package main
import("fmt";"runtime";"syscall";"unsafe")
type event struct { value uint64; signo int32; notify int32; tid int32; padding [44]byte }
func main(){runtime.LockOSThread();defer runtime.UnlockOSThread();for _, n:=range []int32{1,0,4}{for _,sig:=range []int32{35,64}{e:=event{value:1,signo:sig,notify:n,tid:int32(syscall.Gettid())};var id int32;_,_,errno:=syscall.RawSyscall(syscall.SYS_TIMER_CREATE,1,uintptr(unsafe.Pointer(&e)),uintptr(unsafe.Pointer(&id)));fmt.Printf("arch=%s clock=1 notify=%d signo=%d tid=%d size=%d errno=%d %v\n",runtime.GOARCH,n,sig,e.tid,unsafe.Sizeof(e),errno,errno);if errno==0{syscall.RawSyscall(syscall.SYS_TIMER_DELETE,uintptr(id),0,0)}}}}
