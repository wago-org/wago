"""Reuse Stage2 quiet-window method. Each cell runs all validated adapters serially."""
import os,pathlib,time,json,subprocess,datetime,types,fcntl
OUT=pathlib.Path(__file__).resolve().parent
source=(OUT.parent/'stage2-benchmark/measure.py').read_text()
# Reuse the exact /proc CPU and process accounting helpers, without script entrypoint.
ns={'os':os,'pathlib':pathlib,'time':time,'datetime':datetime,'subprocess':subprocess,'json':json}
exec(source[source.index('def processes():'):source.index('last_progress=time.monotonic()')],ns)
def thermal():
 values=[]
 for p in pathlib.Path('/sys/class/hwmon').glob('hwmon*/temp*_input'):
  if (p.parent/'name').read_text().strip() not in ('k10temp','coretemp','cpu_thermal'): continue
  try: values.append({'path':str(p),'c':int(p.read_text())/1000})
  except (OSError,ValueError): pass
 return {'available':bool(values),'sensors':values,'maximum_c':max([x['c'] for x in values],default=None),'admission_veto':False}
def append(file,row):
 with (OUT/file).open('a') as f:f.write(json.dumps(row)+'\n')
def main(tmp,env,manifest,resume=False):
 if not resume:
  # Complete the primary analysis-on baseline oracle matrix before taking timings.
  for tag in ['', 'wagodebug','wago_regalloccheck']:
   suffix='-'+tag if tag else ''
   for m in manifest:
    path=OUT/('validate-baseline-'+(tag or 'ordinary')+'-'+m['id']+'.txt')
    if path.exists():path.rename(path.with_name(path.name.replace('validate-baseline-', 'validate-baselineOff-')))
    cmd=[str(tmp/('baseline'+suffix+'.test')),'-test.run=^$','-test.bench=^(BenchmarkExec|BenchmarkCommandExec)$','-test.benchtime=1x','-test.timeout=2m','-wago.corpus='+m['id']]
    with path.open('w') as f:p=subprocess.run(cmd,cwd=tmp/'baseline/bench/suite',env=env|{'STAGE2_ON':'1'},stdout=f,stderr=subprocess.STDOUT)
    print('validate baselineOn',tag or 'ordinary',m['id'],p.returncode,flush=True)
  metadata={'baseline':'6ceb862219e64480c0503836b19ee1e02b209cc7','stage2':'9d7e4fdf7925265ee0c7db9246e66f0707ee2d76','primary_options':{'baseline':'analysis-on','stage2':'consumer-on'},'go':subprocess.check_output(['/home/dev/.local/share/mise/installs/go/1.27.1/bin/go','version'],env=env,text=True).strip(),'environment':{k:env.get(k) for k in ['GOROOT','GOMAXPROCS','GOFLAGS','GOEXPERIMENT','GOGC','GOMEMLIMIT']},'binaries':{},'harness':{}}
  import hashlib
  for p in tmp.glob('*.test'):metadata['binaries'][p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
  for rev in ['baseline','stage2']:
   for rel in ['bench/suite/suite_test.go','bench/suite/command_corpus_test.go','bench/suite/stage2_corpus_test.go','bench/internal/semanticcorpus/run.go']:
    metadata['harness'][rev+'/'+rel]=hashlib.sha256((tmp/rev/rel).read_bytes()).hexdigest()
  (OUT/'host.json').write_text(json.dumps(metadata,indent=2)+'\n')
  subprocess.run([str(tmp/'stats.test'),'-test.run=^TestStage2Inventory$','-test.v','-wago.corpus=all'],cwd=tmp/'stage2/bench/suite',env=env,stdout=open(OUT/'inventory.txt','w'),stderr=subprocess.STDOUT,check=True)
 # No existing machine lease service/tool or live lease discovered. Canonical main-checkout flock.
 lease=pathlib.Path('/home/dev/Projects/wago/.performance-measurement.lock')
 with lease.open('a+') as f:
  fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  append('lease.jsonl',{'event':'acquired','pid':os.getpid(),'path':str(lease),'authorization':'owner explicitly authorizes corpus measurements','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  allowed=sorted(os.sched_getaffinity(0));ns['a']=types.SimpleNamespace(cpu=allowed[0])
  snap=ns['snapshot'];obs=ns['observation']
  before=snap();time.sleep(2);after=snap()
  choices=[]
  for cpu in allowed:
   ns['a'].cpu=cpu;r=obs(before,after);choices.append((max([r['external_host_pct']]+list(r['watched_cpu_busy_pct'].values())),cpu,r))
  _,cpu,_=min(choices);ns['a'].cpu=cpu
  import collections
  if not (OUT/'cpu-selection-initial.json').exists() and (OUT/'cpu-selection.json').exists():
   (OUT/'cpu-selection-initial.json').write_text((OUT/'cpu-selection.json').read_text())
  all_events=[]
  if (OUT/'during-timing.jsonl').exists():
   with (OUT/'during-timing.jsonl').open() as events_file:
    for line in events_file:
     event=json.loads(line)
     all_events.append({k:event[k] for k in ('cell','attempt','accepted','cpu') if k in event})
  superseded={(x['cell'],x['attempt']) for x in map(json.loads,(OUT/'superseded.jsonl').read_text().splitlines())} if (OUT/'superseded.jsonl').exists() else set()
  initial_cpu=json.loads((OUT/'cpu-selection-initial.json').read_text())['selected'] if (OUT/'cpu-selection-initial.json').exists() else cpu
  active=collections.defaultdict(list)
  for x in all_events:
   if x['accepted'] and (x['cell'],x['attempt']) not in superseded:active[x['cell'].rsplit('-',2)[0]].append(x)
  for workload,events in active.items():
   if len(events)<12 and any(x.get('cpu',initial_cpu)!=cpu for x in events):
    for x in events:
     append('superseded.jsonl',{'cell':x['cell'],'attempt':x['attempt'],'cpu':x.get('cpu',initial_cpu),'replacement_cpu':cpu,'reason':'restart all six revision pairs for incomplete workload on new CPU; completed workload cohorts preserved'})
     superseded.add((x['cell'],x['attempt']))
  (OUT/'cpu-selection.json').write_text(json.dumps({'selected':cpu,'observed':choices,'thermal':thermal()},indent=2)+'\n')
  append('cpu-selection-history.jsonl',{'cpu':cpu,'observed':choices,'thermal':thermal(),'resume':resume})
  # Keep all entries in inventory; missing/unexecutable/failed adapters are explicit runtime gaps.
  eligible=[]
  for m in manifest:
   paths=[OUT/('validate-'+rev+'-ordinary-'+m['id']+'.txt') for rev in ['baseline','stage2']]
   if all('ns/op' in p.read_text() and 'FAIL' not in p.read_text() for p in paths):eligible.append(m['id'])
  (OUT/'timing-eligible.json').write_text(json.dumps(eligible,indent=2)+'\n')
  accepted_cells={x['cell'] for x in all_events if x['accepted'] and (x['cell'],x['attempt']) not in superseded}
  attempts_by_cell={}
  for event in all_events:
   attempts_by_cell[event['cell']]=max(attempts_by_cell.get(event['cell'],0),event['attempt'])
  last=time.monotonic()
  try:
   for m in manifest:
    if m['id'] not in eligible:continue
    for repeat in range(6):
     for name in (['baseline','stage2'] if repeat%2==0 else ['stage2','baseline']):
      label=f"{m['id']}-{repeat+1:02d}-{name}"
      if label in accepted_cells:continue
      attempt=attempts_by_cell.get(label,0)
      while True:
       stable=0
       while stable<3:
        if time.monotonic()-last>300:raise RuntimeError('No admitted measurement progress for five minutes; threshold unchanged')
        before=snap();time.sleep(2);r=obs(before,snap());r.update(label=label,thermal=thermal());append('admission.jsonl',r)
        stable=stable+1 if not r['noisy'] else 0
       attempt+=1
       cmd=['taskset','-c',str(cpu),str(tmp/(name+'.test')),'-test.run=^$','-test.bench=^(BenchmarkExec|BenchmarkCommandExec)$','-test.benchtime=600ms','-test.timeout=3m','-wago.corpus='+m['id']]
       thermal_start=thermal()
       proc=subprocess.Popen(cmd,cwd=tmp/name/'bench/suite',env=env|{'STAGE2_ON':'1'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
       rows=[];before=snap()
       while True:
        try:output,_=proc.communicate(timeout=.25);done=True
        except subprocess.TimeoutExpired:done=False
        after=snap()
        if after[2]-before[2]>=.25:rows.append(obs(before,after,proc.pid))
        before=after
        if done:break
       durations=[]
       for line in output.decode().splitlines():
        fields=line.split()
        if not fields or not (fields[0].startswith('BenchmarkExec/') or fields[0].startswith('BenchmarkCommandExec/')) or 'ns/op' not in fields:continue
        batch=float(fields[fields.index('calls/batch')-1]) if 'calls/batch' in fields else 1
        durations.append(int(fields[1])*float(fields[fields.index('ns/op')-1])*batch/1e9)
       good=proc.returncode==0 and bool(rows) and bool(durations) and min(durations)>=.5 and not any(r['noisy'] for r in rows)
       append('during-timing.jsonl',{'cell':label,'attempt':attempt,'cpu':cpu,'accepted':good,'returncode':proc.returncode,'timed_unit_durations_seconds':durations,'thermal_start':thermal_start,'observations':rows,'thermal_end':thermal()})
       attempts_by_cell[label]=attempt
       (OUT/(('' if good else 'rejected-')+label+f'-attempt{attempt}.txt')).write_bytes(output)
       print('timing',label,attempt,'accepted' if good else 'rejected',flush=True)
       if good:last=time.monotonic();break
       if time.monotonic()-last>300:raise RuntimeError('No accepted measurement progress for five minutes; reassess required')
  except RuntimeError as e:
   (OUT/'timing-blocker.txt').write_text(str(e)+'\n')
  finally:append('lease.jsonl',{'event':'released','pid':os.getpid(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
