TEXT github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.compileModuleWith(SB) /home/jtenner/Projects/wago-sum-unroll/src/core/compiler/backend/railshot/amd64/compile.go
  compile.go:1749	0x6df020		4c8da42458f3ffff		LEAQ 0xfffff358(SP), R12												
  compile.go:1749	0x6df028		4d3b6610			CMPQ R12, 0x10(R14)													
  compile.go:1749	0x6df02c		0f861e490000			JBE 0x6e3950														
  compile.go:1749	0x6df032		55				PUSHQ BP														
  compile.go:1749	0x6df033		4889e5				MOVQ SP, BP														
  compile.go:1749	0x6df036		4881ec200d0000			SUBQ $0xd20, SP														
  compile.go:1749	0x6df03d		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1749	0x6df049		440f11bc2400070000		MOVUPS X15, 0x700(SP)													
  compile.go:1750	0x6df052		80bc24380d000000		CMPB 0xd38(SP), $0x0													
  compile.go:1750	0x6df05a		750b				JNE 0x6df067														
  compile.go:1751	0x6df05c		c78424340d00004f000000		MOVL $0x4f, 0xd34(SP)													
  compile.go:1753	0x6df067		8b9424340d0000			MOVL 0xd34(SP), DX													
  compile.go:1753	0x6df06e		f7c200f8ffff			TESTL $-0x800, DX													
  compile.go:1753	0x6df074		0f85ee080000			JNE 0x6df968														
  compile.go:1758	0x6df07a		80bc24380d000000		CMPB 0xd38(SP), $0x0													
  compile.go:1758	0x6df082		7432				JE 0x6df0b6														
  amd64_features.go:29	0x6df084		0fbae205			BTL $0x5, DX														
  compile.go:1760	0x6df088		7307				JAE 0x6df091														
  compile.go:1760	0x6df08a		b902000000			MOVL $0x2, CX														
  compile.go:1761	0x6df08f		eb02				JMP 0x6df093														
  compile.go:1761	0x6df091		31c9				XORL CX, CX														
  amd64_features.go:29	0x6df093		0fbae207			BTL $0x7, DX														
  compile.go:1763	0x6df097		7303				JAE 0x6df09c														
  compile.go:1764	0x6df099		83c901				ORL $0x1, CX														
  amd64_features.go:29	0x6df09c		0fbae208			BTL $0x8, DX														
  compile.go:1766	0x6df0a0		7303				JAE 0x6df0a5														
  compile.go:1767	0x6df0a2		83c904				ORL $0x4, CX														
  compile.go:1769	0x6df0a5		0fb69424390d0000		MOVZX 0xd39(SP), DX													
  compile.go:1769	0x6df0ad		21d1				ANDL DX, CX														
  compile.go:1769	0x6df0af		888c24390d0000			MOVB CL, 0xd39(SP)													
  compile.go:1772	0x6df0b6		4883bc24980d000000		CMPQ 0xd98(SP), $0x0													
  compile.go:1772	0x6df0bf		90				NOPL															
  compile.go:1772	0x6df0c0		750c				JNE 0x6df0ce														
  compile.go:1773	0x6df0c2		48c78424980d000040000000	MOVQ $0x40, 0xd98(SP)													
  compile.go:1775	0x6df0ce		488b9424980d0000		MOVQ 0xd98(SP), DX													
  compile.go:1775	0x6df0d6		4c8d42c0			LEAQ -0x40(DX), R8													
  compile.go:1775	0x6df0da		660f1f440000			NOPW 0(AX)(AX*1)													
  compile.go:1775	0x6df0e0		4981f8bfff0000			CMPQ R8, $0xffbf													
  compile.go:1775	0x6df0e7		0f877e070000			JA 0x6df86b														
  compile.go:1750	0x6df0ed		48898424380e0000		MOVQ AX, 0xe38(SP)													
  compile.go:1780	0x6df0f5		80bc24900d000000		CMPB 0xd90(SP), $0x0													
  compile.go:1780	0x6df0fd		7407				JE 0x6df106														
  compile.go:1780	0x6df0ff		b901000000			MOVL $0x1, CX														
  compile.go:1780	0x6df104		eb42				JMP 0x6df148														
  compile.go:1780	0x6df106		80bc24b90d000000		CMPB 0xdb9(SP), $0x0													
  compile.go:1780	0x6df10e		7407				JE 0x6df117														
  compile.go:1780	0x6df110		b901000000			MOVL $0x1, CX														
  compile.go:1780	0x6df115		eb31				JMP 0x6df148														
  compile.go:1780	0x6df117		80bc24ba0d000000		CMPB 0xdba(SP), $0x0													
  compile.go:1780	0x6df11f		90				NOPL															
  compile.go:1780	0x6df120		7407				JE 0x6df129														
  compile.go:1780	0x6df122		b901000000			MOVL $0x1, CX														
  compile.go:1780	0x6df127		eb1f				JMP 0x6df148														
  compile.go:1780	0x6df129		488b9c24780d0000		MOVQ 0xd78(SP), BX													
  compile.go:1780	0x6df131		488b8c24800d0000		MOVQ 0xd80(SP), CX													
  compile.go:1780	0x6df139		488bbc24880d0000		MOVQ 0xd88(SP), DI													
  compile.go:1780	0x6df141		e8faa9feff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.moduleUsesSyncHostCalls(SB)			
  compile.go:1780	0x6df146		89c1				MOVL AX, CX														
  compile.go:1780	0x6df148		888c24900d0000			MOVB CL, 0xd90(SP)													
  compile.go:1781	0x6df14f		488d9424f80c0000		LEAQ 0xcf8(SP), DX													
  compile.go:1781	0x6df157		440f113a			MOVUPS X15, 0(DX)													
  compile.go:1781	0x6df15b		440f117a08			MOVUPS X15, 0x8(DX)													
  compile.go:1781	0x6df160		488b0551bbb100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optimizationBindings(SB), AX			
  compile.go:1781	0x6df167		488b9c24400d0000		MOVQ 0xd40(SP), BX													
  compile.go:1781	0x6df16f		488b8c24480d0000		MOVQ 0xd48(SP), CX													
  compile.go:1781	0x6df177		488bbc24500d0000		MOVQ 0xd50(SP), DI													
  compile.go:1781	0x6df17f		488bb424580d0000		MOVQ 0xd58(SP), SI													
  compile.go:1781	0x6df187		e81491f7ff			CALL github.com/wago-org/wago/src/core/compiler/optimization.(*Bindings).ResolveSnapshot(SB)				
  compile.go:1781	0x6df18c		488d9424f80c0000		LEAQ 0xcf8(SP), DX													
  compile.go:1781	0x6df194		4989e0				MOVQ SP, R8														
  compile.go:1781	0x6df197		450f1030			MOVUPS 0(R8), X14													
  compile.go:1781	0x6df19b		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1781	0x6df19f		450f107008			MOVUPS 0x8(R8), X14													
  compile.go:1781	0x6df1a4		440f117208			MOVUPS X14, 0x8(DX)													
  compile.go:1781	0x6df1a9		4c8d8c2430070000		LEAQ 0x730(SP), R9													
  compile.go:1781	0x6df1b1		440f1032			MOVUPS 0(DX), X14													
  compile.go:1781	0x6df1b5		450f1131			MOVUPS X14, 0(R9)													
  compile.go:1781	0x6df1b9		440f107208			MOVUPS 0x8(DX), X14													
  compile.go:1781	0x6df1be		450f117108			MOVUPS X14, 0x8(R9)													
  compile.go:1782	0x6df1c3		4885c0				TESTQ AX, AX														
  compile.go:1782	0x6df1c6		0f84ba000000			JE 0x6df286														
  compile.go:1783	0x6df1cc		440f11bc24000c0000		MOVUPS X15, 0xc00(SP)													
  compile.go:1783	0x6df1d5		7404				JE 0x6df1db														
  compile.go:1783	0x6df1d7		488b4008			MOVQ 0x8(AX), AX													
  compile.go:1783	0x6df1db		48898424000c0000		MOVQ AX, 0xc00(SP)													
  compile.go:1783	0x6df1e3		48899c24080c0000		MOVQ BX, 0xc08(SP)													
  errors.go:26		0x6df1eb		488d0504ee4000			LEAQ 0x40ee04(IP), AX													
  errors.go:26		0x6df1f2		bb09000000			MOVL $0x9, BX														
  errors.go:26		0x6df1f7		488d8c24000c0000		LEAQ 0xc00(SP), CX													
  errors.go:26		0x6df1ff		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6df204		89fe				MOVL DI, SI														
  errors.go:26		0x6df206		e8f5b4e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6df20b		4885c0				TESTQ AX, AX														
  errors.go:26		0x6df20e		7533				JNE 0x6df243														
  errors.go:31		0x6df210		90				NOPL															
  errors.go:65		0x6df211		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6df216		488d1dcb11a700			LEAQ 0xa711cb(IP), BX													
  errors.go:65		0x6df21d		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6df222		e81942d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6df227		48c7400809000000		MOVQ $0x9, 0x8(AX)													
  errors.go:65		0x6df22f		488d15c0ed4000			LEAQ 0x40edc0(IP), DX													
  errors.go:65		0x6df236		488910				MOVQ DX, 0(AX)														
  compile.go:1783	0x6df239		4889c3				MOVQ AX, BX														
  compile.go:1783	0x6df23c		488d05950cae00			LEAQ 0xae0c95(IP), AX													
  compile.go:1783	0x6df243		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1783	0x6df24f		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1783	0x6df257		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:1783	0x6df25f		90				NOPL															
  compile.go:2144	0x6df260		e85b07d7ff			CALL runtime.deferreturn(SB)												
  compile.go:1783	0x6df265		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1783	0x6df26d		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1783	0x6df275		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6df27d		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6df284		5d				POPQ BP															
  compile.go:2144	0x6df285		c3				RET															
  policy.go:37		0x6df286		440f1032			MOVUPS 0(DX), X14													
  policy.go:37		0x6df28a		450f1130			MOVUPS X14, 0(R8)													
  policy.go:37		0x6df28e		440f107208			MOVUPS 0x8(DX), X14													
  policy.go:37		0x6df293		450f117008			MOVUPS X14, 0x8(R8)													
  policy.go:37		0x6df298		31c0				XORL AX, AX														
  policy.go:37		0x6df29a		e8e1c9faff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/shared.codegenPolicy(SB)				
  policy.go:37		0x6df29f		488d8c24680c0000		LEAQ 0xc68(SP), CX													
  policy.go:37		0x6df2a7		488d542418			LEAQ 0x18(SP), DX													
  policy.go:37		0x6df2ac		440f1032			MOVUPS 0(DX), X14													
  policy.go:37		0x6df2b0		440f1131			MOVUPS X14, 0(CX)													
  policy.go:37		0x6df2b4		440f107210			MOVUPS 0x10(DX), X14													
  policy.go:37		0x6df2b9		440f117110			MOVUPS X14, 0x10(CX)													
  policy.go:37		0x6df2be		440f107220			MOVUPS 0x20(DX), X14													
  policy.go:37		0x6df2c3		440f117120			MOVUPS X14, 0x20(CX)													
  compile.go:1785	0x6df2c8		488d9424f0070000		LEAQ 0x7f0(SP), DX													
  compile.go:1785	0x6df2d0		440f1031			MOVUPS 0(CX), X14													
  compile.go:1785	0x6df2d4		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1785	0x6df2d8		440f107110			MOVUPS 0x10(CX), X14													
  compile.go:1785	0x6df2dd		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1785	0x6df2e2		440f107120			MOVUPS 0x20(CX), X14													
  compile.go:1785	0x6df2e7		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1786	0x6df2ec		803db9e3b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.nativeCompactionDisabled(SB), $0x0		
  compile.go:1786	0x6df2f3		757e				JNE 0x6df373														
  compile.go:1786	0x6df2f5		80bc24600d000000		CMPB 0xd60(SP), $0x0													
  compile.go:1786	0x6df2fd		7474				JE 0x6df373														
  policy.go:43		0x6df2ff		4889e1				MOVQ SP, CX														
  policy.go:43		0x6df302		488d942430070000		LEAQ 0x730(SP), DX													
  policy.go:43		0x6df30a		440f1032			MOVUPS 0(DX), X14													
  policy.go:43		0x6df30e		440f1131			MOVUPS X14, 0(CX)													
  policy.go:43		0x6df312		440f107208			MOVUPS 0x8(DX), X14													
  policy.go:43		0x6df317		440f117108			MOVUPS X14, 0x8(CX)													
  policy.go:43		0x6df31c		b801000000			MOVL $0x1, AX														
  policy.go:43		0x6df321		e85ac9faff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/shared.codegenPolicy(SB)				
  policy.go:43		0x6df326		488d8c24680c0000		LEAQ 0xc68(SP), CX													
  policy.go:43		0x6df32e		488d542418			LEAQ 0x18(SP), DX													
  policy.go:43		0x6df333		440f1032			MOVUPS 0(DX), X14													
  policy.go:43		0x6df337		440f1131			MOVUPS X14, 0(CX)													
  policy.go:43		0x6df33b		440f107210			MOVUPS 0x10(DX), X14													
  policy.go:43		0x6df340		440f117110			MOVUPS X14, 0x10(CX)													
  policy.go:43		0x6df345		440f107220			MOVUPS 0x20(DX), X14													
  policy.go:43		0x6df34a		440f117120			MOVUPS X14, 0x20(CX)													
  compile.go:1787	0x6df34f		488d9424f0070000		LEAQ 0x7f0(SP), DX													
  compile.go:1787	0x6df357		440f1031			MOVUPS 0(CX), X14													
  compile.go:1787	0x6df35b		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1787	0x6df35f		440f107110			MOVUPS 0x10(CX), X14													
  compile.go:1787	0x6df364		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1787	0x6df369		440f107120			MOVUPS 0x20(CX), X14													
  compile.go:1787	0x6df36e		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1789	0x6df373		0fb68c24710d0000		MOVZX 0xd71(SP), CX													
  compile.go:1789	0x6df37b		888c2448030000			MOVB CL, 0x348(SP)													
  compile.go:1791	0x6df382		488d9c24680c0000		LEAQ 0xc68(SP), BX													
  compile.go:1791	0x6df38a		440f1032			MOVUPS 0(DX), X14													
  compile.go:1791	0x6df38e		440f1133			MOVUPS X14, 0(BX)													
  compile.go:1791	0x6df392		440f107210			MOVUPS 0x10(DX), X14													
  compile.go:1791	0x6df397		440f117310			MOVUPS X14, 0x10(BX)													
  compile.go:1791	0x6df39c		440f107220			MOVUPS 0x20(DX), X14													
  compile.go:1791	0x6df3a1		440f117320			MOVUPS X14, 0x20(BX)													
  compile.go:1791	0x6df3a6		0fb615e3c2b100			MOVZX github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optBoundsFacts+16(SB), DX			
  compile.go:1791	0x6df3ad		488b1dccc2b100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optBoundsFacts(SB), BX				
  compile.go:1791	0x6df3b4		488b35cdc2b100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optBoundsFacts+8(SB), SI				
  catalog.go:96		0x6df3bb		488bbc24680c0000		MOVQ 0xc68(SP), DI													
  policy.go:28		0x6df3c3		4c8d842490070000		LEAQ 0x790(SP), R8													
  policy.go:28		0x6df3cb		4c8d8c24680c0000		LEAQ 0xc68(SP), R9													
  policy.go:28		0x6df3d3		450f1031			MOVUPS 0(R9), X14													
  policy.go:28		0x6df3d7		450f1130			MOVUPS X14, 0(R8)													
  policy.go:28		0x6df3db		450f107108			MOVUPS 0x8(R9), X14													
  policy.go:28		0x6df3e0		450f117008			MOVUPS X14, 0x8(R8)													
  catalog.go:96		0x6df3e5		4885ff				TESTQ DI, DI														
  catalog.go:96		0x6df3e8		7429				JE 0x6df413														
  catalog.go:96		0x6df3ea		4839df				CMPQ DI, BX														
  catalog.go:96		0x6df3ed		7524				JNE 0x6df413														
  catalog.go:96		0x6df3ef		4883fa02			CMPQ DX, $0x2														
  catalog.go:96		0x6df3f3		0f8351450000			JAE 0x6e394a														
  catalog.go:96		0x6df3f9		488b94d498070000		MOVQ 0x798(SP)(DX*8), DX												
  catalog.go:96		0x6df401		4885f2				TESTQ SI, DX														
  compile.go:1791	0x6df404		740d				JE 0x6df413														
  compile.go:1791	0x6df406		0fb69424720d0000		MOVZX 0xd72(SP), DX													
  compile.go:1791	0x6df40e		83f201				XORL $0x1, DX														
  compile.go:1791	0x6df411		eb02				JMP 0x6df415														
  compile.go:1791	0x6df413		31d2				XORL DX, DX														
  compile.go:1791	0x6df415		88942449030000			MOVB DL, 0x349(SP)													
  compile.go:1792	0x6df41c		488b8c24380e0000		MOVQ 0xe38(SP), CX													
  compile.go:1792	0x6df424		488b8940010000			MOVQ 0x140(CX), CX													
  compile.go:1792	0x6df42b		48898c2458050000		MOVQ CX, 0x558(SP)													
  compile.go:1793	0x6df433		31c0				XORL AX, AX														
  compile.go:1793	0x6df435		e8a6bed3ff			CALL runtime.GOMAXPROCS(SB)												
  compile.go:1793	0x6df43a		488b8c24680d0000		MOVQ 0xd68(SP), CX													
  orchestration.go:11	0x6df442		4883f901			CMPQ CX, $0x1														
  orchestration.go:11	0x6df446		7f0a				JG 0x6df452														
  compile.go:1794	0x6df448		488b9c2458050000		MOVQ 0x558(SP), BX													
  orchestration.go:11	0x6df450		eb14				JMP 0x6df466														
  orchestration.go:11	0x6df452		488b9c2458050000		MOVQ 0x558(SP), BX													
  orchestration.go:11	0x6df45a		660f1f440000			NOPW 0(AX)(AX*1)													
  orchestration.go:11	0x6df460		4883fb01			CMPQ BX, $0x1														
  orchestration.go:11	0x6df464		7f07				JG 0x6df46d														
  orchestration.go:11	0x6df466		b901000000			MOVL $0x1, CX														
  compile.go:1793	0x6df46b		eb1a				JMP 0x6df487														
  orchestration.go:14	0x6df46d		4885c0				TESTQ AX, AX														
  orchestration.go:15	0x6df470		ba01000000			MOVL $0x1, DX														
  orchestration.go:15	0x6df475		480f4ec2			CMOVLE DX, AX														
  orchestration.go:17	0x6df479		4839c1				CMPQ CX, AX														
  orchestration.go:18	0x6df47c		480f4fc8			CMOVG AX, CX														
  orchestration.go:20	0x6df480		4839cb				CMPQ BX, CX														
  orchestration.go:21	0x6df483		480f4ccb			CMOVL BX, CX														
  compile.go:1793	0x6df487		48898c24b0030000		MOVQ CX, 0x3b0(SP)													
  compile.go:1794	0x6df48f		4883fb01			CMPQ BX, $0x1														
  compile.go:1794	0x6df493		771f				JA 0x6df4b4														
  compile.go:1794	0x6df495		48c78424e80b000000000000	MOVQ $0x0, 0xbe8(SP)													
  compile.go:1794	0x6df4a1		440f11bc24f00b0000		MOVUPS X15, 0xbf0(SP)													
  compile.go:1794	0x6df4aa		488d8424e80b0000		LEAQ 0xbe8(SP), AX													
  compile.go:1794	0x6df4b2		eb21				JMP 0x6df4d5														
  compile.go:1794	0x6df4b4		488d057d16a000			LEAQ 0xa0167d(IP), AX													
  compile.go:1794	0x6df4bb		4889d9				MOVQ BX, CX														
  compile.go:1794	0x6df4be		6690				NOPW															
  compile.go:1794	0x6df4c0		e89b0cdbff			CALL runtime.makeslice(SB)												
  compile.go:1807	0x6df4c5		488b8c24b0030000		MOVQ 0x3b0(SP), CX													
  compile.go:1798	0x6df4cd		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:1794	0x6df4d5		48898424b0070000		MOVQ AX, 0x7b0(SP)													
  simd.go:21		0x6df4dd		803ddfe1b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.moduleLiteralIslandEnabled(SB), $0x0		
  simd.go:21		0x6df4e4		7474				JE 0x6df55a														
  simd.go:21		0x6df4e6		80bc240808000000		CMPB 0x808(SP), $0x0													
  compile.go:1797	0x6df4ee		7464				JE 0x6df554														
  compile.go:1798	0x6df4f0		488d5301			LEAQ 0x1(BX), DX													
  compile.go:1798	0x6df4f4		4883fa08			CMPQ DX, $0x8														
  compile.go:1798	0x6df4f8		771b				JA 0x6df515														
  compile.go:1798	0x6df4fa		488db424d0060000		LEAQ 0x6d0(SP), SI													
  compile.go:1798	0x6df502		440f113e			MOVUPS X15, 0(SI)													
  compile.go:1798	0x6df506		440f117e10			MOVUPS X15, 0x10(SI)													
  compile.go:1798	0x6df50b		488db424d0060000		LEAQ 0x6d0(SP), SI													
  compile.go:1798	0x6df513		eb49				JMP 0x6df55e														
  compile.go:1798	0x6df515		4889942418060000		MOVQ DX, 0x618(SP)													
  compile.go:1798	0x6df51d		488d0574cea500			LEAQ 0xa5ce74(IP), AX													
  compile.go:1798	0x6df524		4889d3				MOVQ DX, BX														
  compile.go:1798	0x6df527		4889d9				MOVQ BX, CX														
  compile.go:1798	0x6df52a		e8310cdbff			CALL runtime.makeslice(SB)												
  compile.go:1807	0x6df52f		488b8c24b0030000		MOVQ 0x3b0(SP), CX													
  compile.go:1798	0x6df537		488b942418060000		MOVQ 0x618(SP), DX													
  orchestration.go:44	0x6df53f		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:1798	0x6df547		4889c6				MOVQ AX, SI														
  compile.go:2143	0x6df54a		488b8424b0070000		MOVQ 0x7b0(SP), AX													
  compile.go:1798	0x6df552		eb0a				JMP 0x6df55e														
  compile.go:1798	0x6df554		31d2				XORL DX, DX														
  compile.go:1798	0x6df556		31f6				XORL SI, SI														
  compile.go:1797	0x6df558		eb04				JMP 0x6df55e														
  compile.go:1797	0x6df55a		31d2				XORL DX, DX														
  compile.go:1797	0x6df55c		31f6				XORL SI, SI														
  compile.go:1798	0x6df55e		4889942410050000		MOVQ DX, 0x510(SP)													
  compile.go:1798	0x6df566		4889b42480080000		MOVQ SI, 0x880(SP)													
  orchestration.go:44	0x6df56e		488d0c1b			LEAQ 0(BX)(BX*1), CX													
  orchestration.go:44	0x6df572		48898c2460050000		MOVQ CX, 0x560(SP)													
  compile.go:1800	0x6df57a		90				NOPL															
  orchestration.go:44	0x6df57b		488d05d6cea500			LEAQ 0xa5ced6(IP), AX													
  orchestration.go:44	0x6df582		4889cb				MOVQ CX, BX														
  orchestration.go:44	0x6df585		e8d60bdbff			CALL runtime.makeslice(SB)												
  orchestration.go:45	0x6df58a		488b942458050000		MOVQ 0x558(SP), DX													
  orchestration.go:45	0x6df592		488bb42460050000		MOVQ 0x560(SP), SI													
  orchestration.go:45	0x6df59a		660f1f440000			NOPW 0(AX)(AX*1)													
  orchestration.go:45	0x6df5a0		4839f2				CMPQ DX, SI														
  orchestration.go:45	0x6df5a3		0f879c430000			JA 0x6e3945														
  orchestration.go:44	0x6df5a9		48898424080b0000		MOVQ AX, 0xb08(SP)													
  orchestration.go:45	0x6df5b1		4829d6				SUBQ DX, SI														
  orchestration.go:45	0x6df5b4		4889b42420050000		MOVQ SI, 0x520(SP)													
  orchestration.go:45	0x6df5bc		48f7de				NEGQ SI															
  orchestration.go:45	0x6df5bf		48c1e203			SHLQ $0x3, DX														
  orchestration.go:45	0x6df5c3		48c1fe3f			SARQ $0x3f, SI														
  orchestration.go:45	0x6df5c7		4821f2				ANDQ SI, DX														
  orchestration.go:45	0x6df5ca		4889942418060000		MOVQ DX, 0x618(SP)													
  compile.go:1801	0x6df5d2		90				NOPL															
  types.go:733		0x6df5d3		488b8424380e0000		MOVQ 0xe38(SP), AX													
  types.go:733		0x6df5db		31db				XORL BX, BX														
  types.go:733		0x6df5dd		0f1f00				NOPL 0(AX)														
  types.go:733		0x6df5e0		e87bd0f4ff			CALL github.com/wago-org/wago/src/core/compiler/wasm.(*Module).importCount(SB)						
  types.go:733		0x6df5e5		48898424a8030000		MOVQ AX, 0x3a8(SP)													
  compile.go:1802	0x6df5ed		90				NOPL															
  orchestration.go:45	0x6df5ee		488b8c2418060000		MOVQ 0x618(SP), CX													
  orchestration.go:45	0x6df5f6		488b9424080b0000		MOVQ 0xb08(SP), DX													
  orchestration.go:45	0x6df5fe		4801d1				ADDQ DX, CX														
  orchestration.go:45	0x6df601		48898c2488080000		MOVQ CX, 0x888(SP)													
  types.go:761		0x6df609		488b8424380e0000		MOVQ 0xe38(SP), AX													
  types.go:761		0x6df611		bb03000000			MOVL $0x3, BX														
  types.go:761		0x6df616		e845d0f4ff			CALL github.com/wago-org/wago/src/core/compiler/wasm.(*Module).importCount(SB)						
  types.go:797		0x6df61b		488b8c24380e0000		MOVQ 0xe38(SP), CX													
  types.go:797		0x6df623		480381e8000000			ADDQ 0xe8(CX), AX													
  types.go:797		0x6df62a		48898424a0030000		MOVQ AX, 0x3a0(SP)													
  compile.go:1807	0x6df632		488d9424680c0000		LEAQ 0xc68(SP), DX													
  compile.go:1807	0x6df63a		440f113a			MOVUPS X15, 0(DX)													
  compile.go:1807	0x6df63e		440f117a10			MOVUPS X15, 0x10(DX)													
  compile.go:1807	0x6df643		440f117a20			MOVUPS X15, 0x20(DX)													
  compile.go:1807	0x6df648		440f117a30			MOVUPS X15, 0x30(DX)													
  compile.go:1807	0x6df64d		440f117a40			MOVUPS X15, 0x40(DX)													
  compile.go:1807	0x6df652		440f117a50			MOVUPS X15, 0x50(DX)													
  compile.go:1807	0x6df657		440f117a60			MOVUPS X15, 0x60(DX)													
  compile.go:1807	0x6df65c		440f117a70			MOVUPS X15, 0x70(DX)													
  compile.go:1807	0x6df661		440f11ba80000000		MOVUPS X15, 0x80(DX)													
  compile.go:1807	0x6df669		488bb424080e0000		MOVQ 0xe08(SP), SI													
  compile.go:1807	0x6df671		4c8b8424100e0000		MOVQ 0xe10(SP), R8													
  compile.go:1807	0x6df679		4c8b8c24180e0000		MOVQ 0xe18(SP), R9													
  compile.go:1807	0x6df681		440fb69424b90d0000		MOVZX 0xdb9(SP), R10													
  compile.go:1807	0x6df68a		4889e2				MOVQ SP, DX														
  compile.go:1807	0x6df68d		488dbc24f0070000		LEAQ 0x7f0(SP), DI													
  compile.go:1807	0x6df695		440f1037			MOVUPS 0(DI), X14													
  compile.go:1807	0x6df699		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1807	0x6df69d		440f107710			MOVUPS 0x10(DI), X14													
  compile.go:1807	0x6df6a2		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1807	0x6df6a7		440f107720			MOVUPS 0x20(DI), X14													
  compile.go:1807	0x6df6ac		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1807	0x6df6b1		4889c3				MOVQ AX, BX														
  compile.go:1807	0x6df6b4		488bbc24b0030000		MOVQ 0x3b0(SP), DI													
  compile.go:1807	0x6df6bc		4531db				XORL R11, R11														
  compile.go:1807	0x6df6bf		4889c8				MOVQ CX, AX														
  compile.go:1807	0x6df6c2		488b8c24a8030000		MOVQ 0x3a8(SP), CX													
  compile.go:1807	0x6df6ca		e8d1810000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.computeModuleHintsWithWorkersResidencyPolicy(SB)	
  compile.go:1807	0x6df6cf		488d9424680c0000		LEAQ 0xc68(SP), DX													
  compile.go:1807	0x6df6d7		4c8d5c2430			LEAQ 0x30(SP), R11													
  compile.go:1807	0x6df6dc		450f1033			MOVUPS 0(R11), X14													
  compile.go:1807	0x6df6e0		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1807	0x6df6e4		450f107310			MOVUPS 0x10(R11), X14													
  compile.go:1807	0x6df6e9		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1807	0x6df6ee		450f107320			MOVUPS 0x20(R11), X14													
  compile.go:1807	0x6df6f3		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1807	0x6df6f8		450f107330			MOVUPS 0x30(R11), X14													
  compile.go:1807	0x6df6fd		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:1807	0x6df702		450f107340			MOVUPS 0x40(R11), X14													
  compile.go:1807	0x6df707		440f117240			MOVUPS X14, 0x40(DX)													
  compile.go:1807	0x6df70c		450f107350			MOVUPS 0x50(R11), X14													
  compile.go:1807	0x6df711		440f117250			MOVUPS X14, 0x50(DX)													
  compile.go:1807	0x6df716		450f107360			MOVUPS 0x60(R11), X14													
  compile.go:1807	0x6df71b		440f117260			MOVUPS X14, 0x60(DX)													
  compile.go:1807	0x6df720		450f107370			MOVUPS 0x70(R11), X14													
  compile.go:1807	0x6df725		440f117270			MOVUPS X14, 0x70(DX)													
  compile.go:1807	0x6df72a		450f10b380000000		MOVUPS 0x80(R11), X14													
  compile.go:1807	0x6df732		440f11b280000000		MOVUPS X14, 0x80(DX)													
  compile.go:1807	0x6df73a		4c8d9c2490090000		LEAQ 0x990(SP), R11													
  compile.go:1807	0x6df742		440f1032			MOVUPS 0(DX), X14													
  compile.go:1807	0x6df746		450f1133			MOVUPS X14, 0(R11)													
  compile.go:1807	0x6df74a		440f107210			MOVUPS 0x10(DX), X14													
  compile.go:1807	0x6df74f		450f117310			MOVUPS X14, 0x10(R11)													
  compile.go:1807	0x6df754		440f107220			MOVUPS 0x20(DX), X14													
  compile.go:1807	0x6df759		450f117320			MOVUPS X14, 0x20(R11)													
  compile.go:1807	0x6df75e		440f107230			MOVUPS 0x30(DX), X14													
  compile.go:1807	0x6df763		450f117330			MOVUPS X14, 0x30(R11)													
  compile.go:1807	0x6df768		440f107240			MOVUPS 0x40(DX), X14													
  compile.go:1807	0x6df76d		450f117340			MOVUPS X14, 0x40(R11)													
  compile.go:1807	0x6df772		440f107250			MOVUPS 0x50(DX), X14													
  compile.go:1807	0x6df777		450f117350			MOVUPS X14, 0x50(R11)													
  compile.go:1807	0x6df77c		440f107260			MOVUPS 0x60(DX), X14													
  compile.go:1807	0x6df781		450f117360			MOVUPS X14, 0x60(R11)													
  compile.go:1807	0x6df786		440f107270			MOVUPS 0x70(DX), X14													
  compile.go:1807	0x6df78b		450f117370			MOVUPS X14, 0x70(R11)													
  compile.go:1807	0x6df790		440f10b280000000		MOVUPS 0x80(DX), X14													
  compile.go:1807	0x6df798		450f11b380000000		MOVUPS X14, 0x80(R11)													
  compile.go:1808	0x6df7a0		4d85c9				TESTQ R9, R9														
  compile.go:1808	0x6df7a3		750d				JNE 0x6df7b2														
  compile.go:1813	0x6df7a5		31d2				XORL DX, DX														
  compile.go:1813	0x6df7a7		4531c9				XORL R9, R9														
  compile.go:1813	0x6df7aa		4531d2				XORL R10, R10														
  compile.go:1813	0x6df7ad		e94e020000			JMP 0x6dfa00														
  compile.go:1809	0x6df7b2		440f11bc24d80b0000		MOVUPS X15, 0xbd8(SP)													
  compile.go:1809	0x6df7bb		7404				JE 0x6df7c1														
  compile.go:1809	0x6df7bd		4d8b4908			MOVQ 0x8(R9), R9													
  compile.go:1809	0x6df7c1		4c898c24d80b0000		MOVQ R9, 0xbd8(SP)													
  compile.go:1809	0x6df7c9		4c899424e00b0000		MOVQ R10, 0xbe0(SP)													
  errors.go:26		0x6df7d1		488d051ee84000			LEAQ 0x40e81e(IP), AX													
  errors.go:26		0x6df7d8		bb09000000			MOVL $0x9, BX														
  errors.go:26		0x6df7dd		488d8c24d80b0000		LEAQ 0xbd8(SP), CX													
  errors.go:26		0x6df7e5		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6df7ea		89fe				MOVL DI, SI														
  errors.go:26		0x6df7ec		e80fafe1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6df7f1		4885c0				TESTQ AX, AX														
  errors.go:26		0x6df7f4		7533				JNE 0x6df829														
  errors.go:31		0x6df7f6		90				NOPL															
  errors.go:65		0x6df7f7		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6df7fc		488d1de50ba700			LEAQ 0xa70be5(IP), BX													
  errors.go:65		0x6df803		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6df808		e8333cd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6df80d		48c7400809000000		MOVQ $0x9, 0x8(AX)													
  errors.go:65		0x6df815		488d15dae74000			LEAQ 0x40e7da(IP), DX													
  errors.go:65		0x6df81c		488910				MOVQ DX, 0(AX)														
  compile.go:1809	0x6df81f		4889c3				MOVQ AX, BX														
  compile.go:1809	0x6df822		488d05af06ae00			LEAQ 0xae06af(IP), AX													
  compile.go:1809	0x6df829		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1809	0x6df835		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1809	0x6df83d		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6df845		e87601d7ff			CALL runtime.deferreturn(SB)												
  compile.go:1809	0x6df84a		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1809	0x6df852		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1809	0x6df85a		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6df862		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6df869		5d				POPQ BP															
  compile.go:2144	0x6df86a		c3				RET															
  compile.go:1776	0x6df86b		488d8c24100c0000		LEAQ 0xc10(SP), CX													
  compile.go:1776	0x6df873		440f1139			MOVUPS X15, 0(CX)													
  compile.go:1776	0x6df877		440f117910			MOVUPS X15, 0x10(CX)													
  compile.go:1776	0x6df87c		440f117920			MOVUPS X15, 0x20(CX)													
  compile.go:1776	0x6df881		4889d0				MOVQ DX, AX														
  compile.go:1776	0x6df884		e8d7badaff			CALL runtime.convT64(SB)												
  compile.go:1776	0x6df889		488d0dc8cba500			LEAQ 0xa5cbc8(IP), CX													
  compile.go:1776	0x6df890		48898c24100c0000		MOVQ CX, 0xc10(SP)													
  compile.go:1776	0x6df898		48898424180c0000		MOVQ AX, 0xc18(SP)													
  compile.go:1776	0x6df8a0		48898c24200c0000		MOVQ CX, 0xc20(SP)													
  compile.go:1776	0x6df8a8		488d15f94f4500			LEAQ 0x454ff9(IP), DX													
  compile.go:1776	0x6df8af		48899424280c0000		MOVQ DX, 0xc28(SP)													
  compile.go:1776	0x6df8b7		48898c24300c0000		MOVQ CX, 0xc30(SP)													
  compile.go:1776	0x6df8bf		488d0da24c4500			LEAQ 0x454ca2(IP), CX													
  compile.go:1776	0x6df8c6		48898c24380c0000		MOVQ CX, 0xc38(SP)													
  errors.go:26		0x6df8ce		488d054d104400			LEAQ 0x44104d(IP), AX													
  errors.go:26		0x6df8d5		bb3a000000			MOVL $0x3a, BX														
  errors.go:26		0x6df8da		488d8c24100c0000		LEAQ 0xc10(SP), CX													
  errors.go:26		0x6df8e2		bf03000000			MOVL $0x3, DI														
  errors.go:26		0x6df8e7		89fe				MOVL DI, SI														
  errors.go:26		0x6df8e9		e812aee1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6df8ee		4885c0				TESTQ AX, AX														
  errors.go:26		0x6df8f1		7533				JNE 0x6df926														
  errors.go:31		0x6df8f3		90				NOPL															
  errors.go:65		0x6df8f4		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6df8f9		488d1de80aa700			LEAQ 0xa70ae8(IP), BX													
  errors.go:65		0x6df900		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6df905		e8363bd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6df90a		48c740083a000000		MOVQ $0x3a, 0x8(AX)													
  errors.go:65		0x6df912		488d1509104400			LEAQ 0x441009(IP), DX													
  errors.go:65		0x6df919		488910				MOVQ DX, 0(AX)														
  compile.go:1776	0x6df91c		4889c3				MOVQ AX, BX														
  compile.go:1776	0x6df91f		488d05b205ae00			LEAQ 0xae05b2(IP), AX													
  compile.go:1776	0x6df926		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1776	0x6df932		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1776	0x6df93a		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6df942		e87900d7ff			CALL runtime.deferreturn(SB)												
  compile.go:1776	0x6df947		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1776	0x6df94f		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1776	0x6df957		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6df95f		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6df966		5d				POPQ BP															
  compile.go:2144	0x6df967		c3				RET															
  errors.go:26		0x6df968		488d051bf24100			LEAQ 0x41f21b(IP), AX													
  errors.go:26		0x6df96f		bb1b000000			MOVL $0x1b, BX														
  errors.go:26		0x6df974		31c9				XORL CX, CX														
  errors.go:26		0x6df976		31ff				XORL DI, DI														
  errors.go:26		0x6df978		89fe				MOVL DI, SI														
  errors.go:26		0x6df97a		e881ade1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6df97f		90				NOPL															
  errors.go:26		0x6df980		4885c0				TESTQ AX, AX														
  errors.go:26		0x6df983		7533				JNE 0x6df9b8														
  errors.go:31		0x6df985		90				NOPL															
  errors.go:65		0x6df986		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6df98b		488d1d560aa700			LEAQ 0xa70a56(IP), BX													
  errors.go:65		0x6df992		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6df997		e8a43ad4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6df99c		48c740081b000000		MOVQ $0x1b, 0x8(AX)													
  errors.go:65		0x6df9a4		488d15dff14100			LEAQ 0x41f1df(IP), DX													
  errors.go:65		0x6df9ab		488910				MOVQ DX, 0(AX)														
  compile.go:1754	0x6df9ae		4889c3				MOVQ AX, BX														
  compile.go:1754	0x6df9b1		488d052005ae00			LEAQ 0xae0520(IP), AX													
  compile.go:1754	0x6df9b8		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1754	0x6df9c4		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1754	0x6df9cc		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6df9d4		e8e7ffd6ff			CALL runtime.deferreturn(SB)												
  compile.go:1754	0x6df9d9		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1754	0x6df9e1		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1754	0x6df9e9		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6df9f1		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6df9f8		5d				POPQ BP															
  compile.go:2144	0x6df9f9		c3				RET															
  compile.go:1813	0x6df9fa		49ffc2				INCQ R10														
  compile.go:1813	0x6df9fd		0f1f00				NOPL 0(AX)														
  compile.go:1813	0x6dfa00		4c39d3				CMPQ BX, R10														
  compile.go:1813	0x6dfa03		7e2e				JLE 0x6dfa33														
  compile.go:1814	0x6dfa05		4d6bda1c			IMULQ $0x1c, R10, R11													
  hints.go:135		0x6dfa09		458b2403			MOVL 0(R11)(AX*1), R12													
  hints.go:135		0x6dfa0d		41c1ec18			SHRL $0x18, R12														
  compile.go:1814	0x6dfa11		450fb6e4			MOVZX R12, R12														
  compile.go:1814	0x6dfa15		4d01e1				ADDQ R12, R9														
  compile.go:1813	0x6dfa18		84d2				TESTL DL, DL														
  compile.go:1815	0x6dfa1a		7407				JE 0x6dfa23														
  compile.go:1815	0x6dfa1c		ba01000000			MOVL $0x1, DX														
  compile.go:1815	0x6dfa21		ebd7				JMP 0x6df9fa														
  compile.go:1815	0x6dfa23		410fb7540316			MOVZX 0x16(R11)(AX*1), DX												
  hints.go:65		0x6dfa29		66f7c20010			TESTW $0x1000, DX													
  hints.go:65		0x6dfa2e		0f95c2				SETNE DL														
  compile.go:1815	0x6dfa31		ebc7				JMP 0x6df9fa														
  compile.go:1807	0x6dfa33		4c89842438050000		MOVQ R8, 0x538(SP)													
  compile.go:1807	0x6dfa3b		4889b42430050000		MOVQ SI, 0x530(SP)													
  compile.go:1807	0x6dfa43		4889bc24200a0000		MOVQ DI, 0xa20(SP)													
  compile.go:1807	0x6dfa4b		48898c24c0050000		MOVQ CX, 0x5c0(SP)													
  compile.go:1807	0x6dfa53		48899c24b8050000		MOVQ BX, 0x5b8(SP)													
  compile.go:1807	0x6dfa5b		48898424880a0000		MOVQ AX, 0xa88(SP)													
  compile.go:1813	0x6dfa63		4c898c24b8040000		MOVQ R9, 0x4b8(SP)													
  compile.go:1813	0x6dfa6b		88942446030000			MOVB DL, 0x346(SP)													
  compile.go:1825	0x6dfa72		4889e2				MOVQ SP, DX														
  compile.go:1825	0x6dfa75		488db424f0070000		LEAQ 0x7f0(SP), SI													
  compile.go:1825	0x6dfa7d		440f1036			MOVUPS 0(SI), X14													
  compile.go:1825	0x6dfa81		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1825	0x6dfa85		440f107610			MOVUPS 0x10(SI), X14													
  compile.go:1825	0x6dfa8a		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1825	0x6dfa8f		440f107620			MOVUPS 0x20(SI), X14													
  compile.go:1825	0x6dfa94		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1825	0x6dfa99		4889cf				MOVQ CX, DI														
  compile.go:1825	0x6dfa9c		4889d9				MOVQ BX, CX														
  compile.go:1825	0x6dfa9f		4889c3				MOVQ AX, BX														
  compile.go:1825	0x6dfaa2		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:1825	0x6dfaaa		e8b1b10000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.computeImmutableTableHints(SB)			
  compile.go:1818	0x6dfaaf		488b9424b8040000		MOVQ 0x4b8(SP), DX													
  compile.go:1818	0x6dfab7		4883fa08			CMPQ DX, $0x8														
  compile.go:1819	0x6dfabb		be00000000			MOVL $0x0, SI														
  compile.go:1819	0x6dfac0		480f4cd6			CMOVL SI, DX														
  compile.go:1827	0x6dfac4		31f6				XORL SI, SI														
  compile.go:1827	0x6dfac6		4531c0				XORL R8, R8														
  compile.go:1825	0x6dfac9		4889cf				MOVQ CX, DI														
  compile.go:1827	0x6dfacc		488b8c24b8050000		MOVQ 0x5b8(SP), CX													
  compile.go:1825	0x6dfad4		4989d9				MOVQ BX, R9														
  compile.go:1827	0x6dfad7		488b9c24880a0000		MOVQ 0xa88(SP), BX													
  compile.go:1827	0x6dfadf		90				NOPL															
  compile.go:1827	0x6dfae0		eb15				JMP 0x6dfaf7														
  compile.go:1828	0x6dfae2		4c6bd61c			IMULQ $0x1c, SI, R10													
  hints.go:134		0x6dfae6		458b141a			MOVL 0(R10)(BX*1), R10													
  compile.go:1828	0x6dfaea		4181e2ffff1f00			ANDL $0x1fffff, R10													
  compile.go:1828	0x6dfaf1		4d01d0				ADDQ R10, R8														
  compile.go:1827	0x6dfaf4		48ffc6				INCQ SI															
  compile.go:1827	0x6dfaf7		4839f1				CMPQ CX, SI														
  compile.go:1827	0x6dfafa		7fe6				JG 0x6dfae2														
  compile.go:1834	0x6dfafc		440fb6157fdbb300		MOVZX github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.gcSharedStubsEnabled(SB), R10			
  compile.go:1834	0x6dfb04		4584d2				TESTL R10, R10														
  compile.go:1834	0x6dfb07		743c				JE 0x6dfb45														
  compile.go:1834	0x6dfb09		803d76dbb30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.gcResolveReuseEnabled(SB), $0x0			
  compile.go:1834	0x6dfb10		7426				JE 0x6dfb38														
  compile.go:1794	0x6dfb12		4c8b9c2458050000		MOVQ 0x558(SP), R11													
  compile.go:1794	0x6dfb1a		660f1f440000			NOPW 0(AX)(AX*1)													
  compile.go:1794	0x6dfb20		4983fb01			CMPQ R11, $0x1														
  compile.go:1834	0x6dfb24		750d				JNE 0x6dfb33														
  compile.go:1834	0x6dfb26		4983f802			CMPQ R8, $0x2														
  compile.go:1834	0x6dfb2a		410f9dc4			SETGE R12														
  compile.go:1834	0x6dfb2e		4584d2				TESTL R10, R10														
  compile.go:1834	0x6dfb31		eb20				JMP 0x6dfb53														
  compile.go:1834	0x6dfb33		4584d2				TESTL R10, R10														
  compile.go:1834	0x6dfb36		eb15				JMP 0x6dfb4d														
  compile.go:1834	0x6dfb38		4584d2				TESTL R10, R10														
  compile.go:747	0x6dfb3b		4c8b9c2458050000		MOVQ 0x558(SP), R11													
  compile.go:1834	0x6dfb43		eb08				JMP 0x6dfb4d														
  compile.go:747	0x6dfb45		4c8b9c2458050000		MOVQ 0x558(SP), R11													
  compile.go:1834	0x6dfb4d		41bc00000000			MOVL $0x0, R12														
  compile.go:1835	0x6dfb53		740f				JE 0x6dfb64														
  compile.go:1835	0x6dfb55		4983f802			CMPQ R8, $0x2														
  compile.go:1835	0x6dfb59		7c09				JL 0x6dfb64														
  compile.go:1835	0x6dfb5b		4589e0				MOVL R12, R8														
  compile.go:1835	0x6dfb5e		4183f401			XORL $0x1, R12														
  compile.go:1835	0x6dfb62		eb06				JMP 0x6dfb6a														
  compile.go:1834	0x6dfb64		4589e0				MOVL R12, R8														
  compile.go:1834	0x6dfb67		4531e4				XORL R12, R12														
  compile.go:1836	0x6dfb6a		4531d2				XORL R10, R10														
  compile.go:1836	0x6dfb6d		eb03				JMP 0x6dfb72														
  compile.go:1836	0x6dfb6f		49ffc2				INCQ R10														
  compile.go:1836	0x6dfb72		4c39d1				CMPQ CX, R10														
  compile.go:1836	0x6dfb75		7e32				JLE 0x6dfba9														
  compile.go:1837	0x6dfb77		4d6bea1c			IMULQ $0x1c, R10, R13													
  compile.go:1837	0x6dfb7b		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:1835	0x6dfb80		4584e4				TESTL R12, R12														
  hints.go:70		0x6dfb83		7412				JE 0x6dfb97														
  hints.go:71		0x6dfb85		450fb77c1d16			MOVZX 0x16(R13)(BX*1), R15												
  hints.go:71		0x6dfb8b		4183cf40			ORL $0x40, R15														
  hints.go:71		0x6dfb8f		6646897c2b16			MOVW R15, 0x16(BX)(R13*1)												
  hints.go:71		0x6dfb95		ebd8				JMP 0x6dfb6f														
  hints.go:73		0x6dfb97		450fb77c1d16			MOVZX 0x16(R13)(BX*1), R15												
  hints.go:73		0x6dfb9d		4183e7bf			ANDL $-0x41, R15													
  hints.go:73		0x6dfba1		6646897c2b16			MOVW R15, 0x16(BX)(R13*1)												
  hints.go:73		0x6dfba7		ebc6				JMP 0x6dfb6f														
  compile.go:1825	0x6dfba9		4889bc2418060000		MOVQ DI, 0x618(SP)													
  compile.go:1825	0x6dfbb1		4c898c2410060000		MOVQ R9, 0x610(SP)													
  compile.go:1825	0x6dfbb9		48898424d0080000		MOVQ AX, 0x8d0(SP)													
  compile.go:1819	0x6dfbc1		48899424b8040000		MOVQ DX, 0x4b8(SP)													
  compile.go:1834	0x6dfbc9		4584c0				TESTL R8, R8														
  compile.go:1839	0x6dfbcc		741a				JE 0x6dfbe8														
  compile.go:1840	0x6dfbce		4885c9				TESTQ CX, CX														
  compile.go:1840	0x6dfbd1		0f86643d0000			JBE 0x6e393b														
  hints.go:67		0x6dfbd7		440fb74316			MOVZX 0x16(BX), R8													
  hints.go:67		0x6dfbdc		4181c800400000			ORL $0x4000, R8														
  hints.go:67		0x6dfbe3		6644894316			MOVW R8, 0x16(BX)													
  compile.go:1842	0x6dfbe8		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:1842	0x6dfbf0		488b9c24a0030000		MOVQ 0x3a0(SP), BX													
  compile.go:1842	0x6dfbf8		488b8c24200a0000		MOVQ 0xa20(SP), CX													
  compile.go:1842	0x6dfc00		488bbc2430050000		MOVQ 0x530(SP), DI													
  compile.go:1842	0x6dfc08		488bb42438050000		MOVQ 0x538(SP), SI													
  compile.go:1842	0x6dfc10		e84bba0000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.pickModuleGlobals(SB)				
  compile.go:1842	0x6dfc15		4889842470080000		MOVQ AX, 0x870(SP)													
  compile.go:1842	0x6dfc1d		48899c24f0040000		MOVQ BX, 0x4f0(SP)													
  compile.go:1842	0x6dfc25		48898c24f8040000		MOVQ CX, 0x4f8(SP)													
  compile.go:1843	0x6dfc2d		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:1843	0x6dfc35		e806a4faff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/shared.HostAdapterSet(SB)				
  compile.go:1844	0x6dfc3a		4885ff				TESTQ DI, DI														
  compile.go:1844	0x6dfc3d		751a				JNE 0x6dfc59														
  compile.go:1853	0x6dfc3f		31d2				XORL DX, DX														
  compile.go:1843	0x6dfc41		4889ce				MOVQ CX, SI														
  compile.go:1853	0x6dfc44		488b8c24b8050000		MOVQ 0x5b8(SP), CX													
  compile.go:1853	0x6dfc4c		4c8b8424880a0000		MOVQ 0xa88(SP), R8													
  compile.go:1853	0x6dfc54		e9bc000000			JMP 0x6dfd15														
  compile.go:1845	0x6dfc59		440f11bc24c80b0000		MOVUPS X15, 0xbc8(SP)													
  compile.go:1845	0x6dfc62		7404				JE 0x6dfc68														
  compile.go:1845	0x6dfc64		488b7f08			MOVQ 0x8(DI), DI													
  compile.go:1845	0x6dfc68		4889bc24c80b0000		MOVQ DI, 0xbc8(SP)													
  compile.go:1845	0x6dfc70		4889b424d00b0000		MOVQ SI, 0xbd0(SP)													
  errors.go:26		0x6dfc78		488d052d4d4200			LEAQ 0x424d2d(IP), AX													
  errors.go:26		0x6dfc7f		bb20000000			MOVL $0x20, BX														
  errors.go:26		0x6dfc84		488d8c24c80b0000		LEAQ 0xbc8(SP), CX													
  errors.go:26		0x6dfc8c		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6dfc91		89fe				MOVL DI, SI														
  errors.go:26		0x6dfc93		e868aae1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6dfc98		4885c0				TESTQ AX, AX														
  errors.go:26		0x6dfc9b		7533				JNE 0x6dfcd0														
  errors.go:31		0x6dfc9d		90				NOPL															
  errors.go:65		0x6dfc9e		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6dfca3		488d1d3e07a700			LEAQ 0xa7073e(IP), BX													
  errors.go:65		0x6dfcaa		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6dfcaf		e88c37d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6dfcb4		48c7400820000000		MOVQ $0x20, 0x8(AX)													
  errors.go:65		0x6dfcbc		488d15e94c4200			LEAQ 0x424ce9(IP), DX													
  errors.go:65		0x6dfcc3		488910				MOVQ DX, 0(AX)														
  compile.go:1845	0x6dfcc6		4889c3				MOVQ AX, BX														
  compile.go:1845	0x6dfcc9		488d050802ae00			LEAQ 0xae0208(IP), AX													
  compile.go:1845	0x6dfcd0		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1845	0x6dfcdc		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1845	0x6dfce4		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6dfcec		e8cffcd6ff			CALL runtime.deferreturn(SB)												
  compile.go:1845	0x6dfcf1		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1845	0x6dfcf9		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1845	0x6dfd01		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6dfd09		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6dfd10		5d				POPQ BP															
  compile.go:2144	0x6dfd11		c3				RET															
  compile.go:1853	0x6dfd12		48ffc2				INCQ DX															
  compile.go:1853	0x6dfd15		4839d3				CMPQ BX, DX														
  compile.go:1853	0x6dfd18		7e25				JLE 0x6dfd3f														
  compile.go:1853	0x6dfd1a		660f1f440000			NOPW 0(AX)(AX*1)													
  compile.go:1854	0x6dfd20		4839d1				CMPQ CX, DX														
  compile.go:1854	0x6dfd23		0f860d3c0000			JBE 0x6e3936														
  compile.go:1854	0x6dfd29		4c6bca1c			IMULQ $0x1c, DX, R9													
  hints.go:1357		0x6dfd2d		470fb64c0819			MOVZX 0x19(R8)(R9*1), R9												
  hints.go:1357		0x6dfd33		41f6c180			TESTL $0x80, R9														
  compile.go:1854	0x6dfd37		74d9				JE 0x6dfd12														
  compile.go:1855	0x6dfd39		c6041001			MOVB $0x1, 0(AX)(DX*1)													
  compile.go:1855	0x6dfd3d		ebd3				JMP 0x6dfd12														
  compile.go:1858	0x6dfd3f		488b9424300e0000		MOVQ 0xe30(SP), DX													
  compile.go:1858	0x6dfd47		4885d2				TESTQ DX, DX														
  compile.go:1858	0x6dfd4a		7405				JE 0x6dfd51														
  compile.go:1858	0x6dfd4c		488b12				MOVQ 0(DX), DX														
  compile.go:1858	0x6dfd4f		eb02				JMP 0x6dfd53														
  compile.go:1858	0x6dfd51		31d2				XORL DX, DX														
  compile.go:1843	0x6dfd53		4889b42408060000		MOVQ SI, 0x608(SP)													
  compile.go:1843	0x6dfd5b		48899c2428050000		MOVQ BX, 0x528(SP)													
  compile.go:1843	0x6dfd63		48898424d8080000		MOVQ AX, 0x8d8(SP)													
  compile.go:1858	0x6dfd6b		4885d2				TESTQ DX, DX														
  compile.go:1858	0x6dfd6e		7407				JE 0x6dfd77														
  compile.go:1861	0x6dfd70		31d2				XORL DX, DX														
  compile.go:1861	0x6dfd72		e9b53b0000			JMP 0x6e392c														
  compile.go:1902	0x6dfd77		4889e2				MOVQ SP, DX														
  compile.go:1902	0x6dfd7a		488db424f0070000		LEAQ 0x7f0(SP), SI													
  compile.go:1902	0x6dfd82		440f1036			MOVUPS 0(SI), X14													
  compile.go:1902	0x6dfd86		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1902	0x6dfd8a		440f107610			MOVUPS 0x10(SI), X14													
  compile.go:1902	0x6dfd8f		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1902	0x6dfd94		440f107620			MOVUPS 0x20(SI), X14													
  compile.go:1902	0x6dfd99		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1902	0x6dfd9e		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:1902	0x6dfda6		4c89c3				MOVQ R8, BX														
  compile.go:1902	0x6dfda9		488bbc24c0050000		MOVQ 0x5c0(SP), DI													
  compile.go:1902	0x6dfdb1		e8aa8a0600			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.buildInlineTargets(SB)				
  compile.go:1902	0x6dfdb6		48898424680c0000		MOVQ AX, 0xc68(SP)													
  compile.go:1902	0x6dfdbe		48899c24700c0000		MOVQ BX, 0xc70(SP)													
  compile.go:1902	0x6dfdc6		888c24780c0000			MOVB CL, 0xc78(SP)													
  compile.go:1902	0x6dfdcd		4889bc24800c0000		MOVQ DI, 0xc80(SP)													
  compile.go:1902	0x6dfdd5		4889b424880c0000		MOVQ SI, 0xc88(SP)													
  compile.go:1902	0x6dfddd		4c898424900c0000		MOVQ R8, 0xc90(SP)													
  compile.go:1902	0x6dfde5		44888c24980c0000		MOVB R9, 0xc98(SP)													
  compile.go:1902	0x6dfded		44889424a00c0000		MOVB R10, 0xca0(SP)													
  compile.go:1902	0x6dfdf5		488d942490080000		LEAQ 0x890(SP), DX													
  compile.go:1902	0x6dfdfd		488db424680c0000		LEAQ 0xc68(SP), SI													
  compile.go:1902	0x6dfe05		440f1036			MOVUPS 0(SI), X14													
  compile.go:1902	0x6dfe09		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1902	0x6dfe0d		440f107610			MOVUPS 0x10(SI), X14													
  compile.go:1902	0x6dfe12		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1902	0x6dfe17		440f107620			MOVUPS 0x20(SI), X14													
  compile.go:1902	0x6dfe1c		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1902	0x6dfe21		440f107630			MOVUPS 0x30(SI), X14													
  compile.go:1902	0x6dfe26		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:1903	0x6dfe2b		4883bc24c00d000000		CMPQ 0xdc0(SP), $0x0													
  compile.go:1903	0x6dfe34		7413				JE 0x6dfe49														
  compile.go:1907	0x6dfe36		440f113a			MOVUPS X15, 0(DX)													
  compile.go:1907	0x6dfe3a		440f117a10			MOVUPS X15, 0x10(DX)													
  compile.go:1907	0x6dfe3f		440f117a20			MOVUPS X15, 0x20(DX)													
  compile.go:1907	0x6dfe44		440f117a30			MOVUPS X15, 0x30(DX)													
  compile.go:1918	0x6dfe49		488b9424380e0000		MOVQ 0xe38(SP), DX													
  compile.go:1918	0x6dfe51		4c8b8238010000			MOVQ 0x138(DX), R8													
  compile.go:1918	0x6dfe58		4c8b8a40010000			MOVQ 0x140(DX), R9													
  compile.go:1918	0x6dfe5f		4531d2				XORL R10, R10														
  compile.go:1918	0x6dfe62		4531db				XORL R11, R11														
  compile.go:1918	0x6dfe65		eb0f				JMP 0x6dfe76														
  compile.go:1919	0x6dfe67		496bc368			IMULQ $0x68, R11, AX													
  compile.go:1919	0x6dfe6b		4a8b440058			MOVQ 0x58(AX)(R8*1), AX													
  compile.go:1919	0x6dfe70		4901c2				ADDQ AX, R10														
  compile.go:1918	0x6dfe73		49ffc3				INCQ R11														
  compile.go:1918	0x6dfe76		4d39cb				CMPQ R11, R9														
  compile.go:1918	0x6dfe79		7cec				JL 0x6dfe67														
  compile.go:1918	0x6dfe7b		4c89942480040000		MOVQ R10, 0x480(SP)													
  compile.go:1921	0x6dfe83		90				NOPL															
  compile.go:744	0x6dfe84		80bc240808000000		CMPB 0x808(SP), $0x0													
  compile.go:745	0x6dfe8c		bf25000000			MOVL $0x25, DI														
  compile.go:745	0x6dfe91		ba19000000			MOVL $0x19, DX														
  compile.go:745	0x6dfe96		480f45fa			CMOVNE DX, DI														
  compile.go:747	0x6dfe9a		4c89d0				MOVQ R10, AX														
  compile.go:747	0x6dfe9d		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:747	0x6dfea5		b928000000			MOVL $0x28, CX														
  compile.go:747	0x6dfeaa		be00001000			MOVL $0x100000, SI													
  compile.go:747	0x6dfeaf		e8ac83faff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/shared.TaperedModuleCodeCapacity(SB)			
  compile.go:747	0x6dfeb4		4889842498030000		MOVQ AX, 0x398(SP)													
  compile.go:1922	0x6dfebc		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:1922	0x6dfec4		488b9c2480040000		MOVQ 0x480(SP), BX													
  compile.go:1922	0x6dfecc		e82fe90700			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.buildModuleTypeCache(SB)				
  compile.go:1922	0x6dfed1		488d942420080000		LEAQ 0x820(SP), DX													
  compile.go:1922	0x6dfed9		4989e0				MOVQ SP, R8														
  compile.go:1922	0x6dfedc		450f1030			MOVUPS 0(R8), X14													
  compile.go:1922	0x6dfee0		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1922	0x6dfee4		450f107010			MOVUPS 0x10(R8), X14													
  compile.go:1922	0x6dfee9		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1922	0x6dfeee		450f107020			MOVUPS 0x20(R8), X14													
  compile.go:1922	0x6dfef3		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1922	0x6dfef8		450f107030			MOVUPS 0x30(R8), X14													
  compile.go:1922	0x6dfefd		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:1922	0x6dff02		450f107038			MOVUPS 0x38(R8), X14													
  compile.go:1922	0x6dff07		440f117238			MOVUPS X14, 0x38(DX)													
  bytecode_walk.go:69	0x6dff0c		488b8424380e0000		MOVQ 0xe38(SP), AX													
  bytecode_walk.go:69	0x6dff14		e8c73af4ff			CALL github.com/wago-org/wago/src/core/compiler/wasm.moduleMemargWidths(SB)						
  bytecode_walk.go:69	0x6dff19		888424680c0000			MOVB AL, 0xc68(SP)													
  bytecode_walk.go:69	0x6dff20		48899c24700c0000		MOVQ BX, 0xc70(SP)													
  bytecode_walk.go:69	0x6dff28		48898c24780c0000		MOVQ CX, 0xc78(SP)													
  bytecode_walk.go:69	0x6dff30		4889bc24800c0000		MOVQ DI, 0xc80(SP)													
  bytecode_walk.go:69	0x6dff38		4088b424880c0000		MOVB SI, 0xc88(SP)													
  bytecode_walk.go:69	0x6dff40		488d9424400c0000		LEAQ 0xc40(SP), DX													
  bytecode_walk.go:69	0x6dff48		4c8d8424680c0000		LEAQ 0xc68(SP), R8													
  bytecode_walk.go:69	0x6dff50		450f1030			MOVUPS 0(R8), X14													
  bytecode_walk.go:69	0x6dff54		440f1132			MOVUPS X14, 0(DX)													
  bytecode_walk.go:69	0x6dff58		450f107010			MOVUPS 0x10(R8), X14													
  bytecode_walk.go:69	0x6dff5d		440f117210			MOVUPS X14, 0x10(DX)													
  bytecode_walk.go:69	0x6dff62		450f107018			MOVUPS 0x18(R8), X14													
  bytecode_walk.go:69	0x6dff67		440f117218			MOVUPS X14, 0x18(DX)													
  compile.go:1923	0x6dff6c		4c8d8424680c0000		LEAQ 0xc68(SP), R8													
  compile.go:1923	0x6dff74		450f1138			MOVUPS X15, 0(R8)													
  compile.go:1923	0x6dff78		450f117810			MOVUPS X15, 0x10(R8)													
  compile.go:1923	0x6dff7d		450f117820			MOVUPS X15, 0x20(R8)													
  bytecode_walk.go:69	0x6dff82		4c8d8c24680c0000		LEAQ 0xc68(SP), R9													
  bytecode_walk.go:69	0x6dff8a		440f1032			MOVUPS 0(DX), X14													
  bytecode_walk.go:69	0x6dff8e		450f1131			MOVUPS X14, 0(R9)													
  bytecode_walk.go:69	0x6dff92		440f107210			MOVUPS 0x10(DX), X14													
  bytecode_walk.go:69	0x6dff97		450f117110			MOVUPS X14, 0x10(R9)													
  bytecode_walk.go:69	0x6dff9c		440f107218			MOVUPS 0x18(DX), X14													
  bytecode_walk.go:69	0x6dffa1		450f117118			MOVUPS X14, 0x18(R9)													
  bytecode_walk.go:69	0x6dffa6		c68424900c000001		MOVB $0x1, 0xc90(SP)													
  compile.go:1923	0x6dffae		488d9424500a0000		LEAQ 0xa50(SP), DX													
  compile.go:1923	0x6dffb6		450f1030			MOVUPS 0(R8), X14													
  compile.go:1923	0x6dffba		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1923	0x6dffbe		450f107010			MOVUPS 0x10(R8), X14													
  compile.go:1923	0x6dffc3		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1923	0x6dffc8		450f107020			MOVUPS 0x20(R8), X14													
  compile.go:1923	0x6dffcd		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1927	0x6dffd2		0fb69424700d0000		MOVZX 0xd70(SP), DX													
  compile.go:1927	0x6dffda		84d2				TESTL DL, DL														
  compile.go:744	0x6dffdc		7469				JE 0x6e0047														
  compile.go:1927	0x6dffde		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:1927	0x6dffe6		4c8ba040010000			MOVQ 0x140(AX), R12													
  compile.go:1927	0x6dffed		4983fc01			CMPQ R12, $0x1														
  compile.go:1927	0x6dfff1		7522				JNE 0x6e0015														
  compile.go:1927	0x6dfff3		4c8bac2480040000		MOVQ 0x480(SP), R13													
  compile.go:1927	0x6dfffb		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:1927	0x6e0000		4981fd00080000			CMPQ R13, $0x800													
  compile.go:1927	0x6e0007		7d17				JGE 0x6e0020														
  compile.go:1933	0x6e0009		4889c1				MOVQ AX, CX														
  compile.go:1927	0x6e000c		89d3				MOVL DX, BX														
  compile.go:1927	0x6e000e		ba01000000			MOVL $0x1, DX														
  compile.go:1927	0x6e0013		eb3e				JMP 0x6e0053														
  compile.go:1928	0x6e0015		4c8bac2480040000		MOVQ 0x480(SP), R13													
  compile.go:1928	0x6e001d		0f1f00				NOPL 0(AX)														
  compile.go:1928	0x6e0020		4983fc20			CMPQ R12, $0x20														
  compile.go:1928	0x6e0024		7c18				JL 0x6e003e														
  compile.go:1750	0x6e0026		4889c1				MOVQ AX, CX														
  compile.go:1928	0x6e0029		4c89e8				MOVQ R13, AX														
  compile.go:1927	0x6e002c		89d3				MOVL DX, BX														
  compile.go:1928	0x6e002e		4899				CQO															
  compile.go:1928	0x6e0030		49f7fc				IDIVQ R12														
  compile.go:1928	0x6e0033		483d00080000			CMPQ AX, $0x800														
  compile.go:1928	0x6e0039		0f9cc2				SETL DL															
  compile.go:1928	0x6e003c		eb15				JMP 0x6e0053														
  compile.go:1933	0x6e003e		4889c1				MOVQ AX, CX														
  compile.go:1927	0x6e0041		89d3				MOVL DX, BX														
  compile.go:1927	0x6e0043		31d2				XORL DX, DX														
  compile.go:1928	0x6e0045		eb0c				JMP 0x6e0053														
  compile.go:1933	0x6e0047		488b8c24380e0000		MOVQ 0xe38(SP), CX													
  compile.go:1927	0x6e004f		89d3				MOVL DX, BX														
  compile.go:1927	0x6e0051		31d2				XORL DX, DX														
  compile.go:1929	0x6e0053		4c8ba424b0030000		MOVQ 0x3b0(SP), R12													
  compile.go:1929	0x6e005b		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:1929	0x6e0060		4983fc01			CMPQ R12, $0x1														
  compile.go:1929	0x6e0064		0f8f3b040000			JG 0x6e04a5														
  compile.go:1927	0x6e006a		84db				TESTL BL, BL														
  compile.go:1929	0x6e006c		7408				JE 0x6e0076														
  compile.go:1927	0x6e006e		84d2				TESTL DL, DL														
  compile.go:1929	0x6e0070		0f842f040000			JE 0x6e04a5														
  compile.go:1018	0x6e0076		488b9424300e0000		MOVQ 0xe30(SP), DX													
  compile.go:1932	0x6e007e		90				NOPL															
  compile.go:1932	0x6e007f		90				NOPL															
  compile.go:1018	0x6e0080		4885d2				TESTQ DX, DX														
  compile.go:1018	0x6e0083		7405				JE 0x6e008a														
  compile.go:1018	0x6e0085		488b12				MOVQ 0(DX), DX														
  compile.go:1018	0x6e0088		eb02				JMP 0x6e008c														
  compile.go:1018	0x6e008a		31d2				XORL DX, DX														
  compile.go:1018	0x6e008c		4885d2				TESTQ DX, DX														
  compile.go:1018	0x6e008f		7514				JNE 0x6e00a5														
  compile.go:1018	0x6e0091		80bc24b80d000000		CMPB 0xdb8(SP), $0x0													
  compile.go:1018	0x6e0099		750a				JNE 0x6e00a5														
  compile.go:1018	0x6e009b		80bc24b90d000000		CMPB 0xdb9(SP), $0x0													
  compile.go:1018	0x6e00a3		7407				JE 0x6e00ac														
  compile.go:1018	0x6e00a5		be01000000			MOVL $0x1, SI														
  compile.go:1018	0x6e00aa		eb08				JMP 0x6e00b4														
  compile.go:1018	0x6e00ac		0fb6b424ba0d0000		MOVZX 0xdba(SP), SI													
  compile.go:1933	0x6e00b4		4889e2				MOVQ SP, DX														
  compile.go:1933	0x6e00b7		4c8d842490080000		LEAQ 0x890(SP), R8													
  compile.go:1933	0x6e00bf		450f1030			MOVUPS 0(R8), X14													
  compile.go:1933	0x6e00c3		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1933	0x6e00c7		450f107010			MOVUPS 0x10(R8), X14													
  compile.go:1933	0x6e00cc		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1933	0x6e00d1		450f107020			MOVUPS 0x20(R8), X14													
  compile.go:1933	0x6e00d6		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1933	0x6e00db		450f107030			MOVUPS 0x30(R8), X14													
  compile.go:1933	0x6e00e0		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:1933	0x6e00e5		4889c8				MOVQ CX, AX														
  compile.go:1933	0x6e00e8		488b9c24880a0000		MOVQ 0xa88(SP), BX													
  compile.go:1933	0x6e00f0		488b8c24b8050000		MOVQ 0x5b8(SP), CX													
  compile.go:1933	0x6e00f8		488bbc24c0050000		MOVQ 0x5c0(SP), DI													
  compile.go:1933	0x6e0100		e85bd6ffff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.serialStackArenaCap(SB)				
  compile.go:1933	0x6e0105		48898424a8040000		MOVQ AX, 0x4a8(SP)													
  compile.go:888	0x6e010d		488d05acb5ad00			LEAQ 0xadb5ac(IP), AX													
  compile.go:888	0x6e0114		e8472ad4ff			CALL runtime.newobject(SB)												
  compile.go:888	0x6e0119		4889842418070000		MOVQ AX, 0x718(SP)													
  compile.go:888	0x6e0121		488d0598beac00			LEAQ 0xacbe98(IP), AX													
  compile.go:888	0x6e0128		e8332ad4ff			CALL runtime.newobject(SB)												
  compile.go:888	0x6e012d		833d4cdeb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:888	0x6e0134		750c				JNE 0x6e0142														
  compile.go:888	0x6e0136		488b8c2418070000		MOVQ 0x718(SP), CX													
  compile.go:888	0x6e013e		6690				NOPW															
  compile.go:888	0x6e0140		eb1b				JMP 0x6e015d														
  compile.go:888	0x6e0142		488b8c2418070000		MOVQ 0x718(SP), CX													
  compile.go:888	0x6e014a		488b9100020000			MOVQ 0x200(CX), DX													
  compile.go:888	0x6e0151		e8aa4edbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:888	0x6e0156		498903				MOVQ AX, 0(R11)														
  compile.go:888	0x6e0159		49895308			MOVQ DX, 0x8(R11)													
  compile.go:888	0x6e015d		48898100020000			MOVQ AX, 0x200(CX)													
  compile.go:888	0x6e0164		488b9424a8040000		MOVQ 0x4a8(SP), DX													
  compile.go:888	0x6e016c		48899108020000			MOVQ DX, 0x208(CX)													
  compile.go:888	0x6e0173		488d057ea7ac00			LEAQ 0xaca77e(IP), AX													
  compile.go:888	0x6e017a		e8e129d4ff			CALL runtime.newobject(SB)												
  compile.go:888	0x6e017f		833dfaddb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:888	0x6e0186		750a				JNE 0x6e0192														
  compile.go:888	0x6e0188		488b9c2418070000		MOVQ 0x718(SP), BX													
  compile.go:888	0x6e0190		eb1b				JMP 0x6e01ad														
  compile.go:888	0x6e0192		488b9c2418070000		MOVQ 0x718(SP), BX													
  compile.go:888	0x6e019a		488b9318020000			MOVQ 0x218(BX), DX													
  compile.go:888	0x6e01a1		e85a4edbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:888	0x6e01a6		498903				MOVQ AX, 0(R11)														
  compile.go:888	0x6e01a9		49895308			MOVQ DX, 0x8(R11)													
  compile.go:888	0x6e01ad		48898318020000			MOVQ AX, 0x218(BX)													
  compile.go:1934	0x6e01b4		8b9424340d0000			MOVL 0xd34(SP), DX													
  compile.go:1934	0x6e01bb		8993f8010000			MOVL DX, 0x1f8(BX)													
  compile.go:1935	0x6e01c1		0fb69424390d0000		MOVZX 0xd39(SP), DX													
  compile.go:1935	0x6e01c9		83e207				ANDL $0x7, DX														
  compile.go:1935	0x6e01cc		885045				MOVB DL, 0x45(AX)													
  compile.go:1936	0x6e01cf		488d9328020000			LEAQ 0x228(BX), DX													
  compile.go:1937	0x6e01d6		4c8d8b58020000			LEAQ 0x258(BX), R9													
  compile.go:1938	0x6e01dd		4c8d9388020000			LEAQ 0x288(BX), R10													
  compile.go:1936	0x6e01e4		833d95ddb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:1936	0x6e01eb		747f				JE 0x6e026c														
  compile.go:1936	0x6e01ed		48899424000b0000		MOVQ DX, 0xb00(SP)													
  compile.go:1937	0x6e01f5		4c898c24f80a0000		MOVQ R9, 0xaf8(SP)													
  compile.go:1938	0x6e01fd		4c899424f00a0000		MOVQ R10, 0xaf0(SP)													
  compile.go:1936	0x6e0205		488d05b406ad00			LEAQ 0xad06b4(IP), AX													
  compile.go:1936	0x6e020c		4889d3				MOVQ DX, BX														
  compile.go:1936	0x6e020f		488d8c24f0070000		LEAQ 0x7f0(SP), CX													
  compile.go:1936	0x6e0217		e88468d4ff			CALL runtime.wbMove(SB)													
  compile.go:1937	0x6e021c		488d053546a900			LEAQ 0xa94635(IP), AX													
  compile.go:1937	0x6e0223		488b9c24f80a0000		MOVQ 0xaf8(SP), BX													
  compile.go:1937	0x6e022b		488d8c24500a0000		LEAQ 0xa50(SP), CX													
  compile.go:1937	0x6e0233		e86868d4ff			CALL runtime.wbMove(SB)													
  compile.go:1938	0x6e0238		488d05d156ab00			LEAQ 0xab56d1(IP), AX													
  compile.go:1938	0x6e023f		488b9c24f00a0000		MOVQ 0xaf0(SP), BX													
  compile.go:1938	0x6e0247		488d8c2420080000		LEAQ 0x820(SP), CX													
  compile.go:1938	0x6e024f		e84c68d4ff			CALL runtime.wbMove(SB)													
  compile.go:1936	0x6e0254		488b9424000b0000		MOVQ 0xb00(SP), DX													
  compile.go:1937	0x6e025c		4c8b8c24f80a0000		MOVQ 0xaf8(SP), R9													
  compile.go:1938	0x6e0264		4c8b9424f00a0000		MOVQ 0xaf0(SP), R10													
  compile.go:1936	0x6e026c		4c8d9c24f0070000		LEAQ 0x7f0(SP), R11													
  compile.go:1936	0x6e0274		450f1033			MOVUPS 0(R11), X14													
  compile.go:1936	0x6e0278		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1936	0x6e027c		450f107310			MOVUPS 0x10(R11), X14													
  compile.go:1936	0x6e0281		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1936	0x6e0286		450f107320			MOVUPS 0x20(R11), X14													
  compile.go:1936	0x6e028b		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1937	0x6e0290		488d9424500a0000		LEAQ 0xa50(SP), DX													
  compile.go:1937	0x6e0298		440f1032			MOVUPS 0(DX), X14													
  compile.go:1937	0x6e029c		450f1131			MOVUPS X14, 0(R9)													
  compile.go:1937	0x6e02a0		440f107210			MOVUPS 0x10(DX), X14													
  compile.go:1937	0x6e02a5		450f117110			MOVUPS X14, 0x10(R9)													
  compile.go:1937	0x6e02aa		440f107220			MOVUPS 0x20(DX), X14													
  compile.go:1937	0x6e02af		450f117120			MOVUPS X14, 0x20(R9)													
  compile.go:1938	0x6e02b4		488d942420080000		LEAQ 0x820(SP), DX													
  compile.go:1938	0x6e02bc		440f1032			MOVUPS 0(DX), X14													
  compile.go:1938	0x6e02c0		450f1132			MOVUPS X14, 0(R10)													
  compile.go:1938	0x6e02c4		440f107210			MOVUPS 0x10(DX), X14													
  compile.go:1938	0x6e02c9		450f117210			MOVUPS X14, 0x10(R10)													
  compile.go:1938	0x6e02ce		440f107220			MOVUPS 0x20(DX), X14													
  compile.go:1938	0x6e02d3		450f117220			MOVUPS X14, 0x20(R10)													
  compile.go:1938	0x6e02d8		440f107230			MOVUPS 0x30(DX), X14													
  compile.go:1938	0x6e02dd		450f117230			MOVUPS X14, 0x30(R10)													
  compile.go:1938	0x6e02e2		440f107238			MOVUPS 0x38(DX), X14													
  compile.go:1938	0x6e02e7		450f117238			MOVUPS X14, 0x38(R10)													
  compile.go:1939	0x6e02ec		4889e2				MOVQ SP, DX														
  compile.go:1939	0x6e02ef		4c8d8c2490080000		LEAQ 0x890(SP), R9													
  compile.go:1939	0x6e02f7		450f1031			MOVUPS 0(R9), X14													
  compile.go:1939	0x6e02fb		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1939	0x6e02ff		450f107110			MOVUPS 0x10(R9), X14													
  compile.go:1939	0x6e0304		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:1939	0x6e0309		450f107120			MOVUPS 0x20(R9), X14													
  compile.go:1939	0x6e030e		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:1939	0x6e0313		450f107130			MOVUPS 0x30(R9), X14													
  compile.go:1939	0x6e0318		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:1939	0x6e031d		488b8424880a0000		MOVQ 0xa88(SP), AX													
  compile.go:1939	0x6e0325		488b9c24b8050000		MOVQ 0x5b8(SP), BX													
  compile.go:1939	0x6e032d		488b8c24c0050000		MOVQ 0x5c0(SP), CX													
  compile.go:1939	0x6e0335		488bbc24d8080000		MOVQ 0x8d8(SP), DI													
  compile.go:1939	0x6e033d		488bb42428050000		MOVQ 0x528(SP), SI													
  compile.go:1939	0x6e0345		4c8b842408060000		MOVQ 0x608(SP), R8													
  compile.go:1939	0x6e034d		e82e360000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.serialLocalScratchCapacity(SB)			
  compile.go:917	0x6e0352		4885c0				TESTQ AX, AX														
  compile.go:917	0x6e0355		7f0e				JG 0x6e0365														
  compile.go:907	0x6e0357		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:907	0x6e035f		90				NOPL															
  compile.go:1939	0x6e0360		e905010000			JMP 0x6e046a														
  compile.go:1939	0x6e0365		4889842498050000		MOVQ AX, 0x598(SP)													
  compile.go:920	0x6e036d		31db				XORL BX, BX														
  compile.go:920	0x6e036f		4889c1				MOVQ AX, CX														
  compile.go:920	0x6e0372		488d05476fa800			LEAQ 0xa86f47(IP), AX													
  compile.go:920	0x6e0379		e8e2fddaff			CALL runtime.makeslice(SB)												
  compile.go:920	0x6e037e		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:920	0x6e0386		48c7828005000000000000		MOVQ $0x0, 0x580(DX)													
  compile.go:920	0x6e0391		488b8c2498050000		MOVQ 0x598(SP), CX													
  compile.go:920	0x6e0399		48898a88050000			MOVQ CX, 0x588(DX)													
  compile.go:920	0x6e03a0		833dd9dbb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:920	0x6e03a7		7413				JE 0x6e03bc														
  compile.go:920	0x6e03a9		488bb278050000			MOVQ 0x578(DX), SI													
  compile.go:920	0x6e03b0		e84b4cdbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:920	0x6e03b5		498903				MOVQ AX, 0(R11)														
  compile.go:920	0x6e03b8		49897308			MOVQ SI, 0x8(R11)													
  compile.go:920	0x6e03bc		48898278050000			MOVQ AX, 0x578(DX)													
  compile.go:921	0x6e03c3		488d05cebfa500			LEAQ 0xa5bfce(IP), AX													
  compile.go:921	0x6e03ca		31db				XORL BX, BX														
  compile.go:921	0x6e03cc		e88ffddaff			CALL runtime.makeslice(SB)												
  compile.go:921	0x6e03d1		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:921	0x6e03d9		48c7829805000000000000		MOVQ $0x0, 0x598(DX)													
  compile.go:921	0x6e03e4		488b8c2498050000		MOVQ 0x598(SP), CX													
  compile.go:921	0x6e03ec		48898aa0050000			MOVQ CX, 0x5a0(DX)													
  compile.go:921	0x6e03f3		833d86dbb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:921	0x6e03fa		7413				JE 0x6e040f														
  compile.go:921	0x6e03fc		488bb290050000			MOVQ 0x590(DX), SI													
  compile.go:921	0x6e0403		e8f84bdbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:921	0x6e0408		498903				MOVQ AX, 0(R11)														
  compile.go:921	0x6e040b		49897308			MOVQ SI, 0x8(R11)													
  compile.go:921	0x6e040f		48898290050000			MOVQ AX, 0x590(DX)													
  compile.go:922	0x6e0416		488d059b44aa00			LEAQ 0xaa449b(IP), AX													
  compile.go:922	0x6e041d		31db				XORL BX, BX														
  compile.go:922	0x6e041f		90				NOPL															
  compile.go:922	0x6e0420		e83bfddaff			CALL runtime.makeslice(SB)												
  compile.go:922	0x6e0425		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:922	0x6e042d		48c7820006000000000000		MOVQ $0x0, 0x600(DX)													
  compile.go:922	0x6e0438		488bb42498050000		MOVQ 0x598(SP), SI													
  compile.go:922	0x6e0440		4889b208060000			MOVQ SI, 0x608(DX)													
  compile.go:922	0x6e0447		833d32dbb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:922	0x6e044e		7413				JE 0x6e0463														
  compile.go:922	0x6e0450		488bb2f8050000			MOVQ 0x5f8(DX), SI													
  compile.go:922	0x6e0457		e8a44bdbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:922	0x6e045c		498903				MOVQ AX, 0(R11)														
  compile.go:922	0x6e045f		49897308			MOVQ SI, 0x8(R11)													
  compile.go:922	0x6e0463		488982f8050000			MOVQ AX, 0x5f8(DX)													
  compile.go:1051	0x6e046a		488bb424b8050000		MOVQ 0x5b8(SP), SI													
  compile.go:1051	0x6e0472		488bbc24380e0000		MOVQ 0xe38(SP), DI													
  compile.go:1051	0x6e047a		660f1f440000			NOPW 0(AX)(AX*1)													
  compile.go:1051	0x6e0480		4839b740010000			CMPQ 0x140(DI), SI													
  compile.go:1051	0x6e0487		7513				JNE 0x6e049c														
  compile.go:1055	0x6e0489		4531c0				XORL R8, R8														
  compile.go:1055	0x6e048c		4531c9				XORL R9, R9														
  compile.go:1055	0x6e048f		4c8b9424880a0000		MOVQ 0xa88(SP), R10													
  compile.go:1055	0x6e0497		e967340000			JMP 0x6e3903														
  compile.go:1055	0x6e049c		31c0				XORL AX, AX														
  compile.go:1055	0x6e049e		6690				NOPW															
  compile.go:1940	0x6e04a0		e92b030000			JMP 0x6e07d0														
  compile.go:2143	0x6e04a5		4889e2				MOVQ SP, DX														
  compile.go:2143	0x6e04a8		4c8dac24300d0000		LEAQ 0xd30(SP), R13													
  compile.go:2143	0x6e04b0		41bf04000000			MOVL $0x4, R15														
  compile.go:2143	0x6e04b6		450f107500			MOVUPS 0(R13), X14													
  compile.go:2143	0x6e04bb		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2143	0x6e04bf		450f107510			MOVUPS 0x10(R13), X14													
  compile.go:2143	0x6e04c4		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2143	0x6e04c9		450f107520			MOVUPS 0x20(R13), X14													
  compile.go:2143	0x6e04ce		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2143	0x6e04d3		450f107530			MOVUPS 0x30(R13), X14													
  compile.go:2143	0x6e04d8		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2143	0x6e04dd		4983c540			ADDQ $0x40, R13														
  compile.go:2143	0x6e04e1		4883c240			ADDQ $0x40, DX														
  compile.go:2143	0x6e04e5		41ffcf				DECL R15														
  compile.go:2143	0x6e04e8		75cc				JNE 0x6e04b6														
  compile.go:2143	0x6e04ea		450f1075f8			MOVUPS -0x8(R13), X14													
  compile.go:2143	0x6e04ef		440f1172f8			MOVUPS X14, -0x8(DX)													
  compile.go:2143	0x6e04f4		488b9424b0070000		MOVQ 0x7b0(SP), DX													
  compile.go:2143	0x6e04fc		4889942408010000		MOVQ DX, 0x108(SP)													
  compile.go:2143	0x6e0504		4c8b842458050000		MOVQ 0x558(SP), R8													
  compile.go:2143	0x6e050c		4c89842410010000		MOVQ R8, 0x110(SP)													
  compile.go:2143	0x6e0514		4c89842418010000		MOVQ R8, 0x118(SP)													
  compile.go:2143	0x6e051c		488b942480080000		MOVQ 0x880(SP), DX													
  compile.go:2143	0x6e0524		4889942420010000		MOVQ DX, 0x120(SP)													
  compile.go:2143	0x6e052c		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:2143	0x6e0534		4889942428010000		MOVQ DX, 0x128(SP)													
  compile.go:2143	0x6e053c		4889942430010000		MOVQ DX, 0x130(SP)													
  compile.go:2143	0x6e0544		488b9424880a0000		MOVQ 0xa88(SP), DX													
  compile.go:2143	0x6e054c		4889942438010000		MOVQ DX, 0x138(SP)													
  compile.go:2143	0x6e0554		488b9424b8050000		MOVQ 0x5b8(SP), DX													
  compile.go:2143	0x6e055c		4889942440010000		MOVQ DX, 0x140(SP)													
  compile.go:2143	0x6e0564		488b9424c0050000		MOVQ 0x5c0(SP), DX													
  compile.go:2143	0x6e056c		4889942448010000		MOVQ DX, 0x148(SP)													
  compile.go:2143	0x6e0574		488d942450010000		LEAQ 0x150(SP), DX													
  compile.go:2143	0x6e057c		4c8dac2490090000		LEAQ 0x990(SP), R13													
  compile.go:2143	0x6e0584		450f107500			MOVUPS 0(R13), X14													
  compile.go:2143	0x6e0589		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2143	0x6e058d		450f107510			MOVUPS 0x10(R13), X14													
  compile.go:2143	0x6e0592		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2143	0x6e0597		450f107520			MOVUPS 0x20(R13), X14													
  compile.go:2143	0x6e059c		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2143	0x6e05a1		450f107530			MOVUPS 0x30(R13), X14													
  compile.go:2143	0x6e05a6		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2143	0x6e05ab		450f107540			MOVUPS 0x40(R13), X14													
  compile.go:2143	0x6e05b0		440f117240			MOVUPS X14, 0x40(DX)													
  compile.go:2143	0x6e05b5		450f107550			MOVUPS 0x50(R13), X14													
  compile.go:2143	0x6e05ba		440f117250			MOVUPS X14, 0x50(DX)													
  compile.go:2143	0x6e05bf		450f107560			MOVUPS 0x60(R13), X14													
  compile.go:2143	0x6e05c4		440f117260			MOVUPS X14, 0x60(DX)													
  compile.go:2143	0x6e05c9		450f107570			MOVUPS 0x70(R13), X14													
  compile.go:2143	0x6e05ce		440f117270			MOVUPS X14, 0x70(DX)													
  compile.go:2143	0x6e05d3		450f10b580000000		MOVUPS 0x80(R13), X14													
  compile.go:2143	0x6e05db		440f11b280000000		MOVUPS X14, 0x80(DX)													
  compile.go:2143	0x6e05e3		488b9424d0080000		MOVQ 0x8d0(SP), DX													
  compile.go:2143	0x6e05eb		48899424e0010000		MOVQ DX, 0x1e0(SP)													
  compile.go:2143	0x6e05f3		488b942410060000		MOVQ 0x610(SP), DX													
  compile.go:2143	0x6e05fb		48899424e8010000		MOVQ DX, 0x1e8(SP)													
  compile.go:2143	0x6e0603		488b942418060000		MOVQ 0x618(SP), DX													
  compile.go:2143	0x6e060b		48899424f0010000		MOVQ DX, 0x1f0(SP)													
  compile.go:2143	0x6e0613		488b942470080000		MOVQ 0x870(SP), DX													
  compile.go:2143	0x6e061b		48899424f8010000		MOVQ DX, 0x1f8(SP)													
  compile.go:2143	0x6e0623		488b9424f0040000		MOVQ 0x4f0(SP), DX													
  compile.go:2143	0x6e062b		4889942400020000		MOVQ DX, 0x200(SP)													
  compile.go:2143	0x6e0633		488b9424f8040000		MOVQ 0x4f8(SP), DX													
  compile.go:2143	0x6e063b		4889942408020000		MOVQ DX, 0x208(SP)													
  compile.go:2143	0x6e0643		488b9424d8080000		MOVQ 0x8d8(SP), DX													
  compile.go:2143	0x6e064b		4889942410020000		MOVQ DX, 0x210(SP)													
  compile.go:2143	0x6e0653		488b942428050000		MOVQ 0x528(SP), DX													
  compile.go:2143	0x6e065b		4889942418020000		MOVQ DX, 0x218(SP)													
  compile.go:2143	0x6e0663		488b942408060000		MOVQ 0x608(SP), DX													
  compile.go:2143	0x6e066b		4889942420020000		MOVQ DX, 0x220(SP)													
  compile.go:2143	0x6e0673		488d942428020000		LEAQ 0x228(SP), DX													
  compile.go:2143	0x6e067b		4c8dac2490080000		LEAQ 0x890(SP), R13													
  compile.go:2143	0x6e0683		450f107500			MOVUPS 0(R13), X14													
  compile.go:2143	0x6e0688		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2143	0x6e068c		450f107510			MOVUPS 0x10(R13), X14													
  compile.go:2143	0x6e0691		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2143	0x6e0696		450f107520			MOVUPS 0x20(R13), X14													
  compile.go:2143	0x6e069b		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2143	0x6e06a0		450f107530			MOVUPS 0x30(R13), X14													
  compile.go:2143	0x6e06a5		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2143	0x6e06aa		488d942468020000		LEAQ 0x268(SP), DX													
  compile.go:2143	0x6e06b2		4c8dac2420080000		LEAQ 0x820(SP), R13													
  compile.go:2143	0x6e06ba		450f107500			MOVUPS 0(R13), X14													
  compile.go:2143	0x6e06bf		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2143	0x6e06c3		450f107510			MOVUPS 0x10(R13), X14													
  compile.go:2143	0x6e06c8		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2143	0x6e06cd		450f107520			MOVUPS 0x20(R13), X14													
  compile.go:2143	0x6e06d2		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2143	0x6e06d7		450f107530			MOVUPS 0x30(R13), X14													
  compile.go:2143	0x6e06dc		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2143	0x6e06e1		450f107538			MOVUPS 0x38(R13), X14													
  compile.go:2143	0x6e06e6		440f117238			MOVUPS X14, 0x38(DX)													
  compile.go:2143	0x6e06eb		488d9424b0020000		LEAQ 0x2b0(SP), DX													
  compile.go:2143	0x6e06f3		4c8dac24f0070000		LEAQ 0x7f0(SP), R13													
  compile.go:2143	0x6e06fb		450f107500			MOVUPS 0(R13), X14													
  compile.go:2143	0x6e0700		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2143	0x6e0704		450f107510			MOVUPS 0x10(R13), X14													
  compile.go:2143	0x6e0709		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2143	0x6e070e		450f107520			MOVUPS 0x20(R13), X14													
  compile.go:2143	0x6e0713		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2143	0x6e0718		48c78424e002000000000000	MOVQ $0x0, 0x2e0(SP)													
  compile.go:2143	0x6e0724		0fb6942448030000		MOVZX 0x348(SP), DX													
  compile.go:2143	0x6e072c		889424e8020000			MOVB DL, 0x2e8(SP)													
  compile.go:2143	0x6e0733		0fb6942449030000		MOVZX 0x349(SP), DX													
  compile.go:2143	0x6e073b		889424e9020000			MOVB DL, 0x2e9(SP)													
  compile.go:2143	0x6e0742		0fb6942446030000		MOVZX 0x346(SP), DX													
  compile.go:2143	0x6e074a		889424ea020000			MOVB DL, 0x2ea(SP)													
  compile.go:2143	0x6e0751		488b9424a8030000		MOVQ 0x3a8(SP), DX													
  compile.go:2143	0x6e0759		48899424f0020000		MOVQ DX, 0x2f0(SP)													
  compile.go:2143	0x6e0761		4889c8				MOVQ CX, AX														
  compile.go:2143	0x6e0764		4c89e3				MOVQ R12, BX														
  compile.go:2143	0x6e0767		488b8c2498030000		MOVQ 0x398(SP), CX													
  compile.go:2143	0x6e076f		488bbc24080b0000		MOVQ 0xb08(SP), DI													
  compile.go:2143	0x6e0777		4c89c6				MOVQ R8, SI														
  compile.go:2143	0x6e077a		4c8b8c2488080000		MOVQ 0x888(SP), R9													
  compile.go:2143	0x6e0782		4c8b942420050000		MOVQ 0x520(SP), R10													
  compile.go:2143	0x6e078a		4d89d3				MOVQ R10, R11														
  compile.go:2143	0x6e078d		e80e330000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.compileModuleParallel(SB)			
  compile.go:2143	0x6e0792		4889842420070000		MOVQ AX, 0x720(SP)													
  compile.go:2143	0x6e079a		48899c2400070000		MOVQ BX, 0x700(SP)													
  compile.go:2143	0x6e07a2		48898c2408070000		MOVQ CX, 0x708(SP)													
  compile.go:2144	0x6e07aa		e811f2d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2143	0x6e07af		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2143	0x6e07b7		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2143	0x6e07bf		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e07c7		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e07ce		5d				POPQ BP															
  compile.go:2144	0x6e07cf		c3				RET															
  compile.go:1940	0x6e07d0		4885c0				TESTQ AX, AX														
  compile.go:1940	0x6e07d3		0f8499000000			JE 0x6e0872														
  compile.go:904	0x6e07d9		0f8e93000000			JLE 0x6e0872														
  compile.go:907	0x6e07df		4c8b8200020000			MOVQ 0x200(DX), R8													
  compile.go:907	0x6e07e6		4983780800			CMPQ 0x8(R8), $0x0													
  compile.go:907	0x6e07eb		7509				JNE 0x6e07f6														
  compile.go:908	0x6e07ed		48898210020000			MOVQ AX, 0x210(DX)													
  compile.go:1941	0x6e07f4		eb7c				JMP 0x6e0872														
  compile.go:1940	0x6e07f6		4889842490030000		MOVQ AX, 0x390(SP)													
  compile.go:911	0x6e07fe		31db				XORL BX, BX														
  compile.go:911	0x6e0800		4889c1				MOVQ AX, CX														
  compile.go:911	0x6e0803		488d054eb9ac00			LEAQ 0xacb94e(IP), AX													
  compile.go:911	0x6e080a		e851f9daff			CALL runtime.makeslice(SB)												
  compile.go:911	0x6e080f		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:911	0x6e0817		48c782400f000000000000		MOVQ $0x0, 0xf40(DX)													
  compile.go:911	0x6e0822		488bb42490030000		MOVQ 0x390(SP), SI													
  compile.go:911	0x6e082a		4889b2480f0000			MOVQ SI, 0xf48(DX)													
  compile.go:911	0x6e0831		833d48d7b30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:911	0x6e0838		7413				JE 0x6e084d														
  compile.go:911	0x6e083a		488b8a380f0000			MOVQ 0xf38(DX), CX													
  compile.go:911	0x6e0841		e8ba47dbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:911	0x6e0846		498903				MOVQ AX, 0(R11)														
  compile.go:911	0x6e0849		49894b08			MOVQ CX, 0x8(R11)													
  compile.go:911	0x6e084d		488982380f0000			MOVQ AX, 0xf38(DX)													
  compile.go:912	0x6e0854		4889b258180000			MOVQ SI, 0x1858(DX)													
  compile.go:913	0x6e085b		4889b260180000			MOVQ SI, 0x1860(DX)													
  compile.go:1997	0x6e0862		488bb424b8050000		MOVQ 0x5b8(SP), SI													
  compile.go:1980	0x6e086a		488bbc24380e0000		MOVQ 0xe38(SP), DI													
  compile.go:1945	0x6e0872		80bc24700d000000		CMPB 0xd70(SP), $0x0													
  compile.go:1945	0x6e087a		742c				JE 0x6e08a8														
  compile.go:1947	0x6e087c		488b842498030000		MOVQ 0x398(SP), AX													
  compile.go:1947	0x6e0884		483d00000400			CMPQ AX, $0x40000													
  compile.go:1947	0x6e088a		7c0f				JL 0x6e089b														
  compile.go:1948	0x6e088c		4889c1				MOVQ AX, CX														
  compile.go:1948	0x6e088f		48c1e902			SHRQ $0x2, CX														
  compile.go:1948	0x6e0893		4889c3				MOVQ AX, BX														
  compile.go:1948	0x6e0896		4829cb				SUBQ CX, BX														
  compile.go:1948	0x6e0899		eb03				JMP 0x6e089e														
  compile.go:1948	0x6e089b		4889c3				MOVQ AX, BX														
  compile.go:1950	0x6e089e		4889d8				MOVQ BX, AX														
  compile.go:1950	0x6e08a1		e89af9fbff			CALL github.com/wago-org/wago/src/core/runtime.NewHeapCodeBuffer(SB)							
  compile.go:1950	0x6e08a6		eb0d				JMP 0x6e08b5														
  compile.go:1952	0x6e08a8		488b842498030000		MOVQ 0x398(SP), AX													
  compile.go:1952	0x6e08b0		e8abfafbff			CALL github.com/wago-org/wago/src/core/runtime.NewCodeBuffer(SB)							
  compile.go:1954	0x6e08b5		4885db				TESTQ BX, BX														
  compile.go:1954	0x6e08b8		0f858d010000			JNE 0x6e0a4b														
  compile.go:1950	0x6e08be		48898424800a0000		MOVQ AX, 0xa80(SP)													
  compile.go:1957	0x6e08c6		c684244703000000		MOVB $0x0, 0x347(SP)													
  compile.go:1958	0x6e08ce		488d0dcb2a0b00			LEAQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.compileModuleWith.func1(SB), CX			
  compile.go:1958	0x6e08d5		48898c24a00b0000		MOVQ CX, 0xba0(SP)													
  compile.go:1958	0x6e08dd		488d8c2447030000		LEAQ 0x347(SP), CX													
  compile.go:1958	0x6e08e5		48898c24a80b0000		MOVQ CX, 0xba8(SP)													
  compile.go:1958	0x6e08ed		48898424b00b0000		MOVQ AX, 0xbb0(SP)													
  compile.go:1958	0x6e08f5		488d8c24a00b0000		LEAQ 0xba0(SP), CX													
  compile.go:1958	0x6e08fd		48898c2478060000		MOVQ CX, 0x678(SP)													
  compile.go:1958	0x6e0905		488d842460060000		LEAQ 0x660(SP), AX													
  compile.go:1958	0x6e090d		e88eebd6ff			CALL runtime.deferprocStack(SB)												
  compile.go:1967	0x6e0912		488b9424a80d0000		MOVQ 0xda8(SP), DX													
  orchestration.go:29	0x6e091a		4885d2				TESTQ DX, DX														
  orchestration.go:29	0x6e091d		7f23				JG 0x6e0942														
  orchestration.go:32	0x6e091f		488bb42498030000		MOVQ 0x398(SP), SI													
  orchestration.go:32	0x6e0927		488d3c76			LEAQ 0(SI)(SI*2), DI													
  orchestration.go:32	0x6e092b		488d347e			LEAQ 0(SI)(DI*2), SI													
  orchestration.go:32	0x6e092f		4889f7				MOVQ SI, DI														
  orchestration.go:32	0x6e0932		48c1fe3f			SARQ $0x3f, SI														
  orchestration.go:32	0x6e0936		48c1ee3d			SHRQ $0x3d, SI														
  orchestration.go:32	0x6e093a		488d143e			LEAQ 0(SI)(DI*1), DX													
  orchestration.go:32	0x6e093e		48c1fa03			SARQ $0x3, DX														
  compile.go:1967	0x6e0942		4889942488030000		MOVQ DX, 0x388(SP)													
  compile.go:1971	0x6e094a		80bc240808000000		CMPB 0x808(SP), $0x0													
  compile.go:1971	0x6e0952		0f84bf000000			JE 0x6e0a17														
  compile.go:1972	0x6e0958		488db424680c0000		LEAQ 0xc68(SP), SI													
  compile.go:1972	0x6e0960		488dbc24f0070000		LEAQ 0x7f0(SP), DI													
  compile.go:1972	0x6e0968		440f1037			MOVUPS 0(DI), X14													
  compile.go:1972	0x6e096c		440f1136			MOVUPS X14, 0(SI)													
  compile.go:1972	0x6e0970		440f107710			MOVUPS 0x10(DI), X14													
  compile.go:1972	0x6e0975		440f117610			MOVUPS X14, 0x10(SI)													
  compile.go:1972	0x6e097a		440f107720			MOVUPS 0x20(DI), X14													
  compile.go:1972	0x6e097f		440f117620			MOVUPS X14, 0x20(SI)													
  compile.go:1972	0x6e0984		0fb635c5afb100			MOVZX github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optSharedAdapters+16(SB), SI			
  compile.go:1972	0x6e098b		488b3daeafb100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optSharedAdapters(SB), DI			
  compile.go:1972	0x6e0992		4c8b05afafb100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optSharedAdapters+8(SB), R8			
  catalog.go:96		0x6e0999		4c8b8c24680c0000		MOVQ 0xc68(SP), R9													
  policy.go:28		0x6e09a1		4c8d942478070000		LEAQ 0x778(SP), R10													
  policy.go:28		0x6e09a9		4c8d9c24680c0000		LEAQ 0xc68(SP), R11													
  policy.go:28		0x6e09b1		450f1033			MOVUPS 0(R11), X14													
  policy.go:28		0x6e09b5		450f1132			MOVUPS X14, 0(R10)													
  policy.go:28		0x6e09b9		450f107308			MOVUPS 0x8(R11), X14													
  policy.go:28		0x6e09be		450f117208			MOVUPS X14, 0x8(R10)													
  catalog.go:96		0x6e09c3		4d85c9				TESTQ R9, R9														
  catalog.go:96		0x6e09c6		7436				JE 0x6e09fe														
  catalog.go:96		0x6e09c8		4939f9				CMPQ R9, DI														
  catalog.go:96		0x6e09cb		7531				JNE 0x6e09fe														
  catalog.go:96		0x6e09cd		4883fe02			CMPQ SI, $0x2														
  catalog.go:96		0x6e09d1		0f83132f0000			JAE 0x6e38ea														
  catalog.go:96		0x6e09d7		488bb4f480070000		MOVQ 0x780(SP)(SI*8), SI												
  catalog.go:96		0x6e09df		90				NOPL															
  catalog.go:96		0x6e09e0		4c85c6				TESTQ R8, SI														
  compile.go:1972	0x6e09e3		7419				JE 0x6e09fe														
  compile.go:1389	0x6e09e5		31f6				XORL SI, SI														
  compile.go:1389	0x6e09e7		31ff				XORL DI, DI														
  compile.go:1389	0x6e09e9		4c8b842428050000		MOVQ 0x528(SP), R8													
  compile.go:1389	0x6e09f1		4c8b8c24d8080000		MOVQ 0x8d8(SP), R9													
  compile.go:1389	0x6e09f9		e97a2e0000			JMP 0x6e3878														
  compile.go:1389	0x6e09fe		31f6				XORL SI, SI														
  compile.go:1389	0x6e0a00		31ff				XORL DI, DI														
  compile.go:1389	0x6e0a02		4c8b842428050000		MOVQ 0x528(SP), R8													
  compile.go:1389	0x6e0a0a		4c8b8c24d8080000		MOVQ 0x8d8(SP), R9													
  compile.go:1389	0x6e0a12		e9e32d0000			JMP 0x6e37fa														
  compile.go:1389	0x6e0a17		31c0				XORL AX, AX														
  compile.go:1389	0x6e0a19		31c9				XORL CX, CX														
  compile.go:1389	0x6e0a1b		31db				XORL BX, BX														
  compile.go:1389	0x6e0a1d		31f6				XORL SI, SI														
  compile.go:1389	0x6e0a1f		90				NOPL															
  compile.go:1971	0x6e0a20		e9e1000000			JMP 0x6e0b06														
  compile.go:2144	0x6e0a25		e896efd6ff			CALL runtime.deferreturn(SB)												
  compile.go:1958	0x6e0a2a		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1958	0x6e0a32		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1958	0x6e0a3a		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e0a42		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e0a49		5d				POPQ BP															
  compile.go:2144	0x6e0a4a		c3				RET															
  compile.go:1955	0x6e0a4b		440f11bc24b80b0000		MOVUPS X15, 0xbb8(SP)													
  compile.go:1955	0x6e0a54		7404				JE 0x6e0a5a														
  compile.go:1955	0x6e0a56		488b5b08			MOVQ 0x8(BX), BX													
  compile.go:1955	0x6e0a5a		48899c24b80b0000		MOVQ BX, 0xbb8(SP)													
  compile.go:1955	0x6e0a62		48898c24c00b0000		MOVQ CX, 0xbc0(SP)													
  errors.go:26		0x6e0a6a		488d05691c4200			LEAQ 0x421c69(IP), AX													
  errors.go:26		0x6e0a71		bb1e000000			MOVL $0x1e, BX														
  errors.go:26		0x6e0a76		488d8c24b80b0000		LEAQ 0xbb8(SP), CX													
  errors.go:26		0x6e0a7e		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e0a83		89fe				MOVL DI, SI														
  errors.go:26		0x6e0a85		e8769ce1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e0a8a		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e0a8d		7533				JNE 0x6e0ac2														
  errors.go:31		0x6e0a8f		90				NOPL															
  errors.go:65		0x6e0a90		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e0a95		488d1d4cf9a600			LEAQ 0xa6f94c(IP), BX													
  errors.go:65		0x6e0a9c		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e0aa1		e89a29d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e0aa6		48c740081e000000		MOVQ $0x1e, 0x8(AX)													
  errors.go:65		0x6e0aae		488d15251c4200			LEAQ 0x421c25(IP), DX													
  errors.go:65		0x6e0ab5		488910				MOVQ DX, 0(AX)														
  compile.go:1955	0x6e0ab8		4889c3				MOVQ AX, BX														
  compile.go:1955	0x6e0abb		488d0516f4ad00			LEAQ 0xadf416(IP), AX													
  compile.go:1955	0x6e0ac2		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1955	0x6e0ace		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1955	0x6e0ad6		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:1955	0x6e0ade		6690				NOPW															
  compile.go:2144	0x6e0ae0		e8dbeed6ff			CALL runtime.deferreturn(SB)												
  compile.go:1955	0x6e0ae5		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1955	0x6e0aed		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1955	0x6e0af5		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e0afd		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e0b04		5d				POPQ BP															
  compile.go:2144	0x6e0b05		c3				RET															
  compile.go:2144	0x6e0b06		48898424e0050000		MOVQ AX, 0x5e0(SP)													
  compile.go:2144	0x6e0b0e		48899c24980a0000		MOVQ BX, 0xa98(SP)													
  compile.go:2144	0x6e0b16		48898c24d0050000		MOVQ CX, 0x5d0(SP)													
  compile.go:2144	0x6e0b1e		4889b424900a0000		MOVQ SI, 0xa90(SP)													
  compile.go:1978	0x6e0b26		488d9424b8030000		LEAQ 0x3b8(SP), DX													
  compile.go:1978	0x6e0b2e		be03000000			MOVL $0x3, SI														
  compile.go:1978	0x6e0b33		440f113a			MOVUPS X15, 0(DX)													
  compile.go:1978	0x6e0b37		440f117a10			MOVUPS X15, 0x10(DX)													
  compile.go:1978	0x6e0b3c		440f117a20			MOVUPS X15, 0x20(DX)													
  compile.go:1978	0x6e0b41		440f117a30			MOVUPS X15, 0x30(DX)													
  compile.go:1978	0x6e0b46		4883c240			ADDQ $0x40, DX														
  compile.go:1978	0x6e0b4a		ffce				DECL SI															
  compile.go:1978	0x6e0b4c		75e5				JNE 0x6e0b33														
  compile.go:1978	0x6e0b4e		440f117af8			MOVUPS X15, -0x8(DX)													
  compile.go:1979	0x6e0b53		488d051e3eaa00			LEAQ 0xaa3e1e(IP), AX													
  compile.go:1979	0x6e0b5a		31db				XORL BX, BX														
  compile.go:1979	0x6e0b5c		488b8c24b8040000		MOVQ 0x4b8(SP), CX													
  compile.go:1979	0x6e0b64		e8f7f5daff			CALL runtime.makeslice(SB)												
  compile.go:1206	0x6e0b69		4c8b9c2458050000		MOVQ 0x558(SP), R11													
  compile.go:1206	0x6e0b71		498d533f			LEAQ 0x3f(R11), DX													
  compile.go:1206	0x6e0b75		498d733f			LEAQ 0x3f(R11), SI													
  compile.go:1980	0x6e0b79		488bbc24380e0000		MOVQ 0xe38(SP), DI													
  compile.go:1980	0x6e0b81		4c8b8740010000			MOVQ 0x140(DI), R8													
  compile.go:1980	0x6e0b88		4c89842400060000		MOVQ R8, 0x600(SP)													
  compile.go:1206	0x6e0b90		48c1ea06			SHRQ $0x6, DX														
  compile.go:1206	0x6e0b94		48899424a8050000		MOVQ DX, 0x5a8(SP)													
  compile.go:1206	0x6e0b9c		48c1ee06			SHRQ $0x6, SI														
  compile.go:1206	0x6e0ba0		4889b424a0050000		MOVQ SI, 0x5a0(SP)													
  compile.go:1980	0x6e0ba8		4531c9				XORL R9, R9														
  compile.go:1980	0x6e0bab		4531d2				XORL R10, R10														
  compile.go:1980	0x6e0bae		4531e4				XORL R12, R12														
  compile.go:1980	0x6e0bb1		4531ed				XORL R13, R13														
  compile.go:1980	0x6e0bb4		4531ff				XORL R15, R15														
  compile.go:1980	0x6e0bb7		31f6				XORL SI, SI														
  compile.go:1980	0x6e0bb9		31d2				XORL DX, DX														
  compile.go:1980	0x6e0bbb		31ff				XORL DI, DI														
  compile.go:1980	0x6e0bbd		4531db				XORL R11, R11														
  compile.go:1980	0x6e0bc0		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bc2		31db				XORL BX, BX														
  compile.go:1980	0x6e0bc4		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bc6		48898c24b0050000		MOVQ CX, 0x5b0(SP)													
  compile.go:1980	0x6e0bce		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bd0		888c2443030000			MOVB CL, 0x343(SP)													
  compile.go:1980	0x6e0bd7		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bd9		888c244a030000			MOVB CL, 0x34a(SP)													
  compile.go:1980	0x6e0be0		31c9				XORL CX, CX														
  compile.go:1980	0x6e0be2		48898c2478080000		MOVQ CX, 0x878(SP)													
  compile.go:1980	0x6e0bea		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bec		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bee		48898c24380a0000		MOVQ CX, 0xa38(SP)													
  compile.go:1980	0x6e0bf6		31c9				XORL CX, CX														
  compile.go:1980	0x6e0bf8		48898c24400a0000		MOVQ CX, 0xa40(SP)													
  compile.go:1980	0x6e0c00		488b8c24b8040000		MOVQ 0x4b8(SP), CX													
  compile.go:1980	0x6e0c08		48898c24c8040000		MOVQ CX, 0x4c8(SP)													
  compile.go:1980	0x6e0c10		31c9				XORL CX, CX														
  compile.go:1980	0x6e0c12		eb37				JMP 0x6e0c4b														
  compile.go:1980	0x6e0c14		49ffc4				INCQ R12														
  compile.go:1980	0x6e0c17		4c89a424b0050000		MOVQ R12, 0x5b0(SP)													
  compile.go:1980	0x6e0c1f		4c89fa				MOVQ R15, DX														
  compile.go:1980	0x6e0c22		440fb6bc2444030000		MOVZX 0x344(SP), R15													
  compile.go:1980	0x6e0c2b		4488bc244a030000		MOVB R15, 0x34a(SP)													
  compile.go:1980	0x6e0c33		4c8ba424c0040000		MOVQ 0x4c0(SP), R12													
  compile.go:1980	0x6e0c3b		4c8bbc24d8050000		MOVQ 0x5d8(SP), R15													
  compile.go:1980	0x6e0c43		4c8bac2480050000		MOVQ 0x580(SP), R13													
  compile.go:1980	0x6e0c4b		4c89942470050000		MOVQ R10, 0x570(SP)													
  compile.go:1980	0x6e0c53		4c89a424c0040000		MOVQ R12, 0x4c0(SP)													
  compile.go:1980	0x6e0c5b		4c89ac2478050000		MOVQ R13, 0x578(SP)													
  compile.go:1980	0x6e0c63		4889b42408050000		MOVQ SI, 0x508(SP)													
  compile.go:1980	0x6e0c6b		4889942400050000		MOVQ DX, 0x500(SP)													
  compile.go:1980	0x6e0c73		44898c2464030000		MOVL R9, 0x364(SP)													
  compile.go:1980	0x6e0c7b		4c8ba424b0050000		MOVQ 0x5b0(SP), R12													
  compile.go:1980	0x6e0c83		4d39c4				CMPQ R12, R8														
  compile.go:1980	0x6e0c86		0f8d9a1b0000			JGE 0x6e2826														
  compile.go:1980	0x6e0c8c		4c89bc24d8050000		MOVQ R15, 0x5d8(SP)													
  compile.go:1986	0x6e0c94		4c8dac24680c0000		LEAQ 0xc68(SP), R13													
  compile.go:1986	0x6e0c9c		4c8dbc2490080000		LEAQ 0x890(SP), R15													
  compile.go:1986	0x6e0ca4		450f1037			MOVUPS 0(R15), X14													
  compile.go:1986	0x6e0ca8		450f117500			MOVUPS X14, 0(R13)													
  compile.go:1986	0x6e0cad		450f107710			MOVUPS 0x10(R15), X14													
  compile.go:1986	0x6e0cb2		450f117510			MOVUPS X14, 0x10(R13)													
  compile.go:1986	0x6e0cb7		450f107720			MOVUPS 0x20(R15), X14													
  compile.go:1986	0x6e0cbc		450f117520			MOVUPS X14, 0x20(R13)													
  compile.go:1986	0x6e0cc1		450f107730			MOVUPS 0x30(R15), X14													
  compile.go:1986	0x6e0cc6		450f117530			MOVUPS X14, 0x30(R13)													
  compile.go:1986	0x6e0ccb		4c8bac2428050000		MOVQ 0x528(SP), R13													
  compile.go:1986	0x6e0cd3		4d39e5				CMPQ R13, R12														
  compile.go:1986	0x6e0cd6		0f860e2b0000			JBE 0x6e37ea														
  compile.go:1986	0x6e0cdc		4c8bac24d8080000		MOVQ 0x8d8(SP), R13													
  compile.go:1986	0x6e0ce4		470fb62c2c			MOVZX 0(R12)(R13*1), R13												
  inline.go:541		0x6e0ce9		803dc5c9b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.inlineDeadBodyEnabled(SB), $0x0			
  inline.go:541		0x6e0cf0		0f848e000000			JE 0x6e0d84														
  compile.go:1986	0x6e0cf6		4584ed				TESTL R13, R13														
  inline.go:541		0x6e0cf9		0f8585000000			JNE 0x6e0d84														
  inline.go:544		0x6e0cff		4c8bac24680c0000		MOVQ 0xc68(SP), R13													
  inline.go:544		0x6e0d07		4d01e5				ADDQ R12, R13														
  inline.go:527		0x6e0d0a		4c8bbc2498080000		MOVQ 0x898(SP), R15													
  inline.go:519		0x6e0d12		4c2bac2490080000		SUBQ 0x890(SP), R13													
  inline.go:520		0x6e0d1a		4d85ff				TESTQ R15, R15														
  inline.go:520		0x6e0d1d		7451				JE 0x6e0d70														
  inline.go:520		0x6e0d1f		90				NOPL															
  inline.go:520		0x6e0d20		4d85ed				TESTQ R13, R13														
  inline.go:520		0x6e0d23		7c4b				JL 0x6e0d70														
  inline.go:520		0x6e0d25		4d396f08			CMPQ 0x8(R15), R13													
  inline.go:520		0x6e0d29		7e45				JLE 0x6e0d70														
  inline.go:520		0x6e0d2b		4d8b07				MOVQ 0(R15), R8														
  inline.go:523		0x6e0d2e		478b2ca8			MOVL 0(R8)(R13*4), R13													
  inline.go:524		0x6e0d32		4585ed				TESTL R13, R13														
  inline.go:524		0x6e0d35		7407				JE 0x6e0d3e														
  inline.go:524		0x6e0d37		410fbae51f			BTL $0x1f, R13														
  inline.go:524		0x6e0d3c		730d				JAE 0x6e0d4b														
  compile.go:1980	0x6e0d3e		4c8b842400060000		MOVQ 0x600(SP), R8													
  compile.go:1980	0x6e0d46		4531ed				XORL R13, R13														
  inline.go:544		0x6e0d49		eb28				JMP 0x6e0d73														
  inline.go:527		0x6e0d4b		4d8b4720			MOVQ 0x20(R15), R8													
  inline.go:527		0x6e0d4f		41ffcd				DECL R13														
  inline.go:527		0x6e0d52		4d39e8				CMPQ R8, R13														
  inline.go:527		0x6e0d55		0f868a2a0000			JBE 0x6e37e5														
  inline.go:527		0x6e0d5b		4d8b7f18			MOVQ 0x18(R15), R15													
  inline.go:527		0x6e0d5f		4d6bed38			IMULQ $0x38, R13, R13													
  inline.go:527		0x6e0d63		4d01fd				ADDQ R15, R13														
  compile.go:1980	0x6e0d66		4c8b842400060000		MOVQ 0x600(SP), R8													
  inline.go:544		0x6e0d6e		eb03				JMP 0x6e0d73														
  inline.go:544		0x6e0d70		4531ed				XORL R13, R13														
  inline.go:545		0x6e0d73		4d85ed				TESTQ R13, R13														
  inline.go:545		0x6e0d76		7407				JE 0x6e0d7f														
  inline.go:545		0x6e0d78		450fb66d37			MOVZX 0x37(R13), R13													
  inline.go:545		0x6e0d7d		eb08				JMP 0x6e0d87														
  inline.go:545		0x6e0d7f		4531ed				XORL R13, R13														
  inline.go:545		0x6e0d82		eb03				JMP 0x6e0d87														
  inline.go:545		0x6e0d84		4531ed				XORL R13, R13														
  compile.go:1986	0x6e0d87		4584ed				TESTL R13, R13														
  compile.go:1986	0x6e0d8a		0f8485000000			JE 0x6e0e15														
  compile.go:1988	0x6e0d90		4c8bac2480080000		MOVQ 0x880(SP), R13													
  compile.go:1988	0x6e0d98		4d85ed				TESTQ R13, R13														
  compile.go:1988	0x6e0d9b		7425				JE 0x6e0dc2														
  compile.go:1989	0x6e0d9d		4d8d7c2401			LEAQ 0x1(R12), R15													
  compile.go:1989	0x6e0da2		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:1989	0x6e0daa		4c39fa				CMPQ DX, R15														
  compile.go:1989	0x6e0dad		0f862b2a0000			JBE 0x6e37de														
  compile.go:1989	0x6e0db3		4c8bbc2400050000		MOVQ 0x500(SP), R15													
  compile.go:1989	0x6e0dbb		47897ca504			MOVL R15, 0x4(R13)(R12*4)												
  compile.go:1989	0x6e0dc0		eb10				JMP 0x6e0dd2														
  compile.go:1989	0x6e0dc2		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:1989	0x6e0dca		4c8bbc2400050000		MOVQ 0x500(SP), R15													
  compile.go:1980	0x6e0dd2		48898424100d0000		MOVQ AX, 0xd10(SP)													
  compile.go:1980	0x6e0dda		488b842478050000		MOVQ 0x578(SP), AX													
  compile.go:1980	0x6e0de2		4889842480050000		MOVQ AX, 0x580(SP)													
  compile.go:1980	0x6e0dea		888c244f030000			MOVB CL, 0x34f(SP)													
  compile.go:1980	0x6e0df1		0fb68c244a030000		MOVZX 0x34a(SP), CX													
  compile.go:1980	0x6e0df9		888c2444030000			MOVB CL, 0x344(SP)													
  compile.go:1980	0x6e0e00		0fb68c244f030000		MOVZX 0x34f(SP), CX													
  compile.go:1980	0x6e0e08		488b8424100d0000		MOVQ 0xd10(SP), AX													
  compile.go:1991	0x6e0e10		e9fffdffff			JMP 0x6e0c14														
  compile.go:1980	0x6e0e15		44889c2445030000		MOVB R11, 0x345(SP)													
  code_buffer.go:156	0x6e0e1d		4c8bac24800a0000		MOVQ 0xa80(SP), R13													
  code_buffer.go:156	0x6e0e25		4d85ed				TESTQ R13, R13														
  code_buffer.go:156	0x6e0e28		7424				JE 0x6e0e4e														
  code_buffer.go:156	0x6e0e2a		41807d2300			CMPB 0x23(R13), $0x0													
  code_buffer.go:156	0x6e0e2f		751d				JNE 0x6e0e4e														
  code_buffer.go:159	0x6e0e31		4d8b7d10			MOVQ 0x10(R13), R15													
  code_buffer.go:159	0x6e0e35		4d8b4518			MOVQ 0x18(R13), R8													
  code_buffer.go:159	0x6e0e39		0f1f8000000000			NOPL 0(AX)														
  code_buffer.go:159	0x6e0e40		4d39c7				CMPQ R15, R8														
  code_buffer.go:159	0x6e0e43		0f8290290000			JB 0x6e37d9														
  compile.go:1997	0x6e0e49		4d89c7				MOVQ R8, R15														
  compile.go:1997	0x6e0e4c		eb03				JMP 0x6e0e51														
  compile.go:1997	0x6e0e4e		4531ff				XORL R15, R15														
  compile.go:1997	0x6e0e51		4c8b8424380e0000		MOVQ 0xe38(SP), R8													
  compile.go:1997	0x6e0e59		4d8b9840010000			MOVQ 0x140(R8), R11													
  compile.go:1997	0x6e0e60		4d39dc				CMPQ R12, R11														
  compile.go:1997	0x6e0e63		0f836b290000			JAE 0x6e37d4														
  compile.go:1980	0x6e0e69		48898424b8070000		MOVQ AX, 0x7b8(SP)													
  compile.go:1997	0x6e0e71		4d8b9838010000			MOVQ 0x138(R8), R11													
  compile.go:1997	0x6e0e78		496bd468			IMULQ $0x68, R12, DX													
  compile.go:1997	0x6e0e7c		4d8b5c1358			MOVQ 0x58(R11)(DX*1), R11												
  compile.go:1997	0x6e0e81		488bb424d8080000		MOVQ 0x8d8(SP), SI													
  compile.go:1997	0x6e0e89		410fb60434			MOVZX 0(R12)(SI*1), AX													
  compile.go:1997	0x6e0e8e		4c8b9424b8050000		MOVQ 0x5b8(SP), R10													
  compile.go:1997	0x6e0e96		4d39e2				CMPQ R10, R12														
  compile.go:1997	0x6e0e99		0f8630290000			JBE 0x6e37cf														
  compile.go:1980	0x6e0e9f		4889bc24c8050000		MOVQ DI, 0x5c8(SP)													
  compile.go:1997	0x6e0ea7		48899424f8050000		MOVQ DX, 0x5f8(SP)													
  compile.go:1980	0x6e0eaf		889c244e030000			MOVB BL, 0x34e(SP)													
  compile.go:1980	0x6e0eb6		888c244d030000			MOVB CL, 0x34d(SP)													
  compile.go:1997	0x6e0ebd		496bd41c			IMULQ $0x1c, R12, DX													
  compile.go:1997	0x6e0ec1		488bb424880a0000		MOVQ 0xa88(SP), SI													
  compile.go:1997	0x6e0ec9		4801f2				ADDQ SI, DX														
  compile.go:1997	0x6e0ecc		48899424e80a0000		MOVQ DX, 0xae8(SP)													
  compile.go:1997	0x6e0ed4		488db424680c0000		LEAQ 0xc68(SP), SI													
  compile.go:1997	0x6e0edc		440f1032			MOVUPS 0(DX), X14													
  compile.go:1997	0x6e0ee0		440f1136			MOVUPS X14, 0(SI)													
  compile.go:1997	0x6e0ee4		440f10720c			MOVUPS 0xc(DX), X14													
  compile.go:1997	0x6e0ee9		440f11760c			MOVUPS X14, 0xc(SI)													
  compile.go:1997	0x6e0eee		4889e2				MOVQ SP, DX														
  compile.go:1997	0x6e0ef1		440f1036			MOVUPS 0(SI), X14													
  compile.go:1997	0x6e0ef5		440f1132			MOVUPS X14, 0(DX)													
  compile.go:1997	0x6e0ef9		440f10760c			MOVUPS 0xc(SI), X14													
  compile.go:1997	0x6e0efe		440f11720c			MOVUPS X14, 0xc(DX)													
  compile.go:1997	0x6e0f03		488d742420			LEAQ 0x20(SP), SI													
  compile.go:1997	0x6e0f08		488dbc24f0070000		LEAQ 0x7f0(SP), DI													
  compile.go:1997	0x6e0f10		440f1037			MOVUPS 0(DI), X14													
  compile.go:1997	0x6e0f14		440f1136			MOVUPS X14, 0(SI)													
  compile.go:1997	0x6e0f18		440f107710			MOVUPS 0x10(DI), X14													
  compile.go:1997	0x6e0f1d		440f117610			MOVUPS X14, 0x10(SI)													
  compile.go:1997	0x6e0f22		440f107720			MOVUPS 0x20(DI), X14													
  compile.go:1997	0x6e0f27		440f117620			MOVUPS X14, 0x20(SI)													
  compile.go:1997	0x6e0f2c		4c89db				MOVQ R11, BX														
  compile.go:1997	0x6e0f2f		89c1				MOVL AX, CX														
  compile.go:1997	0x6e0f31		4c89f8				MOVQ R15, AX														
  compile.go:1997	0x6e0f34		e847c5ffff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.functionStartPadding(SB)				
  compile.go:1997	0x6e0f39		4885c0				TESTQ AX, AX														
  compile.go:1997	0x6e0f3c		750d				JNE 0x6e0f4b														
  code_buffer.go:156	0x6e0f3e		488b8424800a0000		MOVQ 0xa80(SP), AX													
  code_buffer.go:156	0x6e0f46		4885c0				TESTQ AX, AX														
  compile.go:1997	0x6e0f49		eb29				JMP 0x6e0f74														
  compile.go:1998	0x6e0f4b		4889c3				MOVQ AX, BX														
  compile.go:1998	0x6e0f4e		488b8424800a0000		MOVQ 0xa80(SP), AX													
  compile.go:1998	0x6e0f56		e8e5f7fbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).AppendZeros(SB)						
  compile.go:1998	0x6e0f5b		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:1998	0x6e0f60		4885c0				TESTQ AX, AX														
  compile.go:1998	0x6e0f63		0f85fd170000			JNE 0x6e2766														
  code_buffer.go:156	0x6e0f69		488b8424800a0000		MOVQ 0xa80(SP), AX													
  code_buffer.go:156	0x6e0f71		4885c0				TESTQ AX, AX														
  code_buffer.go:156	0x6e0f74		7418				JE 0x6e0f8e														
  code_buffer.go:156	0x6e0f76		80782300			CMPB 0x23(AX), $0x0													
  code_buffer.go:156	0x6e0f7a		7512				JNE 0x6e0f8e														
  code_buffer.go:159	0x6e0f7c		488b4810			MOVQ 0x10(AX), CX													
  code_buffer.go:159	0x6e0f80		488b5018			MOVQ 0x18(AX), DX													
  code_buffer.go:159	0x6e0f84		4839d1				CMPQ CX, DX														
  code_buffer.go:159	0x6e0f87		7307				JAE 0x6e0f90														
  code_buffer.go:159	0x6e0f89		e93c280000			JMP 0x6e37ca														
  code_buffer.go:159	0x6e0f8e		31d2				XORL DX, DX														
  compile.go:2003	0x6e0f90		488b8c24b0050000		MOVQ 0x5b0(SP), CX													
  compile.go:2003	0x6e0f98		488bb42458050000		MOVQ 0x558(SP), SI													
  compile.go:2003	0x6e0fa0		4839f1				CMPQ CX, SI														
  compile.go:2003	0x6e0fa3		0f831c280000			JAE 0x6e37c5														
  compile.go:2003	0x6e0fa9		488bbc24080b0000		MOVQ 0xb08(SP), DI													
  compile.go:2003	0x6e0fb1		488914cf			MOVQ DX, 0(DI)(CX*8)													
  compile.go:2004	0x6e0fb5		4c8b8424380e0000		MOVQ 0xe38(SP), R8													
  compile.go:2004	0x6e0fbd		4d8b8840010000			MOVQ 0x140(R8), R9													
  compile.go:2004	0x6e0fc4		4c39c9				CMPQ CX, R9														
  compile.go:2004	0x6e0fc7		0f83f1270000			JAE 0x6e37be														
  compile.go:2004	0x6e0fcd		4d8b8838010000			MOVQ 0x138(R8), R9													
  compile.go:2004	0x6e0fd4		4c8b9424f8050000		MOVQ 0x5f8(SP), R10													
  compile.go:2004	0x6e0fdc		4b8b5c0a58			MOVQ 0x58(R10)(R9*1), BX												
  compile.go:732	0x6e0fe1		48c1e302			SHLQ $0x2, BX														
  compile.go:732	0x6e0fe5		4883c340			ADDQ $0x40, BX														
  compile.go:733	0x6e0fe9		4883fb7f			CMPQ BX, $0x7f														
  compile.go:733	0x6e0fed		7f07				JG 0x6e0ff6														
  compile.go:733	0x6e0fef		bb80000000			MOVL $0x80, BX														
  compile.go:2004	0x6e0ff4		eb0e				JMP 0x6e1004														
  compile.go:736	0x6e0ff6		4881fb00000100			CMPQ BX, $0x10000													
  compile.go:736	0x6e0ffd		7e05				JLE 0x6e1004														
  compile.go:736	0x6e0fff		bb00000100			MOVL $0x10000, BX													
  finalize.go:103	0x6e1004		803da1c6b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.nativeCompactionDisabled(SB), $0x0		
  finalize.go:103	0x6e100b		7552				JNE 0x6e105f														
  finalize.go:103	0x6e100d		803d97c6b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.nativeCompactionEnabled(SB), $0x0		
  finalize.go:103	0x6e1014		750c				JNE 0x6e1022														
  finalize.go:103	0x6e1016		80bc240808000000		CMPB 0x808(SP), $0x0													
  finalize.go:103	0x6e101e		6690				NOPW															
  compile.go:2005	0x6e1020		743d				JE 0x6e105f														
  finalize.go:132	0x6e1022		440fb78c2410080000		MOVZX 0x810(SP), R9													
  finalize.go:136	0x6e102b		4c8b155ecab300			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.finalizerRel32SiteLimitOverride(SB), R10		
  finalize.go:133	0x6e1032		4d85c9				TESTQ R9, R9														
  finalize.go:134	0x6e1035		41bb00010000			MOVL $0x100, R11													
  finalize.go:134	0x6e103b		4d0f44cb			CMOVE R11, R9														
  finalize.go:136	0x6e103f		4d85d2				TESTQ R10, R10														
  finalize.go:137	0x6e1042		4d0f45ca			CMOVNE R10, R9														
  finalize.go:139	0x6e1046		4981f900080000			CMPQ R9, $0x800														
  finalize.go:139	0x6e104d		41ba00080000			MOVL $0x800, R10													
  finalize.go:139	0x6e1053		4d0f4fca			CMOVG R10, R9														
  compile.go:2006	0x6e1057		4a8d1c8b			LEAQ 0(BX)(R9*4), BX													
  compile.go:2006	0x6e105b		488d5b07			LEAQ 0x7(BX), BX													
  compile.go:2002	0x6e105f		4889942478030000		MOVQ DX, 0x378(SP)													
  compile.go:2008	0x6e1067		4c8d8c24c0070000		LEAQ 0x7c0(SP), R9													
  compile.go:2008	0x6e106f		4c8d9424f0070000		LEAQ 0x7f0(SP), R10													
  compile.go:2008	0x6e1077		450f1032			MOVUPS 0(R10), X14													
  compile.go:2008	0x6e107b		450f1131			MOVUPS X14, 0(R9)													
  compile.go:2008	0x6e107f		450f107210			MOVUPS 0x10(R10), X14													
  compile.go:2008	0x6e1084		450f117110			MOVUPS X14, 0x10(R9)													
  compile.go:2008	0x6e1089		450f107220			MOVUPS 0x20(R10), X14													
  compile.go:2008	0x6e108e		450f117120			MOVUPS X14, 0x20(R9)													
  finalize.go:103	0x6e1093		803d12c6b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.nativeCompactionDisabled(SB), $0x0		
  finalize.go:103	0x6e109a		660f1f440000			NOPW 0(AX)(AX*1)													
  finalize.go:103	0x6e10a0		0f85a6000000			JNE 0x6e114c														
  finalize.go:103	0x6e10a6		803dfec5b30000			CMPB github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.nativeCompactionEnabled(SB), $0x0		
  finalize.go:103	0x6e10ad		750e				JNE 0x6e10bd														
  finalize.go:103	0x6e10af		80bc240808000000		CMPB 0x808(SP), $0x0													
  compile.go:4070	0x6e10b7		0f848f000000			JE 0x6e114c														
  compile.go:4070	0x6e10bd		4c8d9c24680c0000		LEAQ 0xc68(SP), R11													
  compile.go:4070	0x6e10c5		450f1031			MOVUPS 0(R9), X14													
  compile.go:4070	0x6e10c9		450f1133			MOVUPS X14, 0(R11)													
  compile.go:4070	0x6e10cd		450f107110			MOVUPS 0x10(R9), X14													
  compile.go:4070	0x6e10d2		450f117310			MOVUPS X14, 0x10(R11)													
  compile.go:4070	0x6e10d7		450f107120			MOVUPS 0x20(R9), X14													
  compile.go:4070	0x6e10dc		450f117320			MOVUPS X14, 0x20(R11)													
  compile.go:4070	0x6e10e1		440fb60d27acb100		MOVZX github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optLocalSlotOrder+16(SB), R9			
  compile.go:4070	0x6e10e9		4c8b1d10acb100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optLocalSlotOrder(SB), R11			
  compile.go:4070	0x6e10f0		4c8b2511acb100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optLocalSlotOrder+8(SB), R12			
  catalog.go:96		0x6e10f7		4c8bac24680c0000		MOVQ 0xc68(SP), R13													
  policy.go:28		0x6e10ff		4c8dbc2448070000		LEAQ 0x748(SP), R15													
  policy.go:28		0x6e1107		488db424680c0000		LEAQ 0xc68(SP), SI													
  policy.go:28		0x6e110f		440f1036			MOVUPS 0(SI), X14													
  policy.go:28		0x6e1113		450f1137			MOVUPS X14, 0(R15)													
  policy.go:28		0x6e1117		440f107608			MOVUPS 0x8(SI), X14													
  policy.go:28		0x6e111c		450f117708			MOVUPS X14, 0x8(R15)													
  catalog.go:96		0x6e1121		4d85ed				TESTQ R13, R13														
  catalog.go:96		0x6e1124		7426				JE 0x6e114c														
  catalog.go:96		0x6e1126		4d39dd				CMPQ R13, R11														
  catalog.go:96		0x6e1129		7521				JNE 0x6e114c														
  catalog.go:96		0x6e112b		4983f902			CMPQ R9, $0x2														
  catalog.go:96		0x6e112f		0f8384260000			JAE 0x6e37b9														
  catalog.go:96		0x6e1135		4a8bb4cc50070000		MOVQ 0x750(SP)(R9*8), SI												
  catalog.go:96		0x6e113d		0f1f00				NOPL 0(AX)														
  catalog.go:96		0x6e1140		4c85e6				TESTQ R12, SI														
  compile.go:2008	0x6e1143		7407				JE 0x6e114c														
  compile.go:2009	0x6e1145		4881c3f70f0000			ADDQ $0xff7, BX														
  compile.go:2011	0x6e114c		e8affafbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).AppendTail(SB)						
  compile.go:2012	0x6e1151		4885ff				TESTQ DI, DI														
  compile.go:2012	0x6e1154		0f854d150000			JNE 0x6e26a7														
  compile.go:2015	0x6e115a		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2015	0x6e1162		488bb218020000			MOVQ 0x218(DX), SI													
  compile.go:2015	0x6e1169		48895e08			MOVQ BX, 0x8(SI)													
  compile.go:2015	0x6e116d		48894e10			MOVQ CX, 0x10(SI)													
  compile.go:2015	0x6e1171		833d08ceb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:2015	0x6e1178		7412				JE 0x6e118c														
  compile.go:2015	0x6e117a		488b0e				MOVQ 0(SI), CX														
  compile.go:2015	0x6e117d		0f1f00				NOPL 0(AX)														
  compile.go:2015	0x6e1180		e87b3edbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:2015	0x6e1185		498903				MOVQ AX, 0(R11)														
  compile.go:2015	0x6e1188		49894b08			MOVQ CX, 0x8(R11)													
  compile.go:2015	0x6e118c		488906				MOVQ AX, 0(SI)														
  compile.go:2016	0x6e118f		488b8a18020000			MOVQ 0x218(DX), CX													
  compile.go:2016	0x6e1196		440f117928			MOVUPS X15, 0x28(CX)													
  compile.go:2016	0x6e119b		833ddecdb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:2016	0x6e11a2		740c				JE 0x6e11b0														
  compile.go:2016	0x6e11a4		488b5920			MOVQ 0x20(CX), BX													
  compile.go:2016	0x6e11a8		e8333edbff			CALL runtime.gcWriteBarrier1(SB)											
  compile.go:2016	0x6e11ad		49891b				MOVQ BX, 0(R11)														
  compile.go:2016	0x6e11b0		48c7412000000000		MOVQ $0x0, 0x20(CX)													
  compile.go:2017	0x6e11b8		c6822202000000			MOVB $0x0, 0x222(DX)													
  compile.go:2018	0x6e11bf		440f11ba10100000		MOVUPS X15, 0x1010(DX)													
  compile.go:2018	0x6e11c7		833db2cdb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:2018	0x6e11ce		740f				JE 0x6e11df														
  compile.go:2018	0x6e11d0		488b8a08100000			MOVQ 0x1008(DX), CX													
  compile.go:2018	0x6e11d7		e8043edbff			CALL runtime.gcWriteBarrier1(SB)											
  compile.go:2018	0x6e11dc		49890b				MOVQ CX, 0(R11)														
  compile.go:2018	0x6e11df		48c7820810000000000000		MOVQ $0x0, 0x1008(DX)													
  compile.go:2019	0x6e11ea		c6822302000000			MOVB $0x0, 0x223(DX)													
  compile.go:2020	0x6e11f1		488d8c24680c0000		LEAQ 0xc68(SP), CX													
  compile.go:2020	0x6e11f9		488b9424e80a0000		MOVQ 0xae8(SP), DX													
  compile.go:2020	0x6e1201		440f1032			MOVUPS 0(DX), X14													
  compile.go:2020	0x6e1205		440f1131			MOVUPS X14, 0(CX)													
  compile.go:2020	0x6e1209		440f10720c			MOVUPS 0xc(DX), X14													
  compile.go:2020	0x6e120e		440f11710c			MOVUPS X14, 0xc(CX)													
  compile.go:2020	0x6e1213		4889e2				MOVQ SP, DX														
  compile.go:2020	0x6e1216		488d9c2490090000		LEAQ 0x990(SP), BX													
  compile.go:2020	0x6e121e		440f1033			MOVUPS 0(BX), X14													
  compile.go:2020	0x6e1222		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2020	0x6e1226		440f107310			MOVUPS 0x10(BX), X14													
  compile.go:2020	0x6e122b		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2020	0x6e1230		440f107320			MOVUPS 0x20(BX), X14													
  compile.go:2020	0x6e1235		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2020	0x6e123a		440f107330			MOVUPS 0x30(BX), X14													
  compile.go:2020	0x6e123f		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2020	0x6e1244		440f107340			MOVUPS 0x40(BX), X14													
  compile.go:2020	0x6e1249		440f117240			MOVUPS X14, 0x40(DX)													
  compile.go:2020	0x6e124e		440f107350			MOVUPS 0x50(BX), X14													
  compile.go:2020	0x6e1253		440f117250			MOVUPS X14, 0x50(DX)													
  compile.go:2020	0x6e1258		440f107360			MOVUPS 0x60(BX), X14													
  compile.go:2020	0x6e125d		440f117260			MOVUPS X14, 0x60(DX)													
  compile.go:2020	0x6e1262		440f107370			MOVUPS 0x70(BX), X14													
  compile.go:2020	0x6e1267		440f117270			MOVUPS X14, 0x70(DX)													
  compile.go:2020	0x6e126c		440f10b380000000		MOVUPS 0x80(BX), X14													
  compile.go:2020	0x6e1274		440f11b280000000		MOVUPS X14, 0x80(DX)													
  compile.go:2020	0x6e127c		488d9c2490000000		LEAQ 0x90(SP), BX													
  compile.go:2020	0x6e1284		440f1031			MOVUPS 0(CX), X14													
  compile.go:2020	0x6e1288		440f1133			MOVUPS X14, 0(BX)													
  compile.go:2020	0x6e128c		440f10710c			MOVUPS 0xc(CX), X14													
  compile.go:2020	0x6e1291		440f11730c			MOVUPS X14, 0xc(BX)													
  compile.go:2020	0x6e1296		488b8424b0050000		MOVQ 0x5b0(SP), AX													
  compile.go:2020	0x6e129e		6690				NOPW															
  compile.go:2020	0x6e12a0		e8db130600			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.funcHintSidecar.viewAt(SB)			
  compile.go:2020	0x6e12a5		488d8c24e0080000		LEAQ 0x8e0(SP), CX													
  compile.go:2020	0x6e12ad		488d9424b0000000		LEAQ 0xb0(SP), DX													
  compile.go:2020	0x6e12b5		440f1032			MOVUPS 0(DX), X14													
  compile.go:2020	0x6e12b9		440f1131			MOVUPS X14, 0(CX)													
  compile.go:2020	0x6e12bd		440f107210			MOVUPS 0x10(DX), X14													
  compile.go:2020	0x6e12c2		440f117110			MOVUPS X14, 0x10(CX)													
  compile.go:2020	0x6e12c7		440f107220			MOVUPS 0x20(DX), X14													
  compile.go:2020	0x6e12cc		440f117120			MOVUPS X14, 0x20(CX)													
  compile.go:2020	0x6e12d1		440f107230			MOVUPS 0x30(DX), X14													
  compile.go:2020	0x6e12d6		440f117130			MOVUPS X14, 0x30(CX)													
  compile.go:2020	0x6e12db		440f107240			MOVUPS 0x40(DX), X14													
  compile.go:2020	0x6e12e0		440f117140			MOVUPS X14, 0x40(CX)													
  compile.go:2020	0x6e12e5		440f107250			MOVUPS 0x50(DX), X14													
  compile.go:2020	0x6e12ea		440f117150			MOVUPS X14, 0x50(CX)													
  compile.go:2020	0x6e12ef		440f107260			MOVUPS 0x60(DX), X14													
  compile.go:2020	0x6e12f4		440f117160			MOVUPS X14, 0x60(CX)													
  compile.go:2020	0x6e12f9		440f107270			MOVUPS 0x70(DX), X14													
  compile.go:2020	0x6e12fe		440f117170			MOVUPS X14, 0x70(CX)													
  compile.go:2020	0x6e1303		440f10b280000000		MOVUPS 0x80(DX), X14													
  compile.go:2020	0x6e130b		440f11b180000000		MOVUPS X14, 0x80(CX)													
  compile.go:2020	0x6e1313		440f10b290000000		MOVUPS 0x90(DX), X14													
  compile.go:2020	0x6e131b		440f11b190000000		MOVUPS X14, 0x90(CX)													
  compile.go:2020	0x6e1323		440f10b2a0000000		MOVUPS 0xa0(DX), X14													
  compile.go:2020	0x6e132b		440f11b1a0000000		MOVUPS X14, 0xa0(CX)													
  compile.go:2021	0x6e1333		488b9424c00d0000		MOVQ 0xdc0(SP), DX													
  compile.go:2021	0x6e133b		0f1f440000			NOPL 0(AX)(AX*1)													
  gc_frame_roots.go:508	0x6e1340		4885d2				TESTQ DX, DX														
  gc_frame_roots.go:508	0x6e1343		743d				JE 0x6e1382														
  gc_frame_roots.go:508	0x6e1345		488bb424b0050000		MOVQ 0x5b0(SP), SI													
  gc_frame_roots.go:508	0x6e134d		48397208			CMPQ 0x8(DX), SI													
  gc_frame_roots.go:508	0x6e1351		7e37				JLE 0x6e138a														
  gc_frame_roots.go:508	0x6e1353		4c8b22				MOVQ 0(DX), R12														
  gc_frame_roots.go:511	0x6e1356		458b24b4			MOVL 0(R12)(SI*4), R12													
  gc_frame_roots.go:512	0x6e135a		4585e4				TESTL R12, R12														
  gc_frame_roots.go:512	0x6e135d		7407				JE 0x6e1366														
  gc_frame_roots.go:512	0x6e135f		90				NOPL															
  gc_frame_roots.go:512	0x6e1360		4c396220			CMPQ 0x20(DX), R12													
  gc_frame_roots.go:512	0x6e1364		7304				JAE 0x6e136a														
  gc_frame_roots.go:512	0x6e1366		31d2				XORL DX, DX														
  compile.go:2021	0x6e1368		eb22				JMP 0x6e138c														
  gc_frame_roots.go:512	0x6e136a		488b5218			MOVQ 0x18(DX), DX													
  gc_frame_roots.go:515	0x6e136e		41ffcc				DECL R12														
  gc_frame_roots.go:515	0x6e1371		4589e5				MOVL R12, R13														
  gc_frame_roots.go:515	0x6e1374		49c1e407			SHLQ $0x7, R12														
  gc_frame_roots.go:515	0x6e1378		4f8d24ec			LEAQ 0(R12)(R13*8), R12													
  gc_frame_roots.go:515	0x6e137c		4c01e2				ADDQ R12, DX														
  gc_frame_roots.go:515	0x6e137f		90				NOPL															
  compile.go:2021	0x6e1380		eb0a				JMP 0x6e138c														
  compile.go:2021	0x6e1382		488bb424b0050000		MOVQ 0x5b0(SP), SI													
  gc_frame_roots.go:508	0x6e138a		31d2				XORL DX, DX														
  compile.go:2021	0x6e138c		488b9c24080e0000		MOVQ 0xe08(SP), BX													
  compile.go:2021	0x6e1394		48899c24e00a0000		MOVQ BX, 0xae0(SP)													
  compile.go:2021	0x6e139c		4c8ba424100e0000		MOVQ 0xe10(SP), R12													
  compile.go:2021	0x6e13a4		4c89a424f8050000		MOVQ R12, 0x5f8(SP)													
  compile.go:2021	0x6e13ac		488bbc24180e0000		MOVQ 0xe18(SP), DI													
  compile.go:2021	0x6e13b4		4889bc24f0050000		MOVQ DI, 0x5f0(SP)													
  compile.go:2021	0x6e13bc		4c8bac24d8080000		MOVQ 0x8d8(SP), R13													
  compile.go:2021	0x6e13c4		460fb6042e			MOVZX 0(SI)(R13*1), R8													
  compile.go:2021	0x6e13c9		440fb69c24a00d0000		MOVZX 0xda0(SP), R11													
  compile.go:2021	0x6e13d2		4c8bac24780d0000		MOVQ 0xd78(SP), R13													
  compile.go:2021	0x6e13da		4c8bbc24800d0000		MOVQ 0xd80(SP), R15													
  compile.go:2021	0x6e13e2		488b8424880d0000		MOVQ 0xd88(SP), AX													
  compile.go:2021	0x6e13ea		440fb68c24900d0000		MOVZX 0xd90(SP), R9													
  compile.go:2021	0x6e13f3		4c8b9424980d0000		MOVQ 0xd98(SP), R10													
  compile.go:2021	0x6e13fb		0fb69c24b80d0000		MOVZX 0xdb8(SP), BX													
  compile.go:2021	0x6e1403		0fb7b424b90d0000		MOVZX 0xdb9(SP), SI													
  compile.go:2021	0x6e140b		488bbc24300e0000		MOVQ 0xe30(SP), DI													
  compile.go:2021	0x6e1413		440fb6a42446030000		MOVZX 0x346(SP), R12													
  compile.go:2021	0x6e141c		44882424			MOVB R12, 0(SP)														
  compile.go:2021	0x6e1420		4c8ba42470080000		MOVQ 0x870(SP), R12													
  compile.go:2021	0x6e1428		4c89642408			MOVQ R12, 0x8(SP)													
  compile.go:2021	0x6e142d		4c8ba424f0040000		MOVQ 0x4f0(SP), R12													
  compile.go:2021	0x6e1435		4c89642410			MOVQ R12, 0x10(SP)													
  compile.go:2021	0x6e143a		4c8ba424f8040000		MOVQ 0x4f8(SP), R12													
  compile.go:2021	0x6e1442		4c89642418			MOVQ R12, 0x18(SP)													
  compile.go:2021	0x6e1447		48894c2420			MOVQ CX, 0x20(SP)													
  compile.go:2021	0x6e144c		4c8ba424d0080000		MOVQ 0x8d0(SP), R12													
  compile.go:2021	0x6e1454		4c89642428			MOVQ R12, 0x28(SP)													
  compile.go:2021	0x6e1459		4c8ba42410060000		MOVQ 0x610(SP), R12													
  compile.go:2021	0x6e1461		4c89642430			MOVQ R12, 0x30(SP)													
  compile.go:2021	0x6e1466		4c8ba42418060000		MOVQ 0x618(SP), R12													
  compile.go:2021	0x6e146e		4c89642438			MOVQ R12, 0x38(SP)													
  compile.go:2021	0x6e1473		4c896c2440			MOVQ R13, 0x40(SP)													
  compile.go:2021	0x6e1478		4c897c2448			MOVQ R15, 0x48(SP)													
  compile.go:2021	0x6e147d		4889442450			MOVQ AX, 0x50(SP)													
  compile.go:2021	0x6e1482		44884c2458			MOVB R9, 0x58(SP)													
  compile.go:2021	0x6e1487		4c89542460			MOVQ R10, 0x60(SP)													
  compile.go:2021	0x6e148c		885c2468			MOVB BL, 0x68(SP)													
  compile.go:2021	0x6e1490		6689742469			MOVW SI, 0x69(SP)													
  compile.go:2021	0x6e1495		48897c2470			MOVQ DI, 0x70(SP)													
  compile.go:2021	0x6e149a		4889542478			MOVQ DX, 0x78(SP)													
  compile.go:2021	0x6e149f		48c784248000000000000000	MOVQ $0x0, 0x80(SP)													
  compile.go:2021	0x6e14ab		488d942488000000		LEAQ 0x88(SP), DX													
  compile.go:2021	0x6e14b3		4c8da42490080000		LEAQ 0x890(SP), R12													
  compile.go:2021	0x6e14bb		450f103424			MOVUPS 0(R12), X14													
  compile.go:2021	0x6e14c0		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2021	0x6e14c4		450f10742410			MOVUPS 0x10(R12), X14													
  compile.go:2021	0x6e14ca		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2021	0x6e14cf		450f10742420			MOVUPS 0x20(R12), X14													
  compile.go:2021	0x6e14d5		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2021	0x6e14da		450f10742430			MOVUPS 0x30(R12), X14													
  compile.go:2021	0x6e14e0		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2021	0x6e14e5		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2021	0x6e14ed		48899424c8000000		MOVQ DX, 0xc8(SP)													
  compile.go:2021	0x6e14f5		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:2021	0x6e14fd		488b9c24e00a0000		MOVQ 0xae0(SP), BX													
  compile.go:2021	0x6e1505		488b8c24f8050000		MOVQ 0x5f8(SP), CX													
  compile.go:2021	0x6e150d		488bbc24f0050000		MOVQ 0x5f0(SP), DI													
  compile.go:2021	0x6e1515		488bb424b0050000		MOVQ 0x5b0(SP), SI													
  compile.go:2021	0x6e151d		440fb68c2448030000		MOVZX 0x348(SP), R9													
  compile.go:2021	0x6e1526		440fb6942449030000		MOVZX 0x349(SP), R10													
  compile.go:2021	0x6e152f		e82ca60000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.compileFunc(SB)					
  compile.go:2022	0x6e1534		4d85d2				TESTQ R10, R10														
  compile.go:2022	0x6e1537		0f855d100000			JNE 0x6e259a														
  compile.go:1980	0x6e153d		0fb694244a030000		MOVZX 0x34a(SP), DX													
  compile.go:1980	0x6e1545		84d2				TESTL DL, DL														
  compile.go:2025	0x6e1547		7410				JE 0x6e1559														
  compile.go:2026	0x6e1549		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2026	0x6e1551		41b801000000			MOVL $0x1, R8														
  compile.go:2025	0x6e1557		eb14				JMP 0x6e156d														
  compile.go:2025	0x6e1559		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2025	0x6e1561		4c8b8218020000			MOVQ 0x218(DX), R8													
  compile.go:2025	0x6e1568		450fb64044			MOVZX 0x44(R8), R8													
  compile.go:2026	0x6e156d		4c8b9218020000			MOVQ 0x218(DX), R10													
  compile.go:2026	0x6e1574		450fb65245			MOVZX 0x45(R10), R10													
  compile.go:2026	0x6e1579		41c0ea04			SHRL $0x4, R10														
  compile.go:2027	0x6e157d		448b9afc010000			MOVL 0x1fc(DX), R11													
  compile.go:2026	0x6e1584		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:2026	0x6e158d		4509d4				ORL R10, R12														
  compile.go:2027	0x6e1590		448b942464030000		MOVL 0x364(SP), R10													
  compile.go:2027	0x6e1598		4509da				ORL R11, R10														
  compile.go:2028	0x6e159b		4c8b9c2478030000		MOVQ 0x378(SP), R11													
  compile.go:2028	0x6e15a3		4d01d9				ADDQ R11, R9														
  compile.go:2028	0x6e15a6		4c8b9c24b0050000		MOVQ 0x5b0(SP), R11													
  compile.go:2028	0x6e15ae		4c8bac2420050000		MOVQ 0x520(SP), R13													
  compile.go:2028	0x6e15b6		4d39eb				CMPQ R11, R13														
  compile.go:2028	0x6e15b9		0f83f5210000			JAE 0x6e37b4														
  compile.go:2026	0x6e15bf		4488a42443030000		MOVB R12, 0x343(SP)													
  compile.go:2027	0x6e15c7		4489942460030000		MOVL R10, 0x360(SP)													
  compile.go:2021	0x6e15cf		48898424280a0000		MOVQ AX, 0xa28(SP)													
  compile.go:2021	0x6e15d7		4889b424b0040000		MOVQ SI, 0x4b0(SP)													
  compile.go:2021	0x6e15df		4889bc24a8070000		MOVQ DI, 0x7a8(SP)													
  compile.go:2021	0x6e15e7		48898c2448050000		MOVQ CX, 0x548(SP)													
  compile.go:2021	0x6e15ef		48899c2440050000		MOVQ BX, 0x540(SP)													
  compile.go:2025	0x6e15f7		4488842444030000		MOVB R8, 0x344(SP)													
  compile.go:2028	0x6e15ff		4c8bbc2488080000		MOVQ 0x888(SP), R15													
  compile.go:2028	0x6e1607		4f890cdf			MOVQ R9, 0(R15)(R11*8)													
  compile.go:2029	0x6e160b		4c8b8c24980a0000		MOVQ 0xa98(SP), R9													
  compile.go:2029	0x6e1613		4d85c9				TESTQ R9, R9														
  compile.go:2029	0x6e1616		0f84df010000			JE 0x6e17fb														
  compile.go:2029	0x6e161c		4c8baa30090000			MOVQ 0x930(DX), R13													
  compile.go:2029	0x6e1623		4d85ed				TESTQ R13, R13														
  compile.go:2029	0x6e1626		0f84ac010000			JE 0x6e17d8														
  adapter_tails.go:24	0x6e162c		80ba4009000000			CMPB 0x940(DX), $0x0													
  adapter_tails.go:24	0x6e1633		7518				JNE 0x6e164d														
  adapter_tails.go:24	0x6e1635		4c8bba38090000			MOVQ 0x938(DX), R15													
  adapter_tails.go:24	0x6e163c		0f1f4000			NOPL 0(AX)														
  adapter_tails.go:24	0x6e1640		4d39ef				CMPQ R15, R13														
  adapter_tails.go:24	0x6e1643		7f1d				JG 0x6e1662														
  compile.go:2082	0x6e1645		4c8bbc2488080000		MOVQ 0x888(SP), R15													
  adapter_tails.go:24	0x6e164d		4531ed				XORL R13, R13														
  compile.go:2030	0x6e1650		4531ed				XORL R13, R13														
  compile.go:2030	0x6e1653		4489ac2458030000		MOVL R13, 0x358(SP)													
  compile.go:2030	0x6e165b		4531ed				XORL R13, R13														
  compile.go:2030	0x6e165e		6690				NOPW															
  compile.go:2030	0x6e1660		eb10				JMP 0x6e1672														
  compile.go:2030	0x6e1662		4489bc2458030000		MOVL R15, 0x358(SP)													
  compile.go:2082	0x6e166a		4c8bbc2488080000		MOVQ 0x888(SP), R15													
  compile.go:2030	0x6e1672		4585ed				TESTL R13, R13														
  compile.go:2030	0x6e1675		0f843a010000			JE 0x6e17b5														
  compile.go:2032	0x6e167b		4c8bbc24d8050000		MOVQ 0x5d8(SP), R15													
  compile.go:2032	0x6e1683		4d8d4701			LEAQ 0x1(R15), R8													
  compile.go:2032	0x6e1687		4c8b9424e0050000		MOVQ 0x5e0(SP), R10													
  compile.go:2032	0x6e168f		4d39c2				CMPQ R10, R8														
  compile.go:2032	0x6e1692		7211				JB 0x6e16a5														
  compile.go:2032	0x6e1694		440fb6bc244e030000		MOVZX 0x34e(SP), R15													
  compile.go:2032	0x6e169d		0f1f00				NOPL 0(AX)														
  compile.go:2032	0x6e16a0		e9b2000000			JMP 0x6e1757														
  compile.go:2030	0x6e16a5		4489ac2450030000		MOVL R13, 0x350(SP)													
  compile.go:2032	0x6e16ad		4983f802			CMPQ R8, $0x2														
  compile.go:2032	0x6e16b1		7f36				JG 0x6e16e9														
  compile.go:1980	0x6e16b3		440fb6a4244e030000		MOVZX 0x34e(SP), R12													
  compile.go:1980	0x6e16bc		0f1f4000			NOPL 0(AX)														
  compile.go:1980	0x6e16c0		4584e4				TESTL R12, R12														
  compile.go:2032	0x6e16c3		7524				JNE 0x6e16e9														
  compile.go:2032	0x6e16c5		4d85ff				TESTQ R15, R15														
  compile.go:2032	0x6e16c8		751f				JNE 0x6e16e9														
  compile.go:2032	0x6e16ca		4c8d8c2440060000		LEAQ 0x640(SP), R9													
  compile.go:2032	0x6e16d2		450f1139			MOVUPS X15, 0(R9)													
  compile.go:2032	0x6e16d6		450f117910			MOVUPS X15, 0x10(R9)													
  compile.go:2032	0x6e16db		41ba02000000			MOVL $0x2, R10														
  compile.go:2032	0x6e16e1		41bf01000000			MOVL $0x1, R15														
  compile.go:2032	0x6e16e7		eb6e				JMP 0x6e1757														
  compile.go:2032	0x6e16e9		4c89c8				MOVQ R9, AX														
  compile.go:2032	0x6e16ec		4c89c3				MOVQ R8, BX														
  compile.go:2032	0x6e16ef		4c89d1				MOVQ R10, CX														
  compile.go:2032	0x6e16f2		bf01000000			MOVL $0x1, DI														
  compile.go:2032	0x6e16f7		488d35ba34aa00			LEAQ 0xaa34ba(IP), SI													
  compile.go:2032	0x6e16fe		6690				NOPW															
  compile.go:2032	0x6e1700		e83bebdaff			CALL runtime.growslice(SB)												
  shared_adapters.go:30	0x6e1705		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2048	0x6e170d		488bb424b0040000		MOVQ 0x4b0(SP), SI													
  compile.go:2048	0x6e1715		488bbc24a8070000		MOVQ 0x7a8(SP), DI													
  compile.go:2032	0x6e171d		4c8b9c24b0050000		MOVQ 0x5b0(SP), R11													
  compile.go:2032	0x6e1725		448bac2450030000		MOVL 0x350(SP), R13													
  compile.go:2032	0x6e172d		4989c1				MOVQ AX, R9														
  compile.go:2032	0x6e1730		4989d8				MOVQ BX, R8														
  compile.go:2032	0x6e1733		4989ca				MOVQ CX, R10														
  compile.go:2032	0x6e1736		440fb6bc244e030000		MOVZX 0x34e(SP), R15													
  compile.go:2058	0x6e173f		488b8424280a0000		MOVQ 0xa28(SP), AX													
  compile.go:2058	0x6e1747		488b8c2448050000		MOVQ 0x548(SP), CX													
  compile.go:2058	0x6e174f		488b9c2440050000		MOVQ 0x540(SP), BX													
  compile.go:2032	0x6e1757		4d8d60ff			LEAQ -0x1(R8), R12													
  compile.go:2032	0x6e175b		49c1e404			SHLQ $0x4, R12														
  compile.go:2032	0x6e175f		47891c21			MOVL R11, 0(R9)(R12*1)													
  compile.go:2032	0x6e1763		47896c2104			MOVL R13, 0x4(R9)(R12*1)												
  compile.go:2032	0x6e1768		448bac2458030000		MOVL 0x358(SP), R13													
  compile.go:2032	0x6e1770		47896c2108			MOVL R13, 0x8(R9)(R12*1)												
  compile.go:2032	0x6e1775		43c744210c00000000		MOVL $0x0, 0xc(R9)(R12*1)												
  compile.go:2032	0x6e177e		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:2032	0x6e1787		4d89d5				MOVQ R10, R13														
  compile.go:2032	0x6e178a		4c898424d8050000		MOVQ R8, 0x5d8(SP)													
  compile.go:2032	0x6e1792		4488bc244c030000		MOVB R15, 0x34c(SP)													
  compile.go:2032	0x6e179a		440fb6842444030000		MOVZX 0x344(SP), R8													
  compile.go:2032	0x6e17a3		448b942460030000		MOVL 0x360(SP), R10													
  compile.go:2082	0x6e17ab		4c8bbc2488080000		MOVQ 0x888(SP), R15													
  compile.go:2032	0x6e17b3		eb6d				JMP 0x6e1822														
  compile.go:2032	0x6e17b5		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:2032	0x6e17bd		440fb6ac244e030000		MOVZX 0x34e(SP), R13													
  compile.go:2032	0x6e17c6		4488ac244c030000		MOVB R13, 0x34c(SP)													
  compile.go:2032	0x6e17ce		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:2030	0x6e17d6		eb4a				JMP 0x6e1822														
  compile.go:2030	0x6e17d8		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:2030	0x6e17e0		440fb6ac244e030000		MOVZX 0x34e(SP), R13													
  compile.go:2030	0x6e17e9		4488ac244c030000		MOVB R13, 0x34c(SP)													
  compile.go:2030	0x6e17f1		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:2029	0x6e17f9		eb27				JMP 0x6e1822														
  compile.go:2029	0x6e17fb		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:2021	0x6e1803		48898424c80a0000		MOVQ AX, 0xac8(SP)													
  compile.go:2021	0x6e180b		0fb684244e030000		MOVZX 0x34e(SP), AX													
  compile.go:2021	0x6e1813		8884244c030000			MOVB AL, 0x34c(SP)													
  compile.go:2058	0x6e181a		488b8424c80a0000		MOVQ 0xac8(SP), AX													
  compile.go:2058	0x6e1822		4c89ac24e0050000		MOVQ R13, 0x5e0(SP)													
  compile.go:2058	0x6e182a		4c898c24980a0000		MOVQ R9, 0xa98(SP)													
  compile.go:2035	0x6e1832		4c8bbc24900a0000		MOVQ 0xa90(SP), R15													
  compile.go:2035	0x6e183a		660f1f440000			NOPW 0(AX)(AX*1)													
  compile.go:2035	0x6e1840		4d85ff				TESTQ R15, R15														
  compile.go:2035	0x6e1843		0f84fe010000			JE 0x6e1a47														
  shared_adapters.go:30	0x6e1849		80ba8806000000			CMPB 0x688(DX), $0x0													
  shared_adapters.go:30	0x6e1850		753e				JNE 0x6e1890														
  shared_adapters.go:30	0x6e1852		80ba4009000000			CMPB 0x940(DX), $0x0													
  shared_adapters.go:30	0x6e1859		7535				JNE 0x6e1890														
  shared_adapters.go:30	0x6e185b		4c8b8230090000			MOVQ 0x930(DX), R8													
  shared_adapters.go:30	0x6e1862		4983f805			CMPQ R8, $0x5														
  shared_adapters.go:30	0x6e1866		7d0b				JGE 0x6e1873														
  shared_adapters.go:30	0x6e1868		440fb6842444030000		MOVZX 0x344(SP), R8													
  shared_adapters.go:30	0x6e1871		eb1d				JMP 0x6e1890														
  shared_adapters.go:30	0x6e1873		4c8b8a38090000			MOVQ 0x938(DX), R9													
  shared_adapters.go:30	0x6e187a		4d39c1				CMPQ R9, R8														
  shared_adapters.go:30	0x6e187d		7f35				JG 0x6e18b4														
  shared_adapters.go:30	0x6e187f		440fb6842444030000		MOVZX 0x344(SP), R8													
  shared_adapters.go:30	0x6e1888		4c8b8c24980a0000		MOVQ 0xa98(SP), R9													
  compile.go:2021	0x6e1890		48898424c00a0000		MOVQ AX, 0xac0(SP)													
  compile.go:2036	0x6e1898		31c0				XORL AX, AX														
  compile.go:2036	0x6e189a		89842454030000			MOVL AX, 0x354(SP)													
  compile.go:2036	0x6e18a1		31c0				XORL AX, AX														
  compile.go:2036	0x6e18a3		8984245c030000			MOVL AX, 0x35c(SP)													
  compile.go:2058	0x6e18aa		488b8424c00a0000		MOVQ 0xac0(SP), AX													
  compile.go:2036	0x6e18b2		eb1c				JMP 0x6e18d0														
  shared_adapters.go:33	0x6e18b4		4983c0fc			ADDQ $-0x4, R8														
  compile.go:2036	0x6e18b8		44898c2454030000		MOVL R9, 0x354(SP)													
  compile.go:2036	0x6e18c0		448984245c030000		MOVL R8, 0x35c(SP)													
  compile.go:2036	0x6e18c8		4c8b8c24980a0000		MOVQ 0xa98(SP), R9													
  compile.go:2036	0x6e18d0		448b842454030000		MOVL 0x354(SP), R8													
  compile.go:2036	0x6e18d8		0f1f840000000000		NOPL 0(AX)(AX*1)													
  compile.go:2036	0x6e18e0		4585c0				TESTL R8, R8														
  compile.go:2036	0x6e18e3		0f843b010000			JE 0x6e1a24														
  compile.go:2038	0x6e18e9		4c8b8c24c8050000		MOVQ 0x5c8(SP), R9													
  compile.go:2038	0x6e18f1		4d8d5101			LEAQ 0x1(R9), R10													
  compile.go:2038	0x6e18f5		4c8ba424d0050000		MOVQ 0x5d0(SP), R12													
  compile.go:2038	0x6e18fd		0f1f00				NOPL 0(AX)														
  compile.go:2038	0x6e1900		4d39d4				CMPQ R12, R10														
  compile.go:2038	0x6e1903		720e				JB 0x6e1913														
  compile.go:2038	0x6e1905		440fb68c244d030000		MOVZX 0x34d(SP), R9													
  compile.go:2038	0x6e190e		e9ac000000			JMP 0x6e19bf														
  compile.go:2038	0x6e1913		4983fa02			CMPQ R10, $0x2														
  compile.go:2038	0x6e1917		7f3a				JG 0x6e1953														
  compile.go:1980	0x6e1919		440fb6ac244d030000		MOVZX 0x34d(SP), R13													
  compile.go:1980	0x6e1922		4584ed				TESTL R13, R13														
  compile.go:2038	0x6e1925		752c				JNE 0x6e1953														
  compile.go:2038	0x6e1927		4d85c9				TESTQ R9, R9														
  compile.go:2038	0x6e192a		7527				JNE 0x6e1953														
  compile.go:2038	0x6e192c		4c8d8c2420060000		LEAQ 0x620(SP), R9													
  compile.go:2038	0x6e1934		450f1139			MOVUPS X15, 0(R9)													
  compile.go:2038	0x6e1938		450f117910			MOVUPS X15, 0x10(R9)													
  compile.go:2038	0x6e193d		4c8dbc2420060000		LEAQ 0x620(SP), R15													
  compile.go:2038	0x6e1945		41bc02000000			MOVL $0x2, R12														
  compile.go:2038	0x6e194b		41b901000000			MOVL $0x1, R9														
  compile.go:2038	0x6e1951		eb6c				JMP 0x6e19bf														
  compile.go:2038	0x6e1953		4c89f8				MOVQ R15, AX														
  compile.go:2038	0x6e1956		4c89d3				MOVQ R10, BX														
  compile.go:2038	0x6e1959		4c89e1				MOVQ R12, CX														
  compile.go:2038	0x6e195c		bf01000000			MOVL $0x1, DI														
  compile.go:2038	0x6e1961		488d351033aa00			LEAQ 0xaa3310(IP), SI													
  compile.go:2038	0x6e1968		e8d3e8daff			CALL runtime.growslice(SB)												
  compile.go:2041	0x6e196d		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2048	0x6e1975		488bb424b0040000		MOVQ 0x4b0(SP), SI													
  compile.go:2048	0x6e197d		488bbc24a8070000		MOVQ 0x7a8(SP), DI													
  compile.go:2038	0x6e1985		448b842454030000		MOVL 0x354(SP), R8													
  compile.go:2038	0x6e198d		4c8b9c24b0050000		MOVQ 0x5b0(SP), R11													
  compile.go:2038	0x6e1995		4989c7				MOVQ AX, R15														
  compile.go:2038	0x6e1998		4989da				MOVQ BX, R10														
  compile.go:2038	0x6e199b		4989cc				MOVQ CX, R12														
  compile.go:2038	0x6e199e		440fb68c244d030000		MOVZX 0x34d(SP), R9													
  compile.go:2058	0x6e19a7		488b8424280a0000		MOVQ 0xa28(SP), AX													
  compile.go:2058	0x6e19af		488b8c2448050000		MOVQ 0x548(SP), CX													
  compile.go:2058	0x6e19b7		488b9c2440050000		MOVQ 0x540(SP), BX													
  compile.go:2038	0x6e19bf		4d8d6aff			LEAQ -0x1(R10), R13													
  compile.go:2038	0x6e19c3		49c1e504			SHLQ $0x4, R13														
  compile.go:2038	0x6e19c7		47891c2f			MOVL R11, 0(R15)(R13*1)													
  compile.go:2038	0x6e19cb		448b9c245c030000		MOVL 0x35c(SP), R11													
  compile.go:2038	0x6e19d3		47895c2f04			MOVL R11, 0x4(R15)(R13*1)												
  compile.go:2038	0x6e19d8		4789442f08			MOVL R8, 0x8(R15)(R13*1)												
  compile.go:2038	0x6e19dd		43c7442f0c00000000		MOVL $0x0, 0xc(R15)(R13*1)												
  compile.go:1208	0x6e19e6		4c8b9c24b0050000		MOVQ 0x5b0(SP), R11													
  compile.go:1208	0x6e19ee		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:2038	0x6e19f6		4d89d0				MOVQ R10, R8														
  compile.go:2038	0x6e19f9		4c89a424d0050000		MOVQ R12, 0x5d0(SP)													
  compile.go:2038	0x6e1a01		44888c244b030000		MOVB R9, 0x34b(SP)													
  compile.go:2038	0x6e1a09		4c8b8c24980a0000		MOVQ 0xa98(SP), R9													
  compile.go:2038	0x6e1a11		448b942460030000		MOVL 0x360(SP), R10													
  compile.go:2038	0x6e1a19		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:2038	0x6e1a22		eb4a				JMP 0x6e1a6e														
  compile.go:2038	0x6e1a24		4c8b8424c8050000		MOVQ 0x5c8(SP), R8													
  compile.go:2038	0x6e1a2c		440fb684244d030000		MOVZX 0x34d(SP), R8													
  compile.go:2038	0x6e1a35		448884244b030000		MOVB R8, 0x34b(SP)													
  compile.go:2038	0x6e1a3d		4c8b8424c8050000		MOVQ 0x5c8(SP), R8													
  compile.go:2036	0x6e1a45		eb27				JMP 0x6e1a6e														
  compile.go:2036	0x6e1a47		4c8b8424c8050000		MOVQ 0x5c8(SP), R8													
  compile.go:2021	0x6e1a4f		48898424b80a0000		MOVQ AX, 0xab8(SP)													
  compile.go:2021	0x6e1a57		0fb684244d030000		MOVZX 0x34d(SP), AX													
  compile.go:2021	0x6e1a5f		8884244b030000			MOVB AL, 0x34b(SP)													
  compile.go:2058	0x6e1a66		488b8424b80a0000		MOVQ 0xab8(SP), AX													
  compile.go:2058	0x6e1a6e		4c898424f8050000		MOVQ R8, 0x5f8(SP)													
  compile.go:2058	0x6e1a76		4c89bc24900a0000		MOVQ R15, 0xa90(SP)													
  compile.go:2041	0x6e1a7e		80ba2002000000			CMPB 0x220(DX), $0x0													
  compile.go:2041	0x6e1a85		0f840c010000			JE 0x6e1b97														
  compile.go:1205	0x6e1a8b		4c8b8424400a0000		MOVQ 0xa40(SP), R8													
  compile.go:1205	0x6e1a93		4d85c0				TESTQ R8, R8														
  compile.go:1205	0x6e1a96		7425				JE 0x6e1abd														
  compile.go:2021	0x6e1a98		48898424b00a0000		MOVQ AX, 0xab0(SP)													
  compile.go:1206	0x6e1aa0		488b842478050000		MOVQ 0x578(SP), AX													
  compile.go:1206	0x6e1aa8		4889842480050000		MOVQ AX, 0x580(SP)													
  compile.go:2058	0x6e1ab0		488b8424b00a0000		MOVQ 0xab0(SP), AX													
  compile.go:1205	0x6e1ab8		e983000000			JMP 0x6e1b40														
  compile.go:1206	0x6e1abd		488d0554a9a500			LEAQ 0xa5a954(IP), AX													
  compile.go:1206	0x6e1ac4		488b9c24a8050000		MOVQ 0x5a8(SP), BX													
  compile.go:1206	0x6e1acc		4889d9				MOVQ BX, CX														
  compile.go:1206	0x6e1acf		e88ce6daff			CALL runtime.makeslice(SB)												
  compile.go:2058	0x6e1ad4		488b8c2448050000		MOVQ 0x548(SP), CX													
  compile.go:2044	0x6e1adc		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2058	0x6e1ae4		488b9c2440050000		MOVQ 0x540(SP), BX													
  compile.go:2048	0x6e1aec		488bb424b0040000		MOVQ 0x4b0(SP), SI													
  compile.go:2048	0x6e1af4		488bbc24a8070000		MOVQ 0x7a8(SP), DI													
  compile.go:2048	0x6e1afc		448b942460030000		MOVL 0x360(SP), R10													
  compile.go:1208	0x6e1b04		4c8b9c24b0050000		MOVQ 0x5b0(SP), R11													
  compile.go:1208	0x6e1b0c		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:1208	0x6e1b15		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:1208	0x6e1b1d		4c8bbc24900a0000		MOVQ 0xa90(SP), R15													
  compile.go:1206	0x6e1b25		4c8b8424a8050000		MOVQ 0x5a8(SP), R8													
  compile.go:1206	0x6e1b2d		4c89842480050000		MOVQ R8, 0x580(SP)													
  compile.go:1206	0x6e1b35		4989c0				MOVQ AX, R8														
  compile.go:2058	0x6e1b38		488b8424280a0000		MOVQ 0xa28(SP), AX													
  compile.go:1208	0x6e1b40		49c1eb06			SHRQ $0x6, R11														
  compile.go:1208	0x6e1b44		4c8b8c2480050000		MOVQ 0x580(SP), R9													
  compile.go:1208	0x6e1b4c		4d39d9				CMPQ R9, R11														
  compile.go:1208	0x6e1b4f		0f865a1c0000			JBE 0x6e37af														
  compile.go:1208	0x6e1b55		4f8b14d8			MOVQ 0(R8)(R11*8), R10													
  compile.go:1208	0x6e1b59		4c8ba424b0050000		MOVQ 0x5b0(SP), R12													
  compile.go:1208	0x6e1b61		4d0fabe2			BTSQ R12, R10														
  compile.go:1208	0x6e1b65		4f8914d8			MOVQ R10, 0(R8)(R11*8)													
  compile.go:1208	0x6e1b69		4c8b8c24980a0000		MOVQ 0xa98(SP), R9													
  compile.go:1208	0x6e1b71		448b942460030000		MOVL 0x360(SP), R10													
  compile.go:1208	0x6e1b79		4d89e3				MOVQ R12, R11														
  compile.go:1208	0x6e1b7c		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:2042	0x6e1b85		4c898424400a0000		MOVQ R8, 0xa40(SP)													
  compile.go:2042	0x6e1b8d		4c8b8424f8050000		MOVQ 0x5f8(SP), R8													
  compile.go:2042	0x6e1b95		eb20				JMP 0x6e1bb7														
  compile.go:2021	0x6e1b97		48898424a80a0000		MOVQ AX, 0xaa8(SP)													
  compile.go:2042	0x6e1b9f		488b842478050000		MOVQ 0x578(SP), AX													
  compile.go:2042	0x6e1ba7		4889842480050000		MOVQ AX, 0x580(SP)													
  compile.go:2058	0x6e1baf		488b8424a80a0000		MOVQ 0xaa8(SP), AX													
  compile.go:2044	0x6e1bb7		80ba2102000000			CMPB 0x221(DX), $0x0													
  compile.go:2044	0x6e1bbe		6690				NOPW															
  compile.go:2044	0x6e1bc0		0f84dc000000			JE 0x6e1ca2														
  compile.go:1205	0x6e1bc6		4c8b8424380a0000		MOVQ 0xa38(SP), R8													
  compile.go:1205	0x6e1bce		4d85c0				TESTQ R8, R8														
  compile.go:1205	0x6e1bd1		0f8583000000			JNE 0x6e1c5a														
  compile.go:1206	0x6e1bd7		488d053aa8a500			LEAQ 0xa5a83a(IP), AX													
  compile.go:1206	0x6e1bde		488b9c24a0050000		MOVQ 0x5a0(SP), BX													
  compile.go:1206	0x6e1be6		4889d9				MOVQ BX, CX														
  compile.go:1206	0x6e1be9		e872e5daff			CALL runtime.makeslice(SB)												
  compile.go:2058	0x6e1bee		488b8c2448050000		MOVQ 0x548(SP), CX													
  compile.go:2051	0x6e1bf6		488b942418070000		MOVQ 0x718(SP), DX													
  compile.go:2058	0x6e1bfe		488b9c2440050000		MOVQ 0x540(SP), BX													
  compile.go:2048	0x6e1c06		488bb424b0040000		MOVQ 0x4b0(SP), SI													
  compile.go:2048	0x6e1c0e		488bbc24a8070000		MOVQ 0x7a8(SP), DI													
  compile.go:2048	0x6e1c16		448b942460030000		MOVL 0x360(SP), R10													
  compile.go:1208	0x6e1c1e		4c8b9c24b0050000		MOVQ 0x5b0(SP), R11													
  compile.go:1208	0x6e1c26		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:1208	0x6e1c2f		4c8bac24e0050000		MOVQ 0x5e0(SP), R13													
  compile.go:1208	0x6e1c37		4c8bbc24900a0000		MOVQ 0xa90(SP), R15													
  compile.go:1206	0x6e1c3f		4c8b8424a0050000		MOVQ 0x5a0(SP), R8													
  compile.go:1206	0x6e1c47		4c89842470050000		MOVQ R8, 0x570(SP)													
  compile.go:1206	0x6e1c4f		4989c0				MOVQ AX, R8														
  compile.go:2058	0x6e1c52		488b8424280a0000		MOVQ 0xa28(SP), AX													
  compile.go:1208	0x6e1c5a		49c1eb06			SHRQ $0x6, R11														
  compile.go:1208	0x6e1c5e		4c8b8c2470050000		MOVQ 0x570(SP), R9													
  compile.go:1208	0x6e1c66		4d39d9				CMPQ R9, R11														
  compile.go:1208	0x6e1c69		0f863b1b0000			JBE 0x6e37aa														
  compile.go:1208	0x6e1c6f		4f8b14d8			MOVQ 0(R8)(R11*8), R10													
  compile.go:1208	0x6e1c73		4c8ba424b0050000		MOVQ 0x5b0(SP), R12													
  compile.go:1208	0x6e1c7b		4d0fabe2			BTSQ R12, R10														
  compile.go:1208	0x6e1c7f		4f8914d8			MOVQ R10, 0(R8)(R11*8)													
  compile.go:2049	0x6e1c83		4d89e3				MOVQ R12, R11														
  compile.go:2049	0x6e1c86		440fb6a42443030000		MOVZX 0x343(SP), R12													
  compile.go:2045	0x6e1c8f		4c898c2468050000		MOVQ R9, 0x568(SP)													
  compile.go:2045	0x6e1c97		4c898424380a0000		MOVQ R8, 0xa38(SP)													
  compile.go:2045	0x6e1c9f		90				NOPL															
  compile.go:2045	0x6e1ca0		eb20				JMP 0x6e1cc2														
  compile.go:2021	0x6e1ca2		48898424a00a0000		MOVQ AX, 0xaa0(SP)													
  compile.go:2045	0x6e1caa		488b842470050000		MOVQ 0x570(SP), AX													
  compile.go:2045	0x6e1cb2		4889842468050000		MOVQ AX, 0x568(SP)													
  compile.go:2058	0x6e1cba		488b8424a00a0000		MOVQ 0xaa0(SP), AX													
  compile.go:2048	0x6e1cc2		4c8b8424c0040000		MOVQ 0x4c0(SP), R8													
  compile.go:2048	0x6e1cca		4d8d0c30			LEAQ 0(R8)(SI*1), R9													
  compile.go:2048	0x6e1cce		4c8b9424c8040000		MOVQ 0x4c8(SP), R10													
  compile.go:2048	0x6e1cd6		4d39ca				CMPQ R10, R9														
  compile.go:2048	0x6e1cd9		721a				JB 0x6e1cf5														
  compile.go:2021	0x6e1cdb		48898424180d0000		MOVQ AX, 0xd18(SP)													
  compile.go:2048	0x6e1ce3		488b8424b8070000		MOVQ 0x7b8(SP), AX													
  compile.go:2048	0x6e1ceb		48898424d80a0000		MOVQ AX, 0xad8(SP)													
  compile.go:2048	0x6e1cf3		eb43				JMP 0x6e1d38														
  compile.go:2048	0x6e1cf5		488b8424b8070000		MOVQ 0x7b8(SP), AX													
  compile.go:2048	0x6e1cfd		4c89cb				MOVQ R9, BX														
  compile.go:2048	0x6e1d00		4c89d1				MOVQ R10, CX														
  compile.go:2048	0x6e1d03		4889f7				MOVQ SI, DI														
  compile.go:2048	0x6e1d06		488d356b2caa00			LEAQ 0xaa2c6b(IP), SI													
  compile.go:2048	0x6e1d0d		e82ee5daff			CALL runtime.growslice(SB)												
  compile.go:2048	0x6e1d12		488bb424b0040000		MOVQ 0x4b0(SP), SI													
  compile.go:2048	0x6e1d1a		488bbc24a8070000		MOVQ 0x7a8(SP), DI													
  compile.go:2048	0x6e1d22		4c8b8424c0040000		MOVQ 0x4c0(SP), R8													
  compile.go:2048	0x6e1d2a		4989d9				MOVQ BX, R9														
  compile.go:2048	0x6e1d2d		48898424d80a0000		MOVQ AX, 0xad8(SP)													
  compile.go:2048	0x6e1d35		4989ca				MOVQ CX, R10														
  compile.go:2048	0x6e1d38		4c899424c8040000		MOVQ R10, 0x4c8(SP)													
  compile.go:2048	0x6e1d40		4c898c24f0050000		MOVQ R9, 0x5f0(SP)													
  compile.go:2048	0x6e1d48		4b8d1440			LEAQ 0(R8)(R8*2), DX													
  compile.go:2048	0x6e1d4c		48899424e8050000		MOVQ DX, 0x5e8(SP)													
  compile.go:2048	0x6e1d54		488d0c76			LEAQ 0(SI)(SI*2), CX													
  compile.go:2048	0x6e1d58		488bb424d80a0000		MOVQ 0xad8(SP), SI													
  compile.go:2048	0x6e1d60		488d0496			LEAQ 0(SI)(DX*4), AX													
  compile.go:2048	0x6e1d64		48c1e102			SHLQ $0x2, CX														
  compile.go:2048	0x6e1d68		4889fb				MOVQ DI, BX														
  compile.go:2048	0x6e1d6b		e8d039dbff			CALL runtime.memmove(SB)												
  compile.go:2049	0x6e1d70		488b9424f0050000		MOVQ 0x5f0(SP), DX													
  compile.go:2049	0x6e1d78		488bb424c0040000		MOVQ 0x4c0(SP), SI													
  compile.go:2049	0x6e1d80		4839f2				CMPQ DX, SI														
  compile.go:2049	0x6e1d83		0f821c1a0000			JB 0x6e37a5														
  compile.go:2049	0x6e1d89		4c8ba424b0050000		MOVQ 0x5b0(SP), R12													
  compile.go:2049	0x6e1d91		4f8d2c64			LEAQ 0(R12)(R12*2), R13													
  compile.go:2049	0x6e1d95		4c8bbc24c8040000		MOVQ 0x4c8(SP), R15													
  compile.go:2049	0x6e1d9d		4c89f8				MOVQ R15, AX														
  compile.go:2049	0x6e1da0		4929f7				SUBQ SI, R15														
  compile.go:2049	0x6e1da3		4889d1				MOVQ DX, CX														
  compile.go:2049	0x6e1da6		4829f2				SUBQ SI, DX														
  compile.go:2049	0x6e1da9		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  compile.go:2049	0x6e1db1		4b8954e908			MOVQ DX, 0x8(R9)(R13*8)													
  compile.go:2049	0x6e1db6		4f897ce910			MOVQ R15, 0x10(R9)(R13*8)												
  compile.go:2049	0x6e1dbb		49f7df				NEGQ R15														
  compile.go:1980	0x6e1dbe		4c89e2				MOVQ R12, DX														
  compile.go:2049	0x6e1dc1		4c8ba424e8050000		MOVQ 0x5e8(SP), R12													
  compile.go:2049	0x6e1dc9		49c1e402			SHLQ $0x2, R12														
  compile.go:2049	0x6e1dcd		49c1ff3f			SARQ $0x3f, R15														
  compile.go:2049	0x6e1dd1		4d21fc				ANDQ R15, R12														
  compile.go:2049	0x6e1dd4		4c8bbc24d80a0000		MOVQ 0xad8(SP), R15													
  compile.go:2049	0x6e1ddc		4d01fc				ADDQ R15, R12														
  compile.go:2049	0x6e1ddf		833d9ac1b30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:2049	0x6e1de6		7410				JE 0x6e1df8														
  compile.go:2049	0x6e1de8		4b8b1ce9			MOVQ 0(R9)(R13*8), BX													
  compile.go:2049	0x6e1dec		e80f32dbff			CALL runtime.gcWriteBarrier2(SB)											
  compile.go:2049	0x6e1df1		4d8923				MOVQ R12, 0(R11)													
  compile.go:2049	0x6e1df4		49895b08			MOVQ BX, 0x8(R11)													
  compile.go:2049	0x6e1df8		4f8924e9			MOVQ R12, 0(R9)(R13*8)													
  compile.go:2050	0x6e1dfc		4c8ba42480080000		MOVQ 0x880(SP), R12													
  compile.go:2050	0x6e1e04		4d85e4				TESTQ R12, R12														
  compile.go:2050	0x6e1e07		751d				JNE 0x6e1e26														
  compile.go:2055	0x6e1e09		488b9c2400050000		MOVQ 0x500(SP), BX													
  compile.go:2055	0x6e1e11		488bb42408050000		MOVQ 0x508(SP), SI													
  compile.go:2055	0x6e1e19		488bbc2478080000		MOVQ 0x878(SP), DI													
  compile.go:2050	0x6e1e21		e926010000			JMP 0x6e1f4c														
  compile.go:2051	0x6e1e26		4c8b842418070000		MOVQ 0x718(SP), R8													
  compile.go:2051	0x6e1e2e		498bb818050000			MOVQ 0x518(R8), DI													
  compile.go:2051	0x6e1e35		4c8b942400050000		MOVQ 0x500(SP), R10													
  compile.go:2051	0x6e1e3d		4a8d1c17			LEAQ 0(DI)(R10*1), BX													
  compile.go:2051	0x6e1e41		4d8b9810050000			MOVQ 0x510(R8), R11													
  compile.go:2051	0x6e1e48		4c8bac2408050000		MOVQ 0x508(SP), R13													
  compile.go:2051	0x6e1e50		4939dd				CMPQ R13, BX														
  compile.go:2051	0x6e1e53		720a				JB 0x6e1e5f														
  compile.go:2051	0x6e1e55		488bb42478080000		MOVQ 0x878(SP), SI													
  compile.go:2051	0x6e1e5d		eb45				JMP 0x6e1ea4														
  compile.go:2051	0x6e1e5f		4889bc24e8050000		MOVQ DI, 0x5e8(SP)													
  compile.go:2051	0x6e1e67		4c899c24d00a0000		MOVQ R11, 0xad0(SP)													
  compile.go:2051	0x6e1e6f		488b842478080000		MOVQ 0x878(SP), AX													
  compile.go:2051	0x6e1e77		4c89e9				MOVQ R13, CX														
  compile.go:2051	0x6e1e7a		488d3597a5a500			LEAQ 0xa5a597(IP), SI													
  compile.go:2051	0x6e1e81		e8bae3daff			CALL runtime.growslice(SB)												
  compile.go:2051	0x6e1e86		488bbc24e8050000		MOVQ 0x5e8(SP), DI													
  compile.go:2051	0x6e1e8e		4c8b942400050000		MOVQ 0x500(SP), R10													
  compile.go:2051	0x6e1e96		4c8b9c24d00a0000		MOVQ 0xad0(SP), R11													
  compile.go:2051	0x6e1e9e		4889c6				MOVQ AX, SI														
  compile.go:2051	0x6e1ea1		4989cd				MOVQ CX, R13														
  compile.go:2051	0x6e1ea4		4c89ac2408050000		MOVQ R13, 0x508(SP)													
  compile.go:2051	0x6e1eac		48899c2400050000		MOVQ BX, 0x500(SP)													
  compile.go:2051	0x6e1eb4		4889b42478080000		MOVQ SI, 0x878(SP)													
  compile.go:2051	0x6e1ebc		4a8d04d6			LEAQ 0(SI)(R10*8), AX													
  compile.go:2051	0x6e1ec0		48c1e703			SHLQ $0x3, DI														
  compile.go:2051	0x6e1ec4		4c89db				MOVQ R11, BX														
  compile.go:2051	0x6e1ec7		4889f9				MOVQ DI, CX														
  compile.go:2051	0x6e1eca		e87138dbff			CALL runtime.memmove(SB)												
  compile.go:2052	0x6e1ecf		488b942400050000		MOVQ 0x500(SP), DX													
  compile.go:2052	0x6e1ed7		beffffffff			MOVL $-0x1, SI														
  compile.go:2052	0x6e1edc		0f1f4000			NOPL 0(AX)														
  compile.go:2052	0x6e1ee0		4839f2				CMPQ DX, SI														
  compile.go:2052	0x6e1ee3		0f871e060000			JA 0x6e2507														
  compile.go:2055	0x6e1ee9		4c8ba424b0050000		MOVQ 0x5b0(SP), R12													
  compile.go:2055	0x6e1ef1		4d8d6c2401			LEAQ 0x1(R12), R13													
  compile.go:2055	0x6e1ef6		4c8bbc2410050000		MOVQ 0x510(SP), R15													
  compile.go:2055	0x6e1efe		6690				NOPW															
  compile.go:2055	0x6e1f00		4d39ef				CMPQ R15, R13														
  compile.go:2055	0x6e1f03		0f8695180000			JBE 0x6e379e														
  compile.go:2055	0x6e1f09		4c8bac2480080000		MOVQ 0x880(SP), R13													
  compile.go:2055	0x6e1f11		438954a504			MOVL DX, 0x4(R13)(R12*4)												
  compile.go:2055	0x6e1f16		488b8424c8040000		MOVQ 0x4c8(SP), AX													
  compile.go:2055	0x6e1f1e		488b8c24f0050000		MOVQ 0x5f0(SP), CX													
  compile.go:1980	0x6e1f26		4c89e2				MOVQ R12, DX														
  compile.go:2082	0x6e1f29		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  compile.go:1988	0x6e1f31		4d89ec				MOVQ R13, R12														
  compile.go:2055	0x6e1f34		488b9c2400050000		MOVQ 0x500(SP), BX													
  compile.go:2055	0x6e1f3c		488bb42408050000		MOVQ 0x508(SP), SI													
  compile.go:2055	0x6e1f44		488bbc2478080000		MOVQ 0x878(SP), DI													
  compile.go:2055	0x6e1f4c		48899c2400050000		MOVQ BX, 0x500(SP)													
  compile.go:2055	0x6e1f54		4889bc2478080000		MOVQ DI, 0x878(SP)													
  compile.go:2055	0x6e1f5c		4889b42408050000		MOVQ SI, 0x508(SP)													
  compile.go:2057	0x6e1f64		4c8dac24680c0000		LEAQ 0xc68(SP), R13													
  compile.go:1798	0x6e1f6c		4d89e0				MOVQ R12, R8														
  compile.go:2057	0x6e1f6f		4c8da424f0070000		LEAQ 0x7f0(SP), R12													
  compile.go:2057	0x6e1f77		450f103424			MOVUPS 0(R12), X14													
  compile.go:2057	0x6e1f7c		450f117500			MOVUPS X14, 0(R13)													
  compile.go:2057	0x6e1f81		450f10742410			MOVUPS 0x10(R12), X14													
  compile.go:2057	0x6e1f87		450f117510			MOVUPS X14, 0x10(R13)													
  compile.go:2057	0x6e1f8c		450f10742420			MOVUPS 0x20(R12), X14													
  compile.go:2057	0x6e1f92		450f117520			MOVUPS X14, 0x20(R13)													
  compile.go:2057	0x6e1f97		440fb62d9199b100		MOVZX github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optSharedTrapBody+16(SB), R13			
  compile.go:2057	0x6e1f9f		4c89ac24e8050000		MOVQ R13, 0x5e8(SP)													
  compile.go:2057	0x6e1fa7		4c8b157299b100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optSharedTrapBody(SB), R10			
  compile.go:2057	0x6e1fae		4c8b1d7399b100			MOVQ github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.optSharedTrapBody+8(SB), R11			
  catalog.go:96		0x6e1fb5		4c8ba424680c0000		MOVQ 0xc68(SP), R12													
  policy.go:28		0x6e1fbd		4c8dbc2460070000		LEAQ 0x760(SP), R15													
  policy.go:28		0x6e1fc5		4c8dac24680c0000		LEAQ 0xc68(SP), R13													
  policy.go:28		0x6e1fcd		450f107500			MOVUPS 0(R13), X14													
  policy.go:28		0x6e1fd2		450f1137			MOVUPS X14, 0(R15)													
  policy.go:28		0x6e1fd6		450f107508			MOVUPS 0x8(R13), X14													
  policy.go:28		0x6e1fdb		450f117708			MOVUPS X14, 0x8(R15)													
  catalog.go:96		0x6e1fe0		4d85e4				TESTQ R12, R12														
  catalog.go:96		0x6e1fe3		0f84d3010000			JE 0x6e21bc														
  catalog.go:96		0x6e1fe9		4d39d4				CMPQ R12, R10														
  catalog.go:96		0x6e1fec		0f85a5010000			JNE 0x6e2197														
  catalog.go:96		0x6e1ff2		4c8ba424e8050000		MOVQ 0x5e8(SP), R12													
  catalog.go:96		0x6e1ffa		660f1f440000			NOPW 0(AX)(AX*1)													
  catalog.go:96		0x6e2000		4983fc02			CMPQ R12, $0x2														
  catalog.go:96		0x6e2004		0f838f170000			JAE 0x6e3799														
  catalog.go:96		0x6e200a		4e8ba4e468070000		MOVQ 0x768(SP)(R12*8), R12												
  catalog.go:96		0x6e2012		4d85dc				TESTQ R11, R12														
  compile.go:2057	0x6e2015		0f8457010000			JE 0x6e2172														
  compile.go:2057	0x6e201b		80bc240808000000		CMPB 0x808(SP), $0x0													
  compile.go:2057	0x6e2023		7528				JNE 0x6e204d														
  code_buffer.go:156	0x6e2025		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  code_buffer.go:156	0x6e202d		4d85e4				TESTQ R12, R12														
  compile.go:2058	0x6e2030		4c8b942440050000		MOVQ 0x540(SP), R10													
  compile.go:2058	0x6e2038		4c8b9c24280a0000		MOVQ 0xa28(SP), R11													
  compile.go:2058	0x6e2040		4c8bac2448050000		MOVQ 0x548(SP), R13													
  compile.go:2057	0x6e2048		e992010000			JMP 0x6e21df														
  code_buffer.go:156	0x6e204d		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  code_buffer.go:156	0x6e2055		4d85e4				TESTQ R12, R12														
  code_buffer.go:156	0x6e2058		7421				JE 0x6e207b														
  code_buffer.go:156	0x6e205a		41807c242300			CMPB 0x23(R12), $0x0													
  code_buffer.go:156	0x6e2060		7519				JNE 0x6e207b														
  code_buffer.go:159	0x6e2062		4d8b6c2410			MOVQ 0x10(R12), R13													
  code_buffer.go:159	0x6e2067		4d8b7c2418			MOVQ 0x18(R12), R15													
  code_buffer.go:159	0x6e206c		4d39ef				CMPQ R15, R13														
  code_buffer.go:159	0x6e206f		0f871f170000			JA 0x6e3794														
  code_buffer.go:159	0x6e2075		4d8b2c24			MOVQ 0(R12), R13													
  compile.go:2058	0x6e2079		eb06				JMP 0x6e2081														
  compile.go:2058	0x6e207b		4531ff				XORL R15, R15														
  compile.go:2058	0x6e207e		4531ed				XORL R13, R13														
  compile.go:1950	0x6e2081		4d89e2				MOVQ R12, R10														
  trap_bodies.go:24	0x6e2084		4c8ba42418070000		MOVQ 0x718(SP), R12													
  trap_bodies.go:24	0x6e208c		4d8b9c2450090000		MOVQ 0x950(R12), R11													
  trap_bodies.go:24	0x6e2094		4d8ba42448090000		MOVQ 0x948(R12), R12													
  trap_bodies.go:24	0x6e209c		4d8d4c2405			LEAQ 0x5(R12), R9													
  trap_bodies.go:24	0x6e20a1		4d39cb				CMPQ R11, R9														
  trap_bodies.go:24	0x6e20a4		7f06				JG 0x6e20ac														
  trap_bodies.go:24	0x6e20a6		4531e4				XORL R12, R12														
  trap_bodies.go:24	0x6e20a9		4531db				XORL R11, R11														
  compile.go:2058	0x6e20ac		4d89e9				MOVQ R13, R9														
  compile.go:2058	0x6e20af		4c8bac24d8080000		MOVQ 0x8d8(SP), R13													
  compile.go:2058	0x6e20b7		460fb6042a			MOVZX 0(DX)(R13*1), R8													
  compile.go:2058	0x6e20bc		4c8bac24080b0000		MOVQ 0xb08(SP), R13													
  compile.go:2058	0x6e20c4		4d8b6cd500			MOVQ 0(R13)(DX*8), R13													
  compile.go:2058	0x6e20c9		4584c0				TESTL R8, R8														
  trap_bodies.go:47	0x6e20cc		7409				JE 0x6e20d7														
  trap_bodies.go:48	0x6e20ce		90				NOPL															
  trap_bodies.go:44	0x6e20cf		c684247804000000		MOVB $0x0, 0x478(SP)													
  trap_bodies.go:50	0x6e20d7		44892424			MOVL R12, 0(SP)														
  trap_bodies.go:50	0x6e20db		44895c2404			MOVL R11, 0x4(SP)													
  trap_bodies.go:50	0x6e20e0		488d8424b8030000		LEAQ 0x3b8(SP), AX													
  trap_bodies.go:50	0x6e20e8		4c89cb				MOVQ R9, BX														
  trap_bodies.go:50	0x6e20eb		4c89f9				MOVQ R15, CX														
  trap_bodies.go:50	0x6e20ee		4889cf				MOVQ CX, DI														
  trap_bodies.go:50	0x6e20f1		488bb424280a0000		MOVQ 0xa28(SP), SI													
  trap_bodies.go:50	0x6e20f9		4c8b842440050000		MOVQ 0x540(SP), R8													
  trap_bodies.go:50	0x6e2101		4c8b8c2448050000		MOVQ 0x548(SP), R9													
  trap_bodies.go:50	0x6e2109		4d89ea				MOVQ R13, R10														
  trap_bodies.go:50	0x6e210c		4531db				XORL R11, R11														
  trap_bodies.go:50	0x6e210f		e8ac1b0a00			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.(*sharedTrapBodyClusterAMD64).share(SB)		
  code_buffer.go:156	0x6e2114		488b9424800a0000		MOVQ 0xa80(SP), DX													
  code_buffer.go:156	0x6e211c		4885d2				TESTQ DX, DX														
  compile.go:1980	0x6e211f		488b9424b0050000		MOVQ 0x5b0(SP), DX													
  compile.go:1980	0x6e2127		488bb42408050000		MOVQ 0x508(SP), SI													
  compile.go:1980	0x6e212f		488bbc2478080000		MOVQ 0x878(SP), DI													
  compile.go:1988	0x6e2137		4c8b842480080000		MOVQ 0x880(SP), R8													
  compile.go:2082	0x6e213f		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  code_buffer.go:140	0x6e2147		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  compile.go:2058	0x6e214f		4989da				MOVQ BX, R10														
  compile.go:2058	0x6e2152		4989c3				MOVQ AX, R11														
  compile.go:2058	0x6e2155		4989cd				MOVQ CX, R13														
  compile.go:2058	0x6e2158		488b8424c8040000		MOVQ 0x4c8(SP), AX													
  compile.go:2058	0x6e2160		488b8c24f0050000		MOVQ 0x5f0(SP), CX													
  compile.go:2058	0x6e2168		488b9c2400050000		MOVQ 0x500(SP), BX													
  compile.go:2058	0x6e2170		eb6d				JMP 0x6e21df														
  code_buffer.go:156	0x6e2172		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  code_buffer.go:156	0x6e217a		4d85e4				TESTQ R12, R12														
  compile.go:2058	0x6e217d		4c8b942440050000		MOVQ 0x540(SP), R10													
  compile.go:2058	0x6e2185		4c8b9c24280a0000		MOVQ 0xa28(SP), R11													
  compile.go:2058	0x6e218d		4c8bac2448050000		MOVQ 0x548(SP), R13													
  compile.go:2057	0x6e2195		eb48				JMP 0x6e21df														
  code_buffer.go:156	0x6e2197		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  code_buffer.go:156	0x6e219f		4d85e4				TESTQ R12, R12														
  compile.go:2058	0x6e21a2		4c8b942440050000		MOVQ 0x540(SP), R10													
  compile.go:2058	0x6e21aa		4c8b9c24280a0000		MOVQ 0xa28(SP), R11													
  compile.go:2058	0x6e21b2		4c8bac2448050000		MOVQ 0x548(SP), R13													
  catalog.go:96		0x6e21ba		eb23				JMP 0x6e21df														
  code_buffer.go:156	0x6e21bc		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  code_buffer.go:156	0x6e21c4		4d85e4				TESTQ R12, R12														
  compile.go:2058	0x6e21c7		4c8b942440050000		MOVQ 0x540(SP), R10													
  compile.go:2058	0x6e21cf		4c8b9c24280a0000		MOVQ 0xa28(SP), R11													
  compile.go:2058	0x6e21d7		4c8bac2448050000		MOVQ 0x548(SP), R13													
  compile.go:2058	0x6e21df		90				NOPL															
  code_buffer.go:140	0x6e21e0		0f84d0000000			JE 0x6e22b6														
  code_buffer.go:140	0x6e21e6		41807c242300			CMPB 0x23(R12), $0x0													
  code_buffer.go:140	0x6e21ec		0f85c4000000			JNE 0x6e22b6														
  code_buffer.go:140	0x6e21f2		41807c242100			CMPB 0x21(R12), $0x0													
  code_buffer.go:140	0x6e21f8		0f85b8000000			JNE 0x6e22b6														
  code_buffer.go:140	0x6e21fe		4d8b7c2408			MOVQ 0x8(R12), R15													
  code_buffer.go:140	0x6e2203		4c89bc24e8050000		MOVQ R15, 0x5e8(SP)													
  code_buffer.go:140	0x6e220b		4d8b4c2418			MOVQ 0x18(R12), R9													
  code_buffer.go:140	0x6e2210		4d29cf				SUBQ R9, R15														
  code_buffer.go:140	0x6e2213		4d39fa				CMPQ R10, R15														
  code_buffer.go:140	0x6e2216		7e0d				JLE 0x6e2225														
  compile.go:2082	0x6e2218		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  code_buffer.go:140	0x6e2220		e991000000			JMP 0x6e22b6														
  code_buffer.go:143	0x6e2225		4d85d2				TESTQ R10, R10														
  code_buffer.go:143	0x6e2228		7510				JNE 0x6e223a														
  compile.go:2082	0x6e222a		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  compile.go:2082	0x6e2232		41bf01000000			MOVL $0x1, R15														
  compile.go:2060	0x6e2238		eb7f				JMP 0x6e22b9														
  code_buffer.go:146	0x6e223a		4c8bbc24e8050000		MOVQ 0x5e8(SP), R15													
  code_buffer.go:146	0x6e2242		4d39f9				CMPQ R9, R15														
  code_buffer.go:146	0x6e2245		743f				JE 0x6e2286														
  code_buffer.go:146	0x6e2247		0f8742150000			JA 0x6e378f														
  code_buffer.go:140	0x6e224d		4c898c24e8050000		MOVQ R9, 0x5e8(SP)													
  code_buffer.go:140	0x6e2255		4d8b3c24			MOVQ 0(R12), R15													
  code_buffer.go:140	0x6e2259		4d8b442410			MOVQ 0x10(R12), R8													
  code_buffer.go:146	0x6e225e		4d29c1				SUBQ R8, R9														
  code_buffer.go:146	0x6e2261		49c1f93f			SARQ $0x3f, R9														
  compile.go:2058	0x6e2265		4d89e8				MOVQ R13, R8														
  code_buffer.go:146	0x6e2268		4c8bac24e8050000		MOVQ 0x5e8(SP), R13													
  code_buffer.go:146	0x6e2270		4d21e9				ANDQ R13, R9														
  code_buffer.go:146	0x6e2273		4d01cf				ADDQ R9, R15														
  code_buffer.go:146	0x6e2276		4d39fb				CMPQ R11, R15														
  code_buffer.go:146	0x6e2279		7418				JE 0x6e2293														
  compile.go:2061	0x6e227b		4d89c5				MOVQ R8, R13														
  compile.go:1988	0x6e227e		4c8b842480080000		MOVQ 0x880(SP), R8													
  compile.go:2082	0x6e2286		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  compile.go:2082	0x6e228e		4531ff				XORL R15, R15														
  compile.go:2060	0x6e2291		eb26				JMP 0x6e22b9														
  code_buffer.go:149	0x6e2293		4d01d5				ADDQ R10, R13														
  code_buffer.go:149	0x6e2296		4d896c2418			MOVQ R13, 0x18(R12)													
  compile.go:2082	0x6e229b		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  compile.go:2061	0x6e22a3		4d89c5				MOVQ R8, R13														
  compile.go:2061	0x6e22a6		41bf01000000			MOVL $0x1, R15														
  compile.go:1988	0x6e22ac		4c8b842480080000		MOVQ 0x880(SP), R8													
  compile.go:2060	0x6e22b4		eb03				JMP 0x6e22b9														
  compile.go:2060	0x6e22b6		4531ff				XORL R15, R15														
  code_buffer.go:149	0x6e22b9		4584ff				TESTL R15, R15														
  compile.go:2060	0x6e22bc		7562				JNE 0x6e2320														
  compile.go:2061	0x6e22be		4c89e0				MOVQ R12, AX														
  compile.go:2061	0x6e22c1		4c89db				MOVQ R11, BX														
  compile.go:2061	0x6e22c4		4c89d1				MOVQ R10, CX														
  compile.go:2061	0x6e22c7		4c89ef				MOVQ R13, DI														
  compile.go:2061	0x6e22ca		e8d1e1fbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).Append(SB)							
  compile.go:2061	0x6e22cf		4885c0				TESTQ AX, AX														
  compile.go:2061	0x6e22d2		0f8576010000			JNE 0x6e244e														
  compile.go:2061	0x6e22d8		488b8424c8040000		MOVQ 0x4c8(SP), AX													
  compile.go:2061	0x6e22e0		488b8c24f0050000		MOVQ 0x5f0(SP), CX													
  compile.go:1980	0x6e22e8		488b9424b0050000		MOVQ 0x5b0(SP), DX													
  compile.go:1980	0x6e22f0		488b9c2400050000		MOVQ 0x500(SP), BX													
  compile.go:1980	0x6e22f8		488bb42408050000		MOVQ 0x508(SP), SI													
  compile.go:1980	0x6e2300		488bbc2478080000		MOVQ 0x878(SP), DI													
  compile.go:1988	0x6e2308		4c8b842480080000		MOVQ 0x880(SP), R8													
  compile.go:2082	0x6e2310		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  code_buffer.go:156	0x6e2318		4c8ba424800a0000		MOVQ 0xa80(SP), R12													
  compile.go:1980	0x6e2320		440fb6ac2445030000		MOVZX 0x345(SP), R13													
  compile.go:1980	0x6e2329		4584ed				TESTL R13, R13														
  compile.go:2065	0x6e232c		7410				JE 0x6e233e														
  code_buffer.go:156	0x6e232e		4d89e2				MOVQ R12, R10														
  compile.go:2065	0x6e2331		4c8ba42488030000		MOVQ 0x388(SP), R12													
  compile.go:2065	0x6e2339		e9b2000000			JMP 0x6e23f0														
  compile.go:2065	0x6e233e		4c8bbc24b00d0000		MOVQ 0xdb0(SP), R15													
  compile.go:2065	0x6e2346		4d85ff				TESTQ R15, R15														
  compile.go:2065	0x6e2349		0f8496000000			JE 0x6e23e5														
  code_buffer.go:156	0x6e234f		4d85e4				TESTQ R12, R12														
  code_buffer.go:156	0x6e2352		741c				JE 0x6e2370														
  code_buffer.go:156	0x6e2354		41807c242300			CMPB 0x23(R12), $0x0													
  code_buffer.go:156	0x6e235a		7514				JNE 0x6e2370														
  code_buffer.go:159	0x6e235c		4d8b542410			MOVQ 0x10(R12), R10													
  code_buffer.go:159	0x6e2361		4d8b5c2418			MOVQ 0x18(R12), R11													
  code_buffer.go:159	0x6e2366		4d39d3				CMPQ R11, R10														
  code_buffer.go:159	0x6e2369		7608				JBE 0x6e2373														
  code_buffer.go:159	0x6e236b		e91a140000			JMP 0x6e378a														
  code_buffer.go:159	0x6e2370		4531db				XORL R11, R11														
  compile.go:1950	0x6e2373		4d89e2				MOVQ R12, R10														
  compile.go:2065	0x6e2376		4c8ba42488030000		MOVQ 0x388(SP), R12													
  compile.go:2065	0x6e237e		6690				NOPW															
  compile.go:2065	0x6e2380		4d39e3				CMPQ R11, R12														
  compile.go:2065	0x6e2383		7c6b				JL 0x6e23f0														
  compile.go:2067	0x6e2385		498b07				MOVQ 0(R15), AX														
  compile.go:2067	0x6e2388		4c89fa				MOVQ R15, DX														
  compile.go:2067	0x6e238b		ffd0				CALL AX															
  compile.go:2067	0x6e238d		488b8424c8040000		MOVQ 0x4c8(SP), AX													
  compile.go:2067	0x6e2395		488b8c24f0050000		MOVQ 0x5f0(SP), CX													
  compile.go:1980	0x6e239d		488b9424b0050000		MOVQ 0x5b0(SP), DX													
  compile.go:1980	0x6e23a5		488b9c2400050000		MOVQ 0x500(SP), BX													
  compile.go:1980	0x6e23ad		488bb42408050000		MOVQ 0x508(SP), SI													
  compile.go:1980	0x6e23b5		488bbc2478080000		MOVQ 0x878(SP), DI													
  compile.go:1988	0x6e23bd		4c8b842480080000		MOVQ 0x880(SP), R8													
  compile.go:2082	0x6e23c5		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  code_buffer.go:156	0x6e23cd		4c8b9424800a0000		MOVQ 0xa80(SP), R10													
  compile.go:2065	0x6e23d5		4c8ba42488030000		MOVQ 0x388(SP), R12													
  compile.go:2065	0x6e23dd		41bd01000000			MOVL $0x1, R13														
  compile.go:2067	0x6e23e3		eb0b				JMP 0x6e23f0														
  code_buffer.go:156	0x6e23e5		4d89e2				MOVQ R12, R10														
  compile.go:2065	0x6e23e8		4c8ba42488030000		MOVQ 0x388(SP), R12													
  compile.go:1980	0x6e23f0		4c8b842400060000		MOVQ 0x600(SP), R8													
  compile.go:1980	0x6e23f8		4989d4				MOVQ DX, R12														
  compile.go:1980	0x6e23fb		448b8c2460030000		MOVL 0x360(SP), R9													
  compile.go:1980	0x6e2403		4c8b942468050000		MOVQ 0x568(SP), R10													
  compile.go:1980	0x6e240b		48898c24c0040000		MOVQ CX, 0x4c0(SP)													
  compile.go:1980	0x6e2413		4989df				MOVQ BX, R15														
  compile.go:1980	0x6e2416		488bbc24f8050000		MOVQ 0x5f8(SP), DI													
  compile.go:1980	0x6e241e		0fb69c244c030000		MOVZX 0x34c(SP), BX													
  compile.go:1980	0x6e2426		0fb68c244b030000		MOVZX 0x34b(SP), CX													
  compile.go:1980	0x6e242e		4589eb				MOVL R13, R11														
  compile.go:1980	0x6e2431		488b8424d80a0000		MOVQ 0xad8(SP), AX													
  compile.go:1989	0x6e2439		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:1988	0x6e2441		4c8bac2480080000		MOVQ 0x880(SP), R13													
  compile.go:1988	0x6e2449		e9c6e7ffff			JMP 0x6e0c14														
  compile.go:2062	0x6e244e		440f11bc24500b0000		MOVUPS X15, 0xb50(SP)													
  compile.go:2062	0x6e2457		7404				JE 0x6e245d														
  compile.go:2062	0x6e2459		488b4008			MOVQ 0x8(AX), AX													
  compile.go:2062	0x6e245d		48898424500b0000		MOVQ AX, 0xb50(SP)													
  compile.go:2062	0x6e2465		48899c24580b0000		MOVQ BX, 0xb58(SP)													
  errors.go:26		0x6e246d		488d0598b44100			LEAQ 0x41b498(IP), AX													
  errors.go:26		0x6e2474		bb1a000000			MOVL $0x1a, BX														
  errors.go:26		0x6e2479		488d8c24500b0000		LEAQ 0xb50(SP), CX													
  errors.go:26		0x6e2481		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e2486		89fe				MOVL DI, SI														
  errors.go:26		0x6e2488		e87382e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e248d		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e2490		7533				JNE 0x6e24c5														
  errors.go:31		0x6e2492		90				NOPL															
  errors.go:65		0x6e2493		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e2498		488d1d49dfa600			LEAQ 0xa6df49(IP), BX													
  errors.go:65		0x6e249f		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e24a4		e8970fd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e24a9		48c740081a000000		MOVQ $0x1a, 0x8(AX)													
  errors.go:65		0x6e24b1		488d1554b44100			LEAQ 0x41b454(IP), DX													
  errors.go:65		0x6e24b8		488910				MOVQ DX, 0(AX)														
  compile.go:2062	0x6e24bb		4889c3				MOVQ AX, BX														
  compile.go:2062	0x6e24be		488d0513daad00			LEAQ 0xadda13(IP), AX													
  compile.go:2062	0x6e24c5		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2062	0x6e24d1		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2062	0x6e24d9		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e24e1		e8dad4d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2062	0x6e24e6		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2062	0x6e24ee		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2062	0x6e24f6		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e24fe		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2505		5d				POPQ BP															
  compile.go:2144	0x6e2506		c3				RET															
  errors.go:26		0x6e2507		488d05be1a4300			LEAQ 0x431abe(IP), AX													
  errors.go:26		0x6e250e		bb2d000000			MOVL $0x2d, BX														
  errors.go:26		0x6e2513		31c9				XORL CX, CX														
  errors.go:26		0x6e2515		31ff				XORL DI, DI														
  errors.go:26		0x6e2517		89fe				MOVL DI, SI														
  errors.go:26		0x6e2519		e8e281e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e251e		6690				NOPW															
  errors.go:26		0x6e2520		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e2523		7533				JNE 0x6e2558														
  errors.go:31		0x6e2525		90				NOPL															
  errors.go:65		0x6e2526		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e252b		488d1db6dea600			LEAQ 0xa6deb6(IP), BX													
  errors.go:65		0x6e2532		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e2537		e8040fd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e253c		48c740082d000000		MOVQ $0x2d, 0x8(AX)													
  errors.go:65		0x6e2544		488d15811a4300			LEAQ 0x431a81(IP), DX													
  errors.go:65		0x6e254b		488910				MOVQ DX, 0(AX)														
  compile.go:2053	0x6e254e		4889c3				MOVQ AX, BX														
  compile.go:2053	0x6e2551		488d0580d9ad00			LEAQ 0xadd980(IP), AX													
  compile.go:2053	0x6e2558		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2053	0x6e2564		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2053	0x6e256c		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e2574		e847d4d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2053	0x6e2579		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2053	0x6e2581		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2053	0x6e2589		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e2591		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2598		5d				POPQ BP															
  compile.go:2144	0x6e2599		c3				RET															
  compile.go:2021	0x6e259a		4c899c24300a0000		MOVQ R11, 0xa30(SP)													
  compile.go:2021	0x6e25a2		4c89942450050000		MOVQ R10, 0x550(SP)													
  compile.go:2023	0x6e25aa		488d8c24600b0000		LEAQ 0xb60(SP), CX													
  compile.go:2023	0x6e25b2		440f1139			MOVUPS X15, 0(CX)													
  compile.go:2023	0x6e25b6		440f117910			MOVUPS X15, 0x10(CX)													
  compile.go:2023	0x6e25bb		488b8424b0050000		MOVQ 0x5b0(SP), AX													
  compile.go:2023	0x6e25c3		e8988ddaff			CALL runtime.convT64(SB)												
  compile.go:2023	0x6e25c8		488d0d899ea500			LEAQ 0xa59e89(IP), CX													
  compile.go:2023	0x6e25cf		48898c24600b0000		MOVQ CX, 0xb60(SP)													
  compile.go:2023	0x6e25d7		48898424680b0000		MOVQ AX, 0xb68(SP)													
  compile.go:2022	0x6e25df		488b8c2450050000		MOVQ 0x550(SP), CX													
  compile.go:2022	0x6e25e7		4885c9				TESTQ CX, CX														
  compile.go:2023	0x6e25ea		7406				JE 0x6e25f2														
  compile.go:2023	0x6e25ec		4c8b5108			MOVQ 0x8(CX), R10													
  compile.go:2023	0x6e25f0		eb03				JMP 0x6e25f5														
  compile.go:2023	0x6e25f2		4989ca				MOVQ CX, R10														
  compile.go:2023	0x6e25f5		4c899424700b0000		MOVQ R10, 0xb70(SP)													
  compile.go:2023	0x6e25fd		488b9424300a0000		MOVQ 0xa30(SP), DX													
  compile.go:2023	0x6e2605		48899424780b0000		MOVQ DX, 0xb78(SP)													
  errors.go:26		0x6e260d		488d0527714100			LEAQ 0x417127(IP), AX													
  errors.go:26		0x6e2614		bb16000000			MOVL $0x16, BX														
  errors.go:26		0x6e2619		488d8c24600b0000		LEAQ 0xb60(SP), CX													
  errors.go:26		0x6e2621		bf02000000			MOVL $0x2, DI														
  errors.go:26		0x6e2626		89fe				MOVL DI, SI														
  errors.go:26		0x6e2628		e8d380e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e262d		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e2630		7533				JNE 0x6e2665														
  errors.go:31		0x6e2632		90				NOPL															
  errors.go:65		0x6e2633		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e2638		488d1da9dda600			LEAQ 0xa6dda9(IP), BX													
  errors.go:65		0x6e263f		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e2644		e8f70dd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e2649		48c7400816000000		MOVQ $0x16, 0x8(AX)													
  errors.go:65		0x6e2651		488d15e3704100			LEAQ 0x4170e3(IP), DX													
  errors.go:65		0x6e2658		488910				MOVQ DX, 0(AX)														
  compile.go:2023	0x6e265b		4889c3				MOVQ AX, BX														
  compile.go:2023	0x6e265e		488d0573d8ad00			LEAQ 0xadd873(IP), AX													
  compile.go:2023	0x6e2665		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2023	0x6e2671		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2023	0x6e2679		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e2681		e83ad3d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2023	0x6e2686		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2023	0x6e268e		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2023	0x6e2696		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e269e		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e26a5		5d				POPQ BP															
  compile.go:2144	0x6e26a6		c3				RET															
  compile.go:2013	0x6e26a7		440f11bc24800b0000		MOVUPS X15, 0xb80(SP)													
  compile.go:2013	0x6e26b0		7404				JE 0x6e26b6														
  compile.go:2013	0x6e26b2		488b7f08			MOVQ 0x8(DI), DI													
  compile.go:2013	0x6e26b6		4889bc24800b0000		MOVQ DI, 0xb80(SP)													
  compile.go:2013	0x6e26be		4889b424880b0000		MOVQ SI, 0xb88(SP)													
  errors.go:26		0x6e26c6		488d053fb24100			LEAQ 0x41b23f(IP), AX													
  errors.go:26		0x6e26cd		bb1a000000			MOVL $0x1a, BX														
  errors.go:26		0x6e26d2		488d8c24800b0000		LEAQ 0xb80(SP), CX													
  errors.go:26		0x6e26da		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e26df		89fe				MOVL DI, SI														
  errors.go:26		0x6e26e1		e81a80e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e26e6		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e26e9		7536				JNE 0x6e2721														
  errors.go:31		0x6e26eb		90				NOPL															
  errors.go:65		0x6e26ec		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e26f1		488d1df0dca600			LEAQ 0xa6dcf0(IP), BX													
  errors.go:65		0x6e26f8		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e26fd		0f1f00				NOPL 0(AX)														
  errors.go:65		0x6e2700		e83b0dd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e2705		48c740081a000000		MOVQ $0x1a, 0x8(AX)													
  errors.go:65		0x6e270d		488d15f8b14100			LEAQ 0x41b1f8(IP), DX													
  errors.go:65		0x6e2714		488910				MOVQ DX, 0(AX)														
  compile.go:2013	0x6e2717		4889c3				MOVQ AX, BX														
  compile.go:2013	0x6e271a		488d05b7d7ad00			LEAQ 0xadd7b7(IP), AX													
  compile.go:2013	0x6e2721		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2013	0x6e272d		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2013	0x6e2735		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2013	0x6e273d		0f1f00				NOPL 0(AX)														
  compile.go:2144	0x6e2740		e87bd2d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2013	0x6e2745		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2013	0x6e274d		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2013	0x6e2755		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e275d		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2764		5d				POPQ BP															
  compile.go:2144	0x6e2765		c3				RET															
  compile.go:1999	0x6e2766		440f11bc24900b0000		MOVUPS X15, 0xb90(SP)													
  compile.go:1998	0x6e276f		4885c0				TESTQ AX, AX														
  compile.go:1999	0x6e2772		7404				JE 0x6e2778														
  compile.go:1999	0x6e2774		488b4008			MOVQ 0x8(AX), AX													
  compile.go:1999	0x6e2778		48898424900b0000		MOVQ AX, 0xb90(SP)													
  compile.go:1999	0x6e2780		48899c24980b0000		MOVQ BX, 0xb98(SP)													
  errors.go:26		0x6e2788		488d057db14100			LEAQ 0x41b17d(IP), AX													
  errors.go:26		0x6e278f		bb1a000000			MOVL $0x1a, BX														
  errors.go:26		0x6e2794		488d8c24900b0000		LEAQ 0xb90(SP), CX													
  errors.go:26		0x6e279c		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e27a1		89fe				MOVL DI, SI														
  errors.go:26		0x6e27a3		e8587fe1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e27a8		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e27ab		7534				JNE 0x6e27e1														
  errors.go:31		0x6e27ad		90				NOPL															
  errors.go:65		0x6e27ae		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e27b3		488d1d2edca600			LEAQ 0xa6dc2e(IP), BX													
  errors.go:65		0x6e27ba		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e27bf		90				NOPL															
  errors.go:65		0x6e27c0		e87b0cd4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e27c5		48c740081a000000		MOVQ $0x1a, 0x8(AX)													
  errors.go:65		0x6e27cd		488d1538b14100			LEAQ 0x41b138(IP), DX													
  errors.go:65		0x6e27d4		488910				MOVQ DX, 0(AX)														
  compile.go:1999	0x6e27d7		4889c3				MOVQ AX, BX														
  compile.go:1999	0x6e27da		488d05f7d6ad00			LEAQ 0xadd6f7(IP), AX													
  compile.go:1999	0x6e27e1		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:1999	0x6e27ed		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:1999	0x6e27f5		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:1999	0x6e27fd		0f1f00				NOPL 0(AX)														
  compile.go:2144	0x6e2800		e8bbd1d6ff			CALL runtime.deferreturn(SB)												
  compile.go:1999	0x6e2805		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:1999	0x6e280d		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:1999	0x6e2815		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e281d		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2824		5d				POPQ BP															
  compile.go:2144	0x6e2825		c3				RET															
  compile.go:2071	0x6e2826		4c8ba424900a0000		MOVQ 0xa90(SP), R12													
  compile.go:2071	0x6e282e		4d85e4				TESTQ R12, R12														
  compile.go:2071	0x6e2831		0f8527010000			JNE 0x6e295e														
  compile.go:2076	0x6e2837		4c8ba424980a0000		MOVQ 0xa98(SP), R12													
  compile.go:2076	0x6e283f		90				NOPL															
  compile.go:2076	0x6e2840		4d85e4				TESTQ R12, R12														
  compile.go:2076	0x6e2843		0f84c0010000			JE 0x6e2a09														
  compile.go:2077	0x6e2849		4c8b9424c00d0000		MOVQ 0xdc0(SP), R10													
  compile.go:2077	0x6e2851		4c8bac24b0070000		MOVQ 0x7b0(SP), R13													
  compile.go:2077	0x6e2859		4c892c24			MOVQ R13, 0(SP)														
  compile.go:2077	0x6e285d		488bbc2458050000		MOVQ 0x558(SP), DI													
  compile.go:2077	0x6e2865		48897c2408			MOVQ DI, 0x8(SP)													
  compile.go:2077	0x6e286a		48897c2410			MOVQ DI, 0x10(SP)													
  compile.go:2077	0x6e286f		4c8bac2478080000		MOVQ 0x878(SP), R13													
  compile.go:2077	0x6e2877		4c896c2418			MOVQ R13, 0x18(SP)													
  compile.go:2077	0x6e287c		4889542420			MOVQ DX, 0x20(SP)													
  compile.go:2077	0x6e2881		4889742428			MOVQ SI, 0x28(SP)													
  compile.go:2077	0x6e2886		488b942480080000		MOVQ 0x880(SP), DX													
  compile.go:2077	0x6e288e		4889542430			MOVQ DX, 0x30(SP)													
  compile.go:2077	0x6e2893		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:2077	0x6e289b		4889542438			MOVQ DX, 0x38(SP)													
  compile.go:2077	0x6e28a0		4889542440			MOVQ DX, 0x40(SP)													
  compile.go:2077	0x6e28a5		4c89642448			MOVQ R12, 0x48(SP)													
  compile.go:2077	0x6e28aa		4c897c2450			MOVQ R15, 0x50(SP)													
  compile.go:2077	0x6e28af		488b9424e0050000		MOVQ 0x5e0(SP), DX													
  compile.go:2077	0x6e28b7		4889542458			MOVQ DX, 0x58(SP)													
  compile.go:2077	0x6e28bc		488b8424800a0000		MOVQ 0xa80(SP), AX													
  compile.go:2077	0x6e28c4		488b9c24080b0000		MOVQ 0xb08(SP), BX													
  compile.go:2077	0x6e28cc		4889f9				MOVQ DI, CX														
  compile.go:2077	0x6e28cf		488bb42488080000		MOVQ 0x888(SP), SI													
  compile.go:2077	0x6e28d7		4c8b842420050000		MOVQ 0x520(SP), R8													
  compile.go:2077	0x6e28df		4d89c1				MOVQ R8, R9														
  compile.go:2077	0x6e28e2		4531db				XORL R11, R11														
  compile.go:2077	0x6e28e5		e856cbfdff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.shareAdapterTailsCodeBufferAMD64(SB)		
  compile.go:2078	0x6e28ea		4885db				TESTQ BX, BX														
  compile.go:2078	0x6e28ed		752d				JNE 0x6e291c														
  compile.go:2086	0x6e28ef		488b942400050000		MOVQ 0x500(SP), DX													
  compile.go:2086	0x6e28f7		488bb42408050000		MOVQ 0x508(SP), SI													
  plugin_machine.go:554	0x6e28ff		448b8c2464030000		MOVL 0x364(SP), R9													
  compile.go:2125	0x6e2907		4c8b942470050000		MOVQ 0x570(SP), R10													
  compile.go:2126	0x6e290f		4c8bac2478050000		MOVQ 0x578(SP), R13													
  compile.go:2078	0x6e2917		e9ed000000			JMP 0x6e2a09														
  compile.go:2079	0x6e291c		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2079	0x6e2928		48899c2400070000		MOVQ BX, 0x700(SP)													
  compile.go:2079	0x6e2930		48898c2408070000		MOVQ CX, 0x708(SP)													
  compile.go:2144	0x6e2938		e883d0d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2079	0x6e293d		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2079	0x6e2945		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2079	0x6e294d		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e2955		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e295c		5d				POPQ BP															
  compile.go:2144	0x6e295d		c3				RET															
  compile.go:2072	0x6e295e		4c8b9424c00d0000		MOVQ 0xdc0(SP), R10													
  compile.go:2072	0x6e2966		4c8bac24b0070000		MOVQ 0x7b0(SP), R13													
  compile.go:2072	0x6e296e		4c892c24			MOVQ R13, 0(SP)														
  compile.go:2072	0x6e2972		488b8c2458050000		MOVQ 0x558(SP), CX													
  compile.go:2072	0x6e297a		48894c2408			MOVQ CX, 0x8(SP)													
  compile.go:2072	0x6e297f		48894c2410			MOVQ CX, 0x10(SP)													
  compile.go:2072	0x6e2984		4c8bac2478080000		MOVQ 0x878(SP), R13													
  compile.go:2072	0x6e298c		4c896c2418			MOVQ R13, 0x18(SP)													
  compile.go:2072	0x6e2991		4889542420			MOVQ DX, 0x20(SP)													
  compile.go:2072	0x6e2996		4889742428			MOVQ SI, 0x28(SP)													
  compile.go:2072	0x6e299b		488b942480080000		MOVQ 0x880(SP), DX													
  compile.go:2072	0x6e29a3		4889542430			MOVQ DX, 0x30(SP)													
  compile.go:2072	0x6e29a8		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:2072	0x6e29b0		4889542438			MOVQ DX, 0x38(SP)													
  compile.go:2072	0x6e29b5		4889542440			MOVQ DX, 0x40(SP)													
  compile.go:2072	0x6e29ba		4c89642448			MOVQ R12, 0x48(SP)													
  compile.go:2072	0x6e29bf		48897c2450			MOVQ DI, 0x50(SP)													
  compile.go:2072	0x6e29c4		488b9424d0050000		MOVQ 0x5d0(SP), DX													
  compile.go:2072	0x6e29cc		4889542458			MOVQ DX, 0x58(SP)													
  compile.go:2072	0x6e29d1		488b8424800a0000		MOVQ 0xa80(SP), AX													
  compile.go:2072	0x6e29d9		488b9c24080b0000		MOVQ 0xb08(SP), BX													
  compile.go:2072	0x6e29e1		4889cf				MOVQ CX, DI														
  compile.go:2072	0x6e29e4		488bb42488080000		MOVQ 0x888(SP), SI													
  compile.go:2072	0x6e29ec		4c8b842420050000		MOVQ 0x520(SP), R8													
  compile.go:2072	0x6e29f4		4d89c1				MOVQ R8, R9														
  compile.go:2072	0x6e29f7		4531db				XORL R11, R11														
  compile.go:2072	0x6e29fa		e8c1310800			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.shareAdaptersCodeBufferAMD64(SB)			
  compile.go:2072	0x6e29ff		90				NOPL															
  compile.go:2073	0x6e2a00		4885db				TESTQ BX, BX														
  compile.go:2073	0x6e2a03		0f8528090000			JNE 0x6e3331														
  compile.go:2082	0x6e2a09		488b9424d8080000		MOVQ 0x8d8(SP), DX													
  compile.go:2082	0x6e2a11		48891424			MOVQ DX, 0(SP)														
  compile.go:2082	0x6e2a15		488b942428050000		MOVQ 0x528(SP), DX													
  compile.go:2082	0x6e2a1d		4889542408			MOVQ DX, 0x8(SP)													
  compile.go:2082	0x6e2a22		488b942408060000		MOVQ 0x608(SP), DX													
  compile.go:2082	0x6e2a2a		4889542410			MOVQ DX, 0x10(SP)													
  compile.go:2082	0x6e2a2f		488d542418			LEAQ 0x18(SP), DX													
  compile.go:2082	0x6e2a34		4c8da42490080000		LEAQ 0x890(SP), R12													
  compile.go:2082	0x6e2a3c		450f103424			MOVUPS 0(R12), X14													
  compile.go:2082	0x6e2a41		440f1132			MOVUPS X14, 0(DX)													
  compile.go:2082	0x6e2a45		450f10742410			MOVUPS 0x10(R12), X14													
  compile.go:2082	0x6e2a4b		440f117210			MOVUPS X14, 0x10(DX)													
  compile.go:2082	0x6e2a50		450f10742420			MOVUPS 0x20(R12), X14													
  compile.go:2082	0x6e2a56		440f117220			MOVUPS X14, 0x20(DX)													
  compile.go:2082	0x6e2a5b		450f10742430			MOVUPS 0x30(R12), X14													
  compile.go:2082	0x6e2a61		440f117230			MOVUPS X14, 0x30(DX)													
  compile.go:2082	0x6e2a66		488b8424080b0000		MOVQ 0xb08(SP), AX													
  compile.go:2082	0x6e2a6e		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:2082	0x6e2a76		4889d9				MOVQ BX, CX														
  compile.go:2082	0x6e2a79		488bbc2488080000		MOVQ 0x888(SP), DI													
  compile.go:2082	0x6e2a81		488bb42420050000		MOVQ 0x520(SP), SI													
  compile.go:2082	0x6e2a89		4989f0				MOVQ SI, R8														
  compile.go:2082	0x6e2a8c		4c8b8c24b0070000		MOVQ 0x7b0(SP), R9													
  compile.go:2082	0x6e2a94		4989ca				MOVQ CX, R10														
  compile.go:2082	0x6e2a97		4989cb				MOVQ CX, R11														
  compile.go:2082	0x6e2a9a		e8613f0000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.finalizeOmittedInlineEntriesAMD64(SB)		
  compile.go:2082	0x6e2a9f		90				NOPL															
  compile.go:2082	0x6e2aa0		4885c0				TESTQ AX, AX														
  compile.go:2082	0x6e2aa3		0f8546080000			JNE 0x6e32ef														
  compile.go:2085	0x6e2aa9		90				NOPL															
  code_buffer.go:156	0x6e2aaa		488b9424800a0000		MOVQ 0xa80(SP), DX													
  code_buffer.go:156	0x6e2ab2		4885d2				TESTQ DX, DX														
  code_buffer.go:156	0x6e2ab5		7417				JE 0x6e2ace														
  code_buffer.go:156	0x6e2ab7		807a2300			CMPB 0x23(DX), $0x0													
  code_buffer.go:156	0x6e2abb		7511				JNE 0x6e2ace														
  code_buffer.go:159	0x6e2abd		4c8b4a10			MOVQ 0x10(DX), R9													
  code_buffer.go:159	0x6e2ac1		4c8b5218			MOVQ 0x18(DX), R10													
  code_buffer.go:159	0x6e2ac5		4d39ca				CMPQ R10, R9														
  code_buffer.go:159	0x6e2ac8		0f87b70c0000			JA 0x6e3785														
  compile.go:2086	0x6e2ace		488b842478080000		MOVQ 0x878(SP), AX													
  compile.go:2086	0x6e2ad6		488b9c2400050000		MOVQ 0x500(SP), BX													
  compile.go:2086	0x6e2ade		488b8c2408050000		MOVQ 0x508(SP), CX													
  compile.go:2086	0x6e2ae6		488bbc2480080000		MOVQ 0x880(SP), DI													
  compile.go:2086	0x6e2aee		488bb42410050000		MOVQ 0x510(SP), SI													
  compile.go:2086	0x6e2af6		4989f0				MOVQ SI, R8														
  compile.go:2086	0x6e2af9		e822640800			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.buildModuleLiteralIsland(SB)			
  compile.go:2086	0x6e2afe		4889bc2468080000		MOVQ DI, 0x868(SP)													
  compile.go:2086	0x6e2b06		4889b424e0040000		MOVQ SI, 0x4e0(SP)													
  compile.go:2086	0x6e2b0e		4c898424e8040000		MOVQ R8, 0x4e8(SP)													
  compile.go:2088	0x6e2b16		4885db				TESTQ BX, BX														
  compile.go:2088	0x6e2b19		0f8412010000			JE 0x6e2c31														
  code_buffer.go:156	0x6e2b1f		488b9424800a0000		MOVQ 0xa80(SP), DX													
  code_buffer.go:156	0x6e2b27		4885d2				TESTQ DX, DX														
  code_buffer.go:156	0x6e2b2a		7419				JE 0x6e2b45														
  code_buffer.go:156	0x6e2b2c		807a2300			CMPB 0x23(DX), $0x0													
  code_buffer.go:156	0x6e2b30		7513				JNE 0x6e2b45														
  code_buffer.go:159	0x6e2b32		4c8b4a10			MOVQ 0x10(DX), R9													
  code_buffer.go:159	0x6e2b36		4c8b5218			MOVQ 0x18(DX), R10													
  code_buffer.go:159	0x6e2b3a		4d39ca				CMPQ R10, R9														
  code_buffer.go:159	0x6e2b3d		7609				JBE 0x6e2b48														
  code_buffer.go:159	0x6e2b3f		90				NOPL															
  code_buffer.go:159	0x6e2b40		e93a0c0000			JMP 0x6e377f														
  code_buffer.go:159	0x6e2b45		4531d2				XORL R10, R10														
  compile.go:2089	0x6e2b48		4c89942470030000		MOVQ R10, 0x370(SP)													
  compile.go:2090	0x6e2b50		4889cf				MOVQ CX, DI														
  compile.go:2090	0x6e2b53		4889d9				MOVQ BX, CX														
  compile.go:2090	0x6e2b56		4889c3				MOVQ AX, BX														
  compile.go:2090	0x6e2b59		4889d0				MOVQ DX, AX														
  compile.go:2090	0x6e2b5c		0f1f4000			NOPL 0(AX)														
  compile.go:2090	0x6e2b60		e83bd9fbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).Append(SB)							
  compile.go:2090	0x6e2b65		4885c0				TESTQ AX, AX														
  compile.go:2090	0x6e2b68		0f84b9000000			JE 0x6e2c27														
  compile.go:2091	0x6e2b6e		440f11bc24400b0000		MOVUPS X15, 0xb40(SP)													
  compile.go:2091	0x6e2b77		7404				JE 0x6e2b7d														
  compile.go:2091	0x6e2b79		488b4008			MOVQ 0x8(AX), AX													
  compile.go:2091	0x6e2b7d		48898424400b0000		MOVQ AX, 0xb40(SP)													
  compile.go:2091	0x6e2b85		48899c24480b0000		MOVQ BX, 0xb48(SP)													
  errors.go:26		0x6e2b8d		488d05381e4200			LEAQ 0x421e38(IP), AX													
  errors.go:26		0x6e2b94		bb20000000			MOVL $0x20, BX														
  errors.go:26		0x6e2b99		488d8c24400b0000		LEAQ 0xb40(SP), CX													
  errors.go:26		0x6e2ba1		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e2ba6		89fe				MOVL DI, SI														
  errors.go:26		0x6e2ba8		e8537be1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e2bad		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e2bb0		7533				JNE 0x6e2be5														
  errors.go:31		0x6e2bb2		90				NOPL															
  errors.go:65		0x6e2bb3		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e2bb8		488d1d29d8a600			LEAQ 0xa6d829(IP), BX													
  errors.go:65		0x6e2bbf		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e2bc4		e87708d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e2bc9		48c7400820000000		MOVQ $0x20, 0x8(AX)													
  errors.go:65		0x6e2bd1		488d15f41d4200			LEAQ 0x421df4(IP), DX													
  errors.go:65		0x6e2bd8		488910				MOVQ DX, 0(AX)														
  compile.go:2091	0x6e2bdb		4889c3				MOVQ AX, BX														
  compile.go:2091	0x6e2bde		488d05f3d2ad00			LEAQ 0xadd2f3(IP), AX													
  compile.go:2091	0x6e2be5		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2091	0x6e2bf1		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2091	0x6e2bf9		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e2c01		e8bacdd6ff			CALL runtime.deferreturn(SB)												
  compile.go:2091	0x6e2c06		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2091	0x6e2c0e		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2091	0x6e2c16		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e2c1e		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2c25		5d				POPQ BP															
  compile.go:2144	0x6e2c26		c3				RET															
  compile.go:2144	0x6e2c27		488b842470030000		MOVQ 0x370(SP), AX													
  compile.go:2090	0x6e2c2f		eb07				JMP 0x6e2c38														
  compile.go:2090	0x6e2c31		48c7c0ffffffff			MOVQ $-0x1, AX														
  compile.go:2090	0x6e2c38		4889842418050000		MOVQ AX, 0x518(SP)													
  compile.go:2096	0x6e2c40		488b8424b0070000		MOVQ 0x7b0(SP), AX													
  compile.go:2096	0x6e2c48		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:2096	0x6e2c50		4889d9				MOVQ BX, CX														
  compile.go:2096	0x6e2c53		e808750400			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.buildModuleGCSharedStubs(SB)			
  compile.go:2096	0x6e2c58		0f100424			MOVUPS 0(SP), X0													
  compile.go:2096	0x6e2c5c		0f118424f0060000		MOVUPS X0, 0x6f0(SP)													
  compile.go:2096	0x6e2c64		0f108424f0060000		MOVUPS 0x6f0(SP), X0													
  compile.go:2096	0x6e2c6c		0f11842488040000		MOVUPS X0, 0x488(SP)													
  compile.go:2098	0x6e2c74		4885db				TESTQ BX, BX														
  compile.go:2098	0x6e2c77		0f847e020000			JE 0x6e2efb														
  code_buffer.go:156	0x6e2c7d		488b9424800a0000		MOVQ 0xa80(SP), DX													
  code_buffer.go:156	0x6e2c85		4885d2				TESTQ DX, DX														
  code_buffer.go:156	0x6e2c88		741b				JE 0x6e2ca5														
  code_buffer.go:156	0x6e2c8a		807a2300			CMPB 0x23(DX), $0x0													
  code_buffer.go:156	0x6e2c8e		7515				JNE 0x6e2ca5														
  code_buffer.go:159	0x6e2c90		488b7210			MOVQ 0x10(DX), SI													
  code_buffer.go:159	0x6e2c94		4c8b4218			MOVQ 0x18(DX), R8													
  code_buffer.go:159	0x6e2c98		4939f0				CMPQ R8, SI														
  code_buffer.go:159	0x6e2c9b		760b				JBE 0x6e2ca8														
  code_buffer.go:159	0x6e2c9d		0f1f00				NOPL 0(AX)														
  code_buffer.go:159	0x6e2ca0		e9d50a0000			JMP 0x6e377a														
  code_buffer.go:159	0x6e2ca5		4531c0				XORL R8, R8														
  compile.go:2099	0x6e2ca8		4183e00f			ANDL $0xf, R8														
  compile.go:2099	0x6e2cac		498d70f0			LEAQ -0x10(R8), SI													
  compile.go:2099	0x6e2cb0		48f7de				NEGQ SI															
  compile.go:2099	0x6e2cb3		4883e6f0			ANDQ $-0x10, SI														
  compile.go:2099	0x6e2cb7		4a8d3406			LEAQ 0(SI)(R8*1), SI													
  compile.go:2099	0x6e2cbb		488d76f0			LEAQ -0x10(SI), SI													
  compile.go:2099	0x6e2cbf		48f7de				NEGQ SI															
  compile.go:2099	0x6e2cc2		4885f6				TESTQ SI, SI														
  compile.go:2099	0x6e2cc5		7508				JNE 0x6e2ccf														
  code_buffer.go:156	0x6e2cc7		4885d2				TESTQ DX, DX														
  compile.go:2099	0x6e2cca		e916010000			JMP 0x6e2de5														
  compile.go:2096	0x6e2ccf		48898c24a0040000		MOVQ CX, 0x4a0(SP)													
  compile.go:2096	0x6e2cd7		48899c2498040000		MOVQ BX, 0x498(SP)													
  compile.go:2096	0x6e2cdf		4889842428070000		MOVQ AX, 0x728(SP)													
  compile.go:2100	0x6e2ce7		4889d0				MOVQ DX, AX														
  compile.go:2100	0x6e2cea		4889f3				MOVQ SI, BX														
  compile.go:2100	0x6e2ced		e84edafbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).AppendZeros(SB)						
  compile.go:2100	0x6e2cf2		4885c0				TESTQ AX, AX														
  compile.go:2100	0x6e2cf5		0f84bf000000			JE 0x6e2dba														
  compile.go:2101	0x6e2cfb		440f11bc24300b0000		MOVUPS X15, 0xb30(SP)													
  compile.go:2100	0x6e2d04		4885c0				TESTQ AX, AX														
  compile.go:2101	0x6e2d07		7404				JE 0x6e2d0d														
  compile.go:2101	0x6e2d09		488b4008			MOVQ 0x8(AX), AX													
  compile.go:2101	0x6e2d0d		48898424300b0000		MOVQ AX, 0xb30(SP)													
  compile.go:2101	0x6e2d15		48899c24380b0000		MOVQ BX, 0xb38(SP)													
  errors.go:26		0x6e2d1d		488d05d4f94100			LEAQ 0x41f9d4(IP), AX													
  errors.go:26		0x6e2d24		bb1e000000			MOVL $0x1e, BX														
  errors.go:26		0x6e2d29		488d8c24300b0000		LEAQ 0xb30(SP), CX													
  errors.go:26		0x6e2d31		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e2d36		89fe				MOVL DI, SI														
  errors.go:26		0x6e2d38		e8c379e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e2d3d		0f1f00				NOPL 0(AX)														
  errors.go:26		0x6e2d40		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e2d43		7533				JNE 0x6e2d78														
  errors.go:31		0x6e2d45		90				NOPL															
  errors.go:65		0x6e2d46		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e2d4b		488d1d96d6a600			LEAQ 0xa6d696(IP), BX													
  errors.go:65		0x6e2d52		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e2d57		e8e406d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e2d5c		48c740081e000000		MOVQ $0x1e, 0x8(AX)													
  errors.go:65		0x6e2d64		488d158df94100			LEAQ 0x41f98d(IP), DX													
  errors.go:65		0x6e2d6b		488910				MOVQ DX, 0(AX)														
  compile.go:2101	0x6e2d6e		4889c3				MOVQ AX, BX														
  compile.go:2101	0x6e2d71		488d0560d1ad00			LEAQ 0xadd160(IP), AX													
  compile.go:2101	0x6e2d78		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2101	0x6e2d84		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2101	0x6e2d8c		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e2d94		e827ccd6ff			CALL runtime.deferreturn(SB)												
  compile.go:2101	0x6e2d99		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2101	0x6e2da1		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2101	0x6e2da9		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e2db1		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2db8		5d				POPQ BP															
  compile.go:2144	0x6e2db9		c3				RET															
  code_buffer.go:156	0x6e2dba		488b8424800a0000		MOVQ 0xa80(SP), AX													
  code_buffer.go:156	0x6e2dc2		4885c0				TESTQ AX, AX														
  compile.go:2105	0x6e2dc5		488b842428070000		MOVQ 0x728(SP), AX													
  compile.go:2105	0x6e2dcd		488b8c24a0040000		MOVQ 0x4a0(SP), CX													
  code_buffer.go:156	0x6e2dd5		488b9424800a0000		MOVQ 0xa80(SP), DX													
  compile.go:2105	0x6e2ddd		488b9c2498040000		MOVQ 0x498(SP), BX													
  code_buffer.go:156	0x6e2de5		7418				JE 0x6e2dff														
  code_buffer.go:156	0x6e2de7		807a2300			CMPB 0x23(DX), $0x0													
  code_buffer.go:156	0x6e2deb		7512				JNE 0x6e2dff														
  code_buffer.go:159	0x6e2ded		488b7210			MOVQ 0x10(DX), SI													
  code_buffer.go:159	0x6e2df1		4c8b4218			MOVQ 0x18(DX), R8													
  code_buffer.go:159	0x6e2df5		4c39c6				CMPQ SI, R8														
  code_buffer.go:159	0x6e2df8		7308				JAE 0x6e2e02														
  code_buffer.go:159	0x6e2dfa		e976090000			JMP 0x6e3775														
  code_buffer.go:159	0x6e2dff		4531c0				XORL R8, R8														
  compile.go:2104	0x6e2e02		4c89842468030000		MOVQ R8, 0x368(SP)													
  compile.go:2105	0x6e2e0a		4889cf				MOVQ CX, DI														
  compile.go:2105	0x6e2e0d		4889d9				MOVQ BX, CX														
  compile.go:2105	0x6e2e10		4889c3				MOVQ AX, BX														
  compile.go:2105	0x6e2e13		4889d0				MOVQ DX, AX														
  compile.go:2105	0x6e2e16		e885d6fbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).Append(SB)							
  compile.go:2105	0x6e2e1b		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:2105	0x6e2e20		4885c0				TESTQ AX, AX														
  compile.go:2105	0x6e2e23		0f84bd000000			JE 0x6e2ee6														
  compile.go:2106	0x6e2e29		440f11bc24200b0000		MOVUPS X15, 0xb20(SP)													
  compile.go:2105	0x6e2e32		4885c0				TESTQ AX, AX														
  compile.go:2106	0x6e2e35		7404				JE 0x6e2e3b														
  compile.go:2106	0x6e2e37		488b4008			MOVQ 0x8(AX), AX													
  compile.go:2106	0x6e2e3b		48898424200b0000		MOVQ AX, 0xb20(SP)													
  compile.go:2106	0x6e2e43		48899c24280b0000		MOVQ BX, 0xb28(SP)													
  errors.go:26		0x6e2e4b		488d059a1b4200			LEAQ 0x421b9a(IP), AX													
  errors.go:26		0x6e2e52		bb20000000			MOVL $0x20, BX														
  errors.go:26		0x6e2e57		488d8c24200b0000		LEAQ 0xb20(SP), CX													
  errors.go:26		0x6e2e5f		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e2e64		89fe				MOVL DI, SI														
  errors.go:26		0x6e2e66		e89578e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e2e6b		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e2e6e		7533				JNE 0x6e2ea3														
  errors.go:31		0x6e2e70		90				NOPL															
  errors.go:65		0x6e2e71		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e2e76		488d1d6bd5a600			LEAQ 0xa6d56b(IP), BX													
  errors.go:65		0x6e2e7d		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e2e82		e8b905d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e2e87		48c7400820000000		MOVQ $0x20, 0x8(AX)													
  errors.go:65		0x6e2e8f		488d15561b4200			LEAQ 0x421b56(IP), DX													
  errors.go:65		0x6e2e96		488910				MOVQ DX, 0(AX)														
  compile.go:2106	0x6e2e99		4889c3				MOVQ AX, BX														
  compile.go:2106	0x6e2e9c		488d0535d0ad00			LEAQ 0xadd035(IP), AX													
  compile.go:2106	0x6e2ea3		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2106	0x6e2eaf		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2106	0x6e2eb7		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2106	0x6e2ebf		90				NOPL															
  compile.go:2144	0x6e2ec0		e8fbcad6ff			CALL runtime.deferreturn(SB)												
  compile.go:2106	0x6e2ec5		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2106	0x6e2ecd		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2106	0x6e2ed5		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e2edd		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e2ee4		5d				POPQ BP															
  compile.go:2144	0x6e2ee5		c3				RET															
  code_buffer.go:156	0x6e2ee6		488b9424800a0000		MOVQ 0xa80(SP), DX													
  code_buffer.go:156	0x6e2eee		4885d2				TESTQ DX, DX														
  code_buffer.go:156	0x6e2ef1		488b842468030000		MOVQ 0x368(SP), AX													
  compile.go:2105	0x6e2ef9		eb12				JMP 0x6e2f0d														
  code_buffer.go:156	0x6e2efb		488b9424800a0000		MOVQ 0xa80(SP), DX													
  code_buffer.go:156	0x6e2f03		4885d2				TESTQ DX, DX														
  code_buffer.go:156	0x6e2f06		48c7c0ffffffff			MOVQ $-0x1, AX														
  code_buffer.go:156	0x6e2f0d		741f				JE 0x6e2f2e														
  code_buffer.go:156	0x6e2f0f		807a2300			CMPB 0x23(DX), $0x0													
  code_buffer.go:156	0x6e2f13		7519				JNE 0x6e2f2e														
  code_buffer.go:159	0x6e2f15		4c8b6210			MOVQ 0x10(DX), R12													
  code_buffer.go:159	0x6e2f19		488b4a18			MOVQ 0x18(DX), CX													
  code_buffer.go:159	0x6e2f1d		0f1f00				NOPL 0(AX)														
  code_buffer.go:159	0x6e2f20		4c39e1				CMPQ CX, R12														
  code_buffer.go:159	0x6e2f23		0f8747080000			JA 0x6e3770														
  code_buffer.go:159	0x6e2f29		4c8b22				MOVQ 0(DX), R12														
  compile.go:2114	0x6e2f2c		eb05				JMP 0x6e2f33														
  compile.go:2114	0x6e2f2e		31c9				XORL CX, CX														
  compile.go:2114	0x6e2f30		4531e4				XORL R12, R12														
  compile.go:2114	0x6e2f33		48898c2480030000		MOVQ CX, 0x380(SP)													
  compile.go:2114	0x6e2f3b		4c89a42410070000		MOVQ R12, 0x710(SP)													
  compile.go:2119	0x6e2f43		488b9424b0070000		MOVQ 0x7b0(SP), DX													
  compile.go:2119	0x6e2f4b		48891424			MOVQ DX, 0(SP)														
  compile.go:2119	0x6e2f4f		4c8b842458050000		MOVQ 0x558(SP), R8													
  compile.go:2119	0x6e2f57		4c89442408			MOVQ R8, 0x8(SP)													
  compile.go:2119	0x6e2f5c		4c89442410			MOVQ R8, 0x10(SP)													
  compile.go:2119	0x6e2f61		4889442418			MOVQ AX, 0x18(SP)													
  compile.go:2119	0x6e2f66		0f10842488040000		MOVUPS 0x488(SP), X0													
  compile.go:2119	0x6e2f6e		0f11442420			MOVUPS X0, 0x20(SP)													
  compile.go:2119	0x6e2f73		4c89e0				MOVQ R12, AX														
  compile.go:2119	0x6e2f76		4889cb				MOVQ CX, BX														
  compile.go:2119	0x6e2f79		488bbc24080b0000		MOVQ 0xb08(SP), DI													
  compile.go:2119	0x6e2f81		4c89c6				MOVQ R8, SI														
  compile.go:2119	0x6e2f84		4c8b8c2488080000		MOVQ 0x888(SP), R9													
  compile.go:2119	0x6e2f8c		4c8b942420050000		MOVQ 0x520(SP), R10													
  compile.go:2119	0x6e2f94		4d89d3				MOVQ R10, R11														
  compile.go:2119	0x6e2f97		e824400000			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.patchModuleRelocs(SB)				
  compile.go:2119	0x6e2f9c		0f1f4000			NOPL 0(AX)														
  compile.go:2119	0x6e2fa0		4885c0				TESTQ AX, AX														
  compile.go:2119	0x6e2fa3		0f8504030000			JNE 0x6e32ad														
  compile.go:2122	0x6e2fa9		488b942480080000		MOVQ 0x880(SP), DX													
  compile.go:2122	0x6e2fb1		48891424			MOVQ DX, 0(SP)														
  compile.go:2122	0x6e2fb5		488b942410050000		MOVQ 0x510(SP), DX													
  compile.go:2122	0x6e2fbd		4889542408			MOVQ DX, 0x8(SP)													
  compile.go:2122	0x6e2fc2		4889542410			MOVQ DX, 0x10(SP)													
  compile.go:2122	0x6e2fc7		488b942418050000		MOVQ 0x518(SP), DX													
  compile.go:2122	0x6e2fcf		4889542418			MOVQ DX, 0x18(SP)													
  compile.go:2122	0x6e2fd4		488b942468080000		MOVQ 0x868(SP), DX													
  compile.go:2122	0x6e2fdc		4889542420			MOVQ DX, 0x20(SP)													
  compile.go:2122	0x6e2fe1		488b9424e0040000		MOVQ 0x4e0(SP), DX													
  compile.go:2122	0x6e2fe9		4889542428			MOVQ DX, 0x28(SP)													
  compile.go:2122	0x6e2fee		488b9424e8040000		MOVQ 0x4e8(SP), DX													
  compile.go:2122	0x6e2ff6		4889542430			MOVQ DX, 0x30(SP)													
  compile.go:2122	0x6e2ffb		488b842410070000		MOVQ 0x710(SP), AX													
  compile.go:2122	0x6e3003		488b9c2480030000		MOVQ 0x380(SP), BX													
  compile.go:2122	0x6e300b		4889d9				MOVQ BX, CX														
  compile.go:2122	0x6e300e		488bbc24080b0000		MOVQ 0xb08(SP), DI													
  compile.go:2122	0x6e3016		488bb42458050000		MOVQ 0x558(SP), SI													
  compile.go:2122	0x6e301e		4989f0				MOVQ SI, R8														
  compile.go:2122	0x6e3021		4c8b8c2478080000		MOVQ 0x878(SP), R9													
  compile.go:2122	0x6e3029		4c8b942400050000		MOVQ 0x500(SP), R10													
  compile.go:2122	0x6e3031		4c8b9c2408050000		MOVQ 0x508(SP), R11													
  compile.go:2122	0x6e3039		e842630800			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.patchModuleLiteralRelocs(SB)			
  compile.go:2122	0x6e303e		6690				NOPW															
  compile.go:2122	0x6e3040		4885c0				TESTQ AX, AX														
  compile.go:2122	0x6e3043		0f8522020000			JNE 0x6e326b														
  compile.go:2125	0x6e3049		488b9424b0070000		MOVQ 0x7b0(SP), DX													
  compile.go:2125	0x6e3051		48891424			MOVQ DX, 0(SP)														
  compile.go:2125	0x6e3055		488b942458050000		MOVQ 0x558(SP), DX													
  compile.go:2125	0x6e305d		4889542408			MOVQ DX, 0x8(SP)													
  compile.go:2125	0x6e3062		4889542410			MOVQ DX, 0x10(SP)													
  compile.go:2125	0x6e3067		488b9424d0080000		MOVQ 0x8d0(SP), DX													
  compile.go:2125	0x6e306f		4889542418			MOVQ DX, 0x18(SP)													
  compile.go:2125	0x6e3074		488b942410060000		MOVQ 0x610(SP), DX													
  compile.go:2125	0x6e307c		4889542420			MOVQ DX, 0x20(SP)													
  compile.go:2125	0x6e3081		488b942418060000		MOVQ 0x618(SP), DX													
  compile.go:2125	0x6e3089		4889542428			MOVQ DX, 0x28(SP)													
  compile.go:2125	0x6e308e		488b8424380e0000		MOVQ 0xe38(SP), AX													
  compile.go:2125	0x6e3096		488b9c24380a0000		MOVQ 0xa38(SP), BX													
  compile.go:2125	0x6e309e		488b8c2470050000		MOVQ 0x570(SP), CX													
  compile.go:2125	0x6e30a6		4889cf				MOVQ CX, DI														
  compile.go:2125	0x6e30a9		488bb424880a0000		MOVQ 0xa88(SP), SI													
  compile.go:2125	0x6e30b1		4c8b8424b8050000		MOVQ 0x5b8(SP), R8													
  compile.go:2125	0x6e30b9		4c8b8c24c0050000		MOVQ 0x5c0(SP), R9													
  compile.go:2125	0x6e30c1		e89aaeffff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.resolveBoundedPreparedEntries(SB)		
  compile.go:2125	0x6e30c6		48898424380a0000		MOVQ AX, 0xa38(SP)													
  compile.go:2125	0x6e30ce		48899c2468050000		MOVQ BX, 0x568(SP)													
  compile.go:2125	0x6e30d6		48898c2470050000		MOVQ CX, 0x570(SP)													
  compile.go:2126	0x6e30de		4889c7				MOVQ AX, DI														
  compile.go:2126	0x6e30e1		4889de				MOVQ BX, SI														
  compile.go:2126	0x6e30e4		4989c8				MOVQ CX, R8														
  compile.go:2126	0x6e30e7		4c8b8c24880a0000		MOVQ 0xa88(SP), R9													
  compile.go:2126	0x6e30ef		4c8b9424b8050000		MOVQ 0x5b8(SP), R10													
  compile.go:2126	0x6e30f7		4c8b9c24c0050000		MOVQ 0x5c0(SP), R11													
  compile.go:2126	0x6e30ff		488b8424400a0000		MOVQ 0xa40(SP), AX													
  compile.go:2126	0x6e3107		488b9c2478050000		MOVQ 0x578(SP), BX													
  compile.go:2126	0x6e310f		4889d9				MOVQ BX, CX														
  compile.go:2126	0x6e3112		e8c9adffff			CALL github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.retainResolvedPreparedCallers(SB)		
  compile.go:2126	0x6e3117		48898424400a0000		MOVQ AX, 0xa40(SP)													
  compile.go:2126	0x6e311f		48899c2478050000		MOVQ BX, 0x578(SP)													
  compile.go:2126	0x6e3127		48898c2480050000		MOVQ CX, 0x580(SP)													
  compile.go:2132	0x6e312f		80bc24700d000000		CMPB 0xd70(SP), $0x0													
  compile.go:2132	0x6e3137		752c				JNE 0x6e3165														
  compile.go:2139	0x6e3139		c684244703000001		MOVB $0x1, 0x347(SP)													
  compile.go:2460	0x6e3141		488b942410060000		MOVQ 0x610(SP), DX													
  compile.go:2460	0x6e3149		4885d2				TESTQ DX, DX														
  compile.go:2460	0x6e314c		740f				JE 0x6e315d														
  compile.go:2463	0x6e314e		31f6				XORL SI, SI														
  compile.go:2463	0x6e3150		488bbc24d0080000		MOVQ 0x8d0(SP), DI													
  compile.go:2463	0x6e3158		e9ed050000			JMP 0x6e374a														
  compile.go:2463	0x6e315d		31d2				XORL DX, DX														
  compile.go:2463	0x6e315f		90				NOPL															
  compile.go:2140	0x6e3160		e900040000			JMP 0x6e3565														
  compile.go:2133	0x6e3165		488b8424800a0000		MOVQ 0xa80(SP), AX													
  compile.go:2133	0x6e316d		e8eeddfbff			CALL github.com/wago-org/wago/src/core/runtime.(*CodeBuffer).TakeHeap(SB)						
  compile.go:2134	0x6e3172		4885ff				TESTQ DI, DI														
  compile.go:2134	0x6e3175		753b				JNE 0x6e31b2														
  compile.go:2133	0x6e3177		48898c2490050000		MOVQ CX, 0x590(SP)													
  compile.go:2133	0x6e317f		48898424480a0000		MOVQ AX, 0xa48(SP)													
  compile.go:2133	0x6e3187		48899c2488050000		MOVQ BX, 0x588(SP)													
  compile.go:2460	0x6e318f		488b942410060000		MOVQ 0x610(SP), DX													
  compile.go:2460	0x6e3197		4885d2				TESTQ DX, DX														
  compile.go:2460	0x6e319a		740f				JE 0x6e31ab														
  compile.go:2463	0x6e319c		31f6				XORL SI, SI														
  compile.go:2463	0x6e319e		488bbc24d0080000		MOVQ 0x8d0(SP), DI													
  compile.go:2463	0x6e31a6		e98f030000			JMP 0x6e353a														
  compile.go:2463	0x6e31ab		31d2				XORL DX, DX														
  compile.go:2137	0x6e31ad		e9c1010000			JMP 0x6e3373														
  compile.go:2135	0x6e31b2		440f11bc24100b0000		MOVUPS X15, 0xb10(SP)													
  compile.go:2135	0x6e31bb		7404				JE 0x6e31c1														
  compile.go:2135	0x6e31bd		488b7f08			MOVQ 0x8(DI), DI													
  compile.go:2135	0x6e31c1		4889bc24100b0000		MOVQ DI, 0xb10(SP)													
  compile.go:2135	0x6e31c9		4889b424180b0000		MOVQ SI, 0xb18(SP)													
  errors.go:26		0x6e31d1		488d05a4504200			LEAQ 0x4250a4(IP), AX													
  errors.go:26		0x6e31d8		bb23000000			MOVL $0x23, BX														
  errors.go:26		0x6e31dd		488d8c24100b0000		LEAQ 0xb10(SP), CX													
  errors.go:26		0x6e31e5		bf01000000			MOVL $0x1, DI														
  errors.go:26		0x6e31ea		89fe				MOVL DI, SI														
  errors.go:26		0x6e31ec		e80f75e1ff			CALL fmt.errorf(SB)													
  errors.go:26		0x6e31f1		4885c0				TESTQ AX, AX														
  errors.go:26		0x6e31f4		7533				JNE 0x6e3229														
  errors.go:31		0x6e31f6		90				NOPL															
  errors.go:65		0x6e31f7		b810000000			MOVL $0x10, AX														
  errors.go:65		0x6e31fc		488d1de5d1a600			LEAQ 0xa6d1e5(IP), BX													
  errors.go:65		0x6e3203		b901000000			MOVL $0x1, CX														
  errors.go:65		0x6e3208		e83302d4ff			CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)										
  errors.go:65		0x6e320d		48c7400823000000		MOVQ $0x23, 0x8(AX)													
  errors.go:65		0x6e3215		488d1560504200			LEAQ 0x425060(IP), DX													
  errors.go:65		0x6e321c		488910				MOVQ DX, 0(AX)														
  compile.go:2135	0x6e321f		4889c3				MOVQ AX, BX														
  compile.go:2135	0x6e3222		488d05afccad00			LEAQ 0xadccaf(IP), AX													
  compile.go:2135	0x6e3229		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2135	0x6e3235		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2135	0x6e323d		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e3245		e876c7d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2135	0x6e324a		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2135	0x6e3252		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2135	0x6e325a		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e3262		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e3269		5d				POPQ BP															
  compile.go:2144	0x6e326a		c3				RET															
  compile.go:2123	0x6e326b		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2123	0x6e3277		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2123	0x6e327f		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e3287		e834c7d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2123	0x6e328c		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2123	0x6e3294		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2123	0x6e329c		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e32a4		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e32ab		5d				POPQ BP															
  compile.go:2144	0x6e32ac		c3				RET															
  compile.go:2120	0x6e32ad		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2120	0x6e32b9		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2120	0x6e32c1		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e32c9		e8f2c6d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2120	0x6e32ce		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2120	0x6e32d6		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2120	0x6e32de		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e32e6		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e32ed		5d				POPQ BP															
  compile.go:2144	0x6e32ee		c3				RET															
  compile.go:2083	0x6e32ef		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2083	0x6e32fb		4889842400070000		MOVQ AX, 0x700(SP)													
  compile.go:2083	0x6e3303		48899c2408070000		MOVQ BX, 0x708(SP)													
  compile.go:2144	0x6e330b		e8b0c6d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2083	0x6e3310		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2083	0x6e3318		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2083	0x6e3320		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e3328		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e332f		5d				POPQ BP															
  compile.go:2144	0x6e3330		c3				RET															
  compile.go:2074	0x6e3331		48c784242007000000000000	MOVQ $0x0, 0x720(SP)													
  compile.go:2074	0x6e333d		48899c2400070000		MOVQ BX, 0x700(SP)													
  compile.go:2074	0x6e3345		48898c2408070000		MOVQ CX, 0x708(SP)													
  compile.go:2144	0x6e334d		e86ec6d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2074	0x6e3352		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2074	0x6e335a		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2074	0x6e3362		488b842420070000		MOVQ 0x720(SP), AX													
  compile.go:2144	0x6e336a		4881c4200d0000			ADDQ $0xd20, SP														
  compile.go:2144	0x6e3371		5d				POPQ BP															
  compile.go:2144	0x6e3372		c3				RET															
  compile.go:2137	0x6e3373		88942442030000			MOVB DL, 0x342(SP)													
  compile.go:2137	0x6e337a		488d056797ac00			LEAQ 0xac9767(IP), AX													
  compile.go:2137	0x6e3381		e8daf7d3ff			CALL runtime.newobject(SB)												
  compile.go:2137	0x6e3386		488b8c2488050000		MOVQ 0x588(SP), CX													
  compile.go:2137	0x6e338e		48894810			MOVQ CX, 0x10(AX)													
  compile.go:2137	0x6e3392		488b8c2490050000		MOVQ 0x590(SP), CX													
  compile.go:2137	0x6e339a		48894818			MOVQ CX, 0x18(AX)													
  plugin_machine.go:556	0x6e339e		0fb68c244a030000		MOVZX 0x34a(SP), CX													
  plugin_machine.go:556	0x6e33a6		84c9				TESTL CL, CL														
  amd64_features.go:45	0x6e33a8		0fb6942443030000		MOVZX 0x343(SP), DX													
  amd64_features.go:45	0x6e33b0		f6c201				TESTL $0x1, DL														
  amd64_features.go:46	0x6e33b3		bb00000000			MOVL $0x0, BX														
  amd64_features.go:46	0x6e33b8		be80000000			MOVL $0x80, SI														
  amd64_features.go:46	0x6e33bd		0f45de				CMOVNE SI, BX														
  amd64_features.go:49	0x6e33c0		89de				MOVL BX, SI														
  amd64_features.go:49	0x6e33c2		83cb20				ORL $0x20, BX														
  amd64_features.go:48	0x6e33c5		f6c202				TESTL $0x2, DL														
  amd64_features.go:49	0x6e33c8		0f45f3				CMOVNE BX, SI														
  amd64_features.go:52	0x6e33cb		89f3				MOVL SI, BX														
  amd64_features.go:52	0x6e33cd		81ce00010000			ORL $0x100, SI														
  amd64_features.go:51	0x6e33d3		f6c204				TESTL $0x4, DL														
  amd64_features.go:52	0x6e33d6		0f45de				CMOVNE SI, BX														
  plugin_machine.go:554	0x6e33d9		8bb42464030000			MOVL 0x364(SP), SI													
  plugin_machine.go:554	0x6e33e0		09f3				ORL SI, BX														
  plugin_machine.go:556	0x6e33e2		89df				MOVL BX, DI														
  plugin_machine.go:556	0x6e33e4		83cb40				ORL $0x40, BX														
  plugin_machine.go:556	0x6e33e7		84c9				TESTL CL, CL														
  plugin_machine.go:556	0x6e33e9		0f45fb				CMOVNE BX, DI														
  compile.go:2137	0x6e33ec		833d8dabb30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:2137	0x6e33f3		752b				JNE 0x6e3420														
  compile.go:2137	0x6e33f5		488b9c24480a0000		MOVQ 0xa48(SP), BX													
  compile.go:2137	0x6e33fd		4c8b8424080b0000		MOVQ 0xb08(SP), R8													
  compile.go:2137	0x6e3405		4c8b8c2488080000		MOVQ 0x888(SP), R9													
  compile.go:2137	0x6e340d		4c8b9424400a0000		MOVQ 0xa40(SP), R10													
  compile.go:2137	0x6e3415		4c8ba424380a0000		MOVQ 0xa38(SP), R12													
  compile.go:2137	0x6e341d		eb41				JMP 0x6e3460														
  compile.go:2137	0x6e341f		90				NOPL															
  compile.go:2137	0x6e3420		e83b1cdbff			CALL runtime.gcWriteBarrier5(SB)											
  compile.go:2137	0x6e3425		488b9c24480a0000		MOVQ 0xa48(SP), BX													
  compile.go:2137	0x6e342d		49891b				MOVQ BX, 0(R11)														
  compile.go:2137	0x6e3430		4c8b8424080b0000		MOVQ 0xb08(SP), R8													
  compile.go:2137	0x6e3438		4d894308			MOVQ R8, 0x8(R11)													
  compile.go:2137	0x6e343c		4c8b8c2488080000		MOVQ 0x888(SP), R9													
  compile.go:2137	0x6e3444		4d894b10			MOVQ R9, 0x10(R11)													
  compile.go:2137	0x6e3448		4c8b9424400a0000		MOVQ 0xa40(SP), R10													
  compile.go:2137	0x6e3450		4d895318			MOVQ R10, 0x18(R11)													
  compile.go:2137	0x6e3454		4c8ba424380a0000		MOVQ 0xa38(SP), R12													
  compile.go:2137	0x6e345c		4d896320			MOVQ R12, 0x20(R11)													
  compile.go:2137	0x6e3460		48895808			MOVQ BX, 0x8(AX)													
  compile.go:2137	0x6e3464		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:2137	0x6e346c		48895828			MOVQ BX, 0x28(AX)													
  compile.go:2137	0x6e3470		48895830			MOVQ BX, 0x30(AX)													
  compile.go:2137	0x6e3474		4c894020			MOVQ R8, 0x20(AX)													
  compile.go:2137	0x6e3478		488b9c2420050000		MOVQ 0x520(SP), BX													
  compile.go:2137	0x6e3480		48895850			MOVQ BX, 0x50(AX)													
  compile.go:2137	0x6e3484		48895858			MOVQ BX, 0x58(AX)													
  compile.go:2137	0x6e3488		4c894848			MOVQ R9, 0x48(AX)													
  compile.go:2137	0x6e348c		488b9c2478050000		MOVQ 0x578(SP), BX													
  compile.go:2137	0x6e3494		48895868			MOVQ BX, 0x68(AX)													
  compile.go:2137	0x6e3498		488b9c2480050000		MOVQ 0x580(SP), BX													
  compile.go:2137	0x6e34a0		48895870			MOVQ BX, 0x70(AX)													
  compile.go:2137	0x6e34a4		4c895060			MOVQ R10, 0x60(AX)													
  compile.go:2137	0x6e34a8		488b9c2468050000		MOVQ 0x568(SP), BX													
  compile.go:2137	0x6e34b0		48899898000000			MOVQ BX, 0x98(AX)													
  compile.go:2137	0x6e34b7		488b9c2470050000		MOVQ 0x570(SP), BX													
  compile.go:2137	0x6e34bf		488998a0000000			MOVQ BX, 0xa0(AX)													
  compile.go:2137	0x6e34c6		4c89a090000000			MOVQ R12, 0x90(AX)													
  compile.go:2137	0x6e34cd		0fb69c2442030000		MOVZX 0x342(SP), BX													
  compile.go:2137	0x6e34d5		8898a8000000			MOVB BL, 0xa8(AX)													
  compile.go:2137	0x6e34db		8938				MOVL DI, 0(AX)														
  compile.go:2137	0x6e34dd		8888a9000000			MOVB CL, 0xa9(AX)													
  compile.go:2137	0x6e34e3		8890aa000000			MOVB DL, 0xaa(AX)													
  compile.go:2137	0x6e34e9		0fbae604			BTL $0x4, SI														
  compile.go:2137	0x6e34ed		0f9280ab000000			SETB 0xab(AX)														
  compile.go:2137	0x6e34f4		0fbae60a			BTL $0xa, SI														
  compile.go:2137	0x6e34f8		0f9280ac000000			SETB 0xac(AX)														
  compile.go:2137	0x6e34ff		4889842420070000		MOVQ AX, 0x720(SP)													
  compile.go:2137	0x6e3507		440f11bc2400070000		MOVUPS X15, 0x700(SP)													
  compile.go:2144	0x6e3510		e8abc4d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2137	0x6e3515		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2137	0x6e351d		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2137	0x6e3525		488b842420070000		MOVQ 0x720(SP), AX													
  plugin_machine.go:555	0x6e352d		4881c4200d0000			ADDQ $0xd20, SP														
  plugin_machine.go:555	0x6e3534		5d				POPQ BP															
  plugin_machine.go:555	0x6e3535		c3				RET															
  compile.go:2463	0x6e3536		498d7001			LEAQ 0x1(R8), SI													
  compile.go:2463	0x6e353a		4839f2				CMPQ DX, SI														
  compile.go:2463	0x6e353d		7e17				JLE 0x6e3556														
  compile.go:2464	0x6e353f		4989f0				MOVQ SI, R8														
  compile.go:2464	0x6e3542		48c1e605			SHLQ $0x5, SI														
  compile.go:2464	0x6e3546		0fb6343e			MOVZX 0(SI)(DI*1), SI													
  compile.go:2464	0x6e354a		4084f6				TESTL SI, SI														
  compile.go:2464	0x6e354d		75e7				JNE 0x6e3536														
  compile.go:2464	0x6e354f		31d2				XORL DX, DX														
  compile.go:2137	0x6e3551		e91dfeffff			JMP 0x6e3373														
  compile.go:2137	0x6e3556		ba01000000			MOVL $0x1, DX														
  compile.go:2137	0x6e355b		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:2137	0x6e3560		e90efeffff			JMP 0x6e3373														
  compile.go:2140	0x6e3565		88942441030000			MOVB DL, 0x341(SP)													
  compile.go:2140	0x6e356c		488d057595ac00			LEAQ 0xac9575(IP), AX													
  compile.go:2140	0x6e3573		e8e8f5d3ff			CALL runtime.newobject(SB)												
  compile.go:2140	0x6e3578		488b8c2480030000		MOVQ 0x380(SP), CX													
  compile.go:2140	0x6e3580		48894810			MOVQ CX, 0x10(AX)													
  compile.go:2140	0x6e3584		48894818			MOVQ CX, 0x18(AX)													
  plugin_machine.go:556	0x6e3588		0fb68c244a030000		MOVZX 0x34a(SP), CX													
  plugin_machine.go:556	0x6e3590		84c9				TESTL CL, CL														
  amd64_features.go:45	0x6e3592		0fb6942443030000		MOVZX 0x343(SP), DX													
  amd64_features.go:45	0x6e359a		f6c201				TESTL $0x1, DL														
  amd64_features.go:46	0x6e359d		bb00000000			MOVL $0x0, BX														
  amd64_features.go:46	0x6e35a2		be80000000			MOVL $0x80, SI														
  amd64_features.go:46	0x6e35a7		0f45de				CMOVNE SI, BX														
  amd64_features.go:49	0x6e35aa		89de				MOVL BX, SI														
  amd64_features.go:49	0x6e35ac		83cb20				ORL $0x20, BX														
  amd64_features.go:48	0x6e35af		f6c202				TESTL $0x2, DL														
  amd64_features.go:49	0x6e35b2		0f45f3				CMOVNE BX, SI														
  amd64_features.go:52	0x6e35b5		89f3				MOVL SI, BX														
  amd64_features.go:52	0x6e35b7		81ce00010000			ORL $0x100, SI														
  amd64_features.go:51	0x6e35bd		f6c204				TESTL $0x4, DL														
  amd64_features.go:52	0x6e35c0		0f45de				CMOVNE SI, BX														
  plugin_machine.go:554	0x6e35c3		8bb42464030000			MOVL 0x364(SP), SI													
  plugin_machine.go:554	0x6e35ca		09f3				ORL SI, BX														
  plugin_machine.go:556	0x6e35cc		89df				MOVL BX, DI														
  plugin_machine.go:556	0x6e35ce		83cb40				ORL $0x40, BX														
  plugin_machine.go:556	0x6e35d1		84c9				TESTL CL, CL														
  plugin_machine.go:556	0x6e35d3		0f45fb				CMOVNE BX, DI														
  compile.go:2140	0x6e35d6		833da3a9b30000			CMPL runtime.writeBarrier(SB), $0x0											
  compile.go:2140	0x6e35dd		7532				JNE 0x6e3611														
  compile.go:2140	0x6e35df		488b9c2410070000		MOVQ 0x710(SP), BX													
  compile.go:2140	0x6e35e7		4c8b8424800a0000		MOVQ 0xa80(SP), R8													
  compile.go:2140	0x6e35ef		4c8b8c24080b0000		MOVQ 0xb08(SP), R9													
  compile.go:2140	0x6e35f7		4c8b942488080000		MOVQ 0x888(SP), R10													
  compile.go:2140	0x6e35ff		4c8ba424400a0000		MOVQ 0xa40(SP), R12													
  compile.go:2140	0x6e3607		4c8bac24380a0000		MOVQ 0xa38(SP), R13													
  compile.go:2140	0x6e360f		eb4c				JMP 0x6e365d														
  compile.go:2140	0x6e3611		e86a1adbff			CALL runtime.gcWriteBarrier6(SB)											
  compile.go:2140	0x6e3616		488b9c2410070000		MOVQ 0x710(SP), BX													
  compile.go:2140	0x6e361e		49891b				MOVQ BX, 0(R11)														
  compile.go:2140	0x6e3621		4c8b8424800a0000		MOVQ 0xa80(SP), R8													
  compile.go:2140	0x6e3629		4d894308			MOVQ R8, 0x8(R11)													
  compile.go:2140	0x6e362d		4c8b8c24080b0000		MOVQ 0xb08(SP), R9													
  compile.go:2140	0x6e3635		4d894b10			MOVQ R9, 0x10(R11)													
  compile.go:2140	0x6e3639		4c8b942488080000		MOVQ 0x888(SP), R10													
  compile.go:2140	0x6e3641		4d895318			MOVQ R10, 0x18(R11)													
  compile.go:2140	0x6e3645		4c8ba424400a0000		MOVQ 0xa40(SP), R12													
  compile.go:2140	0x6e364d		4d896320			MOVQ R12, 0x20(R11)													
  compile.go:2140	0x6e3651		4c8bac24380a0000		MOVQ 0xa38(SP), R13													
  compile.go:2140	0x6e3659		4d896b28			MOVQ R13, 0x28(R11)													
  compile.go:2140	0x6e365d		48895808			MOVQ BX, 0x8(AX)													
  compile.go:2140	0x6e3661		488d1de0dcad00			LEAQ 0xaddce0(IP), BX													
  compile.go:2140	0x6e3668		48895838			MOVQ BX, 0x38(AX)													
  compile.go:2140	0x6e366c		4c894040			MOVQ R8, 0x40(AX)													
  compile.go:2140	0x6e3670		488b9c2458050000		MOVQ 0x558(SP), BX													
  compile.go:2140	0x6e3678		48895828			MOVQ BX, 0x28(AX)													
  compile.go:2140	0x6e367c		48895830			MOVQ BX, 0x30(AX)													
  compile.go:2140	0x6e3680		4c894820			MOVQ R9, 0x20(AX)													
  compile.go:2140	0x6e3684		488b9c2420050000		MOVQ 0x520(SP), BX													
  compile.go:2140	0x6e368c		48895850			MOVQ BX, 0x50(AX)													
  compile.go:2140	0x6e3690		48895858			MOVQ BX, 0x58(AX)													
  compile.go:2140	0x6e3694		4c895048			MOVQ R10, 0x48(AX)													
  compile.go:2140	0x6e3698		488b9c2478050000		MOVQ 0x578(SP), BX													
  compile.go:2140	0x6e36a0		48895868			MOVQ BX, 0x68(AX)													
  compile.go:2140	0x6e36a4		488b9c2480050000		MOVQ 0x580(SP), BX													
  compile.go:2140	0x6e36ac		48895870			MOVQ BX, 0x70(AX)													
  compile.go:2140	0x6e36b0		4c896060			MOVQ R12, 0x60(AX)													
  compile.go:2140	0x6e36b4		488b9c2468050000		MOVQ 0x568(SP), BX													
  compile.go:2140	0x6e36bc		48899898000000			MOVQ BX, 0x98(AX)													
  compile.go:2140	0x6e36c3		488b9c2470050000		MOVQ 0x570(SP), BX													
  compile.go:2140	0x6e36cb		488998a0000000			MOVQ BX, 0xa0(AX)													
  compile.go:2140	0x6e36d2		4c89a890000000			MOVQ R13, 0x90(AX)													
  compile.go:2140	0x6e36d9		0fb69c2441030000		MOVZX 0x341(SP), BX													
  compile.go:2140	0x6e36e1		8898a8000000			MOVB BL, 0xa8(AX)													
  compile.go:2140	0x6e36e7		8938				MOVL DI, 0(AX)														
  compile.go:2140	0x6e36e9		8888a9000000			MOVB CL, 0xa9(AX)													
  compile.go:2140	0x6e36ef		8890aa000000			MOVB DL, 0xaa(AX)													
  compile.go:2140	0x6e36f5		0fbae604			BTL $0x4, SI														
  compile.go:2140	0x6e36f9		0f9280ab000000			SETB 0xab(AX)														
  compile.go:2140	0x6e3700		0fbae60a			BTL $0xa, SI														
  compile.go:2140	0x6e3704		0f9280ac000000			SETB 0xac(AX)														
  compile.go:2140	0x6e370b		4889842420070000		MOVQ AX, 0x720(SP)													
  compile.go:2140	0x6e3713		440f11bc2400070000		MOVUPS X15, 0x700(SP)													
  compile.go:2144	0x6e371c		0f1f4000			NOPL 0(AX)														
  compile.go:2144	0x6e3720		e89bc2d6ff			CALL runtime.deferreturn(SB)												
  compile.go:2140	0x6e3725		488b9c2400070000		MOVQ 0x700(SP), BX													
  compile.go:2140	0x6e372d		488b8c2408070000		MOVQ 0x708(SP), CX													
  compile.go:2140	0x6e3735		488b842420070000		MOVQ 0x720(SP), AX													
  plugin_machine.go:555	0x6e373d		4881c4200d0000			ADDQ $0xd20, SP														
  plugin_machine.go:555	0x6e3744		5d				POPQ BP															
  plugin_machine.go:555	0x6e3745		c3				RET															
  compile.go:2463	0x6e3746		498d7001			LEAQ 0x1(R8), SI													
  compile.go:2463	0x6e374a		4839f2				CMPQ DX, SI														
  compile.go:2463	0x6e374d		7e17				JLE 0x6e3766														
  compile.go:2464	0x6e374f		4989f0				MOVQ SI, R8														
  compile.go:2464	0x6e3752		48c1e605			SHLQ $0x5, SI														
  compile.go:2464	0x6e3756		0fb6343e			MOVZX 0(SI)(DI*1), SI													
  compile.go:2464	0x6e375a		4084f6				TESTL SI, SI														
  compile.go:2464	0x6e375d		75e7				JNE 0x6e3746														
  compile.go:2464	0x6e375f		31d2				XORL DX, DX														
  compile.go:2140	0x6e3761		e9fffdffff			JMP 0x6e3565														
  compile.go:2140	0x6e3766		ba01000000			MOVL $0x1, DX														
  compile.go:2140	0x6e376b		e9f5fdffff			JMP 0x6e3565														
  code_buffer.go:159	0x6e3770		e82b1cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e3775		e8261cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e377a		e8211cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e377f		90				NOPL															
  code_buffer.go:159	0x6e3780		e81b1cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e3785		e8161cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e378a		e8111cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:146	0x6e378f		e80c1cdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e3794		e8071cdbff			CALL runtime.panicBounds(SB)												
  catalog.go:96		0x6e3799		e8021cdbff			CALL runtime.panicBounds(SB)												
  compile.go:2055	0x6e379e		6690				NOPW															
  compile.go:2055	0x6e37a0		e8fb1bdbff			CALL runtime.panicBounds(SB)												
  compile.go:2049	0x6e37a5		e8f61bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1208	0x6e37aa		e8f11bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1208	0x6e37af		e8ec1bdbff			CALL runtime.panicBounds(SB)												
  compile.go:2028	0x6e37b4		e8e71bdbff			CALL runtime.panicBounds(SB)												
  catalog.go:96		0x6e37b9		e8e21bdbff			CALL runtime.panicBounds(SB)												
  compile.go:2004	0x6e37be		6690				NOPW															
  compile.go:2004	0x6e37c0		e8db1bdbff			CALL runtime.panicBounds(SB)												
  compile.go:2003	0x6e37c5		e8d61bdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e37ca		e8d11bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1997	0x6e37cf		e8cc1bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1997	0x6e37d4		e8c71bdbff			CALL runtime.panicBounds(SB)												
  code_buffer.go:159	0x6e37d9		e8c21bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1989	0x6e37de		6690				NOPW															
  compile.go:1989	0x6e37e0		e8bb1bdbff			CALL runtime.panicBounds(SB)												
  inline.go:527		0x6e37e5		e8b61bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1986	0x6e37ea		e8b11bdbff			CALL runtime.panicBounds(SB)												
  compile.go:1389	0x6e37ef		460fb6140e			MOVZX 0(SI)(R9*1), R10													
  compile.go:1391	0x6e37f4		4c01d7				ADDQ R10, DI														
  compile.go:1389	0x6e37f7		48ffc6				INCQ SI															
  compile.go:1389	0x6e37fa		4939f0				CMPQ R8, SI														
  compile.go:1389	0x6e37fd		7ff0				JG 0x6e37ef														
  compile.go:1389	0x6e37ff		90				NOPL															
  compile.go:1975	0x6e3800		4883ff02			CMPQ DI, $0x2														
  compile.go:1975	0x6e3804		771c				JA 0x6e3822														
  compile.go:1975	0x6e3806		488db42490060000		LEAQ 0x690(SP), SI													
  compile.go:1975	0x6e380e		440f113e			MOVUPS X15, 0(SI)													
  compile.go:1975	0x6e3812		440f117e10			MOVUPS X15, 0x10(SI)													
  compile.go:1975	0x6e3817		488d842490060000		LEAQ 0x690(SP), AX													
  compile.go:1975	0x6e381f		90				NOPL															
  compile.go:1975	0x6e3820		eb39				JMP 0x6e385b														
  compile.go:1389	0x6e3822		4889bc24d0040000		MOVQ DI, 0x4d0(SP)													
  compile.go:1975	0x6e382a		488d058713aa00			LEAQ 0xaa1387(IP), AX													
  compile.go:1975	0x6e3831		31db				XORL BX, BX														
  compile.go:1975	0x6e3833		4889f9				MOVQ DI, CX														
  compile.go:1975	0x6e3836		e825c9daff			CALL runtime.makeslice(SB)												
  compile.go:2065	0x6e383b		488b942488030000		MOVQ 0x388(SP), DX													
  compile.go:1975	0x6e3843		488bbc24d0040000		MOVQ 0x4d0(SP), DI													
  compile.go:1986	0x6e384b		4c8b842428050000		MOVQ 0x528(SP), R8													
  compile.go:1986	0x6e3853		4c8b8c24d8080000		MOVQ 0x8d8(SP), R9													
  compile.go:1975	0x6e385b		31c9				XORL CX, CX														
  compile.go:1975	0x6e385d		31db				XORL BX, BX														
  compile.go:1975	0x6e385f		4889de				MOVQ BX, SI														
  compile.go:1975	0x6e3862		4889c3				MOVQ AX, BX														
  compile.go:1975	0x6e3865		4889f8				MOVQ DI, AX														
  compile.go:1978	0x6e3868		e999d2ffff			JMP 0x6e0b06														
  compile.go:1389	0x6e386d		460fb6140f			MOVZX 0(DI)(R9*1), R10													
  compile.go:1391	0x6e3872		4c01d6				ADDQ R10, SI														
  compile.go:1389	0x6e3875		48ffc7				INCQ DI															
  compile.go:1389	0x6e3878		4939f8				CMPQ R8, DI														
  compile.go:1389	0x6e387b		7ff0				JG 0x6e386d														
  compile.go:1389	0x6e387d		0f1f00				NOPL 0(AX)														
  compile.go:1973	0x6e3880		4883fe02			CMPQ SI, $0x2														
  compile.go:1973	0x6e3884		771c				JA 0x6e38a2														
  compile.go:1973	0x6e3886		488dbc24b0060000		LEAQ 0x6b0(SP), DI													
  compile.go:1973	0x6e388e		440f113f			MOVUPS X15, 0(DI)													
  compile.go:1973	0x6e3892		440f117f10			MOVUPS X15, 0x10(DI)													
  compile.go:1973	0x6e3897		488d8424b0060000		LEAQ 0x6b0(SP), AX													
  compile.go:1973	0x6e389f		90				NOPL															
  compile.go:1973	0x6e38a0		eb39				JMP 0x6e38db														
  compile.go:1389	0x6e38a2		4889b424d8040000		MOVQ SI, 0x4d8(SP)													
  compile.go:1973	0x6e38aa		488d05c713aa00			LEAQ 0xaa13c7(IP), AX													
  compile.go:1973	0x6e38b1		31db				XORL BX, BX														
  compile.go:1973	0x6e38b3		4889f1				MOVQ SI, CX														
  compile.go:1973	0x6e38b6		e8a5c8daff			CALL runtime.makeslice(SB)												
  compile.go:2065	0x6e38bb		488b942488030000		MOVQ 0x388(SP), DX													
  compile.go:1973	0x6e38c3		488bb424d8040000		MOVQ 0x4d8(SP), SI													
  compile.go:1986	0x6e38cb		4c8b842428050000		MOVQ 0x528(SP), R8													
  compile.go:1986	0x6e38d3		4c8b8c24d8080000		MOVQ 0x8d8(SP), R9													
  compile.go:1973	0x6e38db		4889f1				MOVQ SI, CX														
  compile.go:1973	0x6e38de		4889c3				MOVQ AX, BX														
  compile.go:1973	0x6e38e1		31ff				XORL DI, DI														
  compile.go:1973	0x6e38e3		31c0				XORL AX, AX														
  compile.go:1973	0x6e38e5		e975ffffff			JMP 0x6e385f														
  catalog.go:96		0x6e38ea		e8b11adbff			CALL runtime.panicBounds(SB)												
  compile.go:1056	0x6e38ef		496bc81c			IMULQ $0x1c, R8, CX													
  compile.go:1056	0x6e38f3		410fb64c0a18			MOVZX 0x18(R10)(CX*1), CX												
  compile.go:1056	0x6e38f9		4939c9				CMPQ R9, CX														
  compile.go:1057	0x6e38fc		4c0f4cc9			CMOVL CX, R9														
  compile.go:1055	0x6e3900		49ffc0				INCQ R8															
  compile.go:1055	0x6e3903		4c39c6				CMPQ SI, R8														
  compile.go:1055	0x6e3906		7fe7				JG 0x6e38ef														
  compile.go:1060	0x6e3908		4d85c9				TESTQ R9, R9														
  compile.go:1060	0x6e390b		7406				JE 0x6e3913														
  compile.go:1060	0x6e390d		4983f940			CMPQ R9, $0x40														
  compile.go:1060	0x6e3911		7c07				JL 0x6e391a														
  compile.go:1060	0x6e3913		31c0				XORL AX, AX														
  compile.go:1940	0x6e3915		e9b6ceffff			JMP 0x6e07d0														
  compile.go:1063	0x6e391a		498d4101			LEAQ 0x1(R9), AX													
  compile.go:1063	0x6e391e		6690				NOPW															
  compile.go:1940	0x6e3920		e9abceffff			JMP 0x6e07d0														
  compile.go:1862	0x6e3925		c6041001			MOVB $0x1, 0(AX)(DX*1)													
  compile.go:1861	0x6e3929		48ffc2				INCQ DX															
  compile.go:1861	0x6e392c		4839d3				CMPQ BX, DX														
  compile.go:1861	0x6e392f		7ff4				JG 0x6e3925														
  compile.go:1861	0x6e3931		e941c4ffff			JMP 0x6dfd77														
  compile.go:1854	0x6e3936		e8651adbff			CALL runtime.panicBounds(SB)												
  compile.go:1840	0x6e393b		0f1f440000			NOPL 0(AX)(AX*1)													
  compile.go:1840	0x6e3940		e85b1adbff			CALL runtime.panicBounds(SB)												
  orchestration.go:45	0x6e3945		e8561adbff			CALL runtime.panicBounds(SB)												
  catalog.go:96		0x6e394a		e8511adbff			CALL runtime.panicBounds(SB)												
  catalog.go:96		0x6e394f		90				NOPL															
  compile.go:1749	0x6e3950		4889842410010000		MOVQ AX, 0x110(SP)													
  compile.go:1749	0x6e3958		e8a3fcdaff			CALL runtime.morestack_noctxt.abi0(SB)											
  compile.go:1749	0x6e395d		488b842410010000		MOVQ 0x110(SP), AX													
  compile.go:1749	0x6e3965		e9b6b6ffff			JMP github.com/wago-org/wago/src/core/compiler/backend/railshot/amd64.compileModuleWith(SB)				
